<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once ("my_controller.php");
class Nexthigherclass extends My_Controller {


	public function index()
	{
		//$this->load->view("login");
        
         $this->load->view('header_nexthigher/headermerit');
         $this->load->view('header_nexthigher/navbarmerit');
         $this->load->view('nexthigherform');
         $this->load->view('footer_nexthigher/footermerit');

	}
	

	public function getStudentInfo()
	{
		
		$CI = &get_instance();
        $this->db2 = $CI->load->database('db2', TRUE);
		$id = $this->input->post('search');
	    
	    $search = "SELECT * FROM candidate_profile_bach_2018
                        WHERE seat_no = '$id'";
		$queryAdmin = $this->db2->query($search);
		$registerdata =  $queryAdmin->result_array();
		$data['data']=$registerdata;
		$this->load->view('searchnexthigher',$data);

	}


	public function candidateProfile()
	{
		
		$CI = &get_instance();
        $this->db2 = $CI->load->database('db2', TRUE);
		$seatnum = $this->input->post('seatnum');
		$progam = $this->input->post('progam');
		$batch = $this->input->post('batch');
		$sql = "SELECT * FROM `next_higher_class_2018` WHERE `batch`='$batch' and program='$progam' and id_no=$seatnum";
		$queryAdmin = $this->db2->query($sql);
		if ($queryAdmin->num_rows() > 0)
               {
               	$registerdata =  $queryAdmin->result_array();
				$data['data']=$registerdata;
				$this->load->view('header_nexthigher/headermerit');
		        $this->load->view('header_nexthigher/navbarmerit');
				$this->load->view('searchnexthigher',$data);
				$this->load->view('footer_nexthigher/footermerit');

               }
         else {	
         		
         		$this->session->set_flashdata('error_msg', 'Please input all correct data.');
               	 redirect('/nexthigherclass');
               }      
		
		//print_r($registerdata);
	    
	    

	}

	public function updatePrint()
	{
		
		$CI = &get_instance();
        $this->db2 = $CI->load->database('db2', TRUE);
		$peraddress = $this->input->post('peraddress');
		$rowid = $this->input->post('rowid');
		$posaddress = $this->input->post('posaddress');
		$mobile = $this->input->post('mobile');
		$phone = $this->input->post('phone');
		$blood = $this->input->post('blood');
		$sql = "UPDATE `next_higher_class_2018` SET `permenant_add`='$peraddress',`postal_add`='$posaddress',`mobile_no`=$mobile,`phone_no`=$phone,`blood_group`='$blood' WHERE `candidate_id`=$rowid";

		$queryAdmin = $this->db2->query($sql);
		header("location:http://admission.usindh.edu.pk/form_new.php?id=$rowid");
		
		//print_r($registerdata);
	    
	    

	}

	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */

