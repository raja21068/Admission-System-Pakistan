<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class searchcandidate extends CI_Controller {


	public function __construct(){
        parent::__construct();
       
		}
	public function index()
	{
		$bar_data = array("is_logged_in"=>false);
        $this->load->view("bar",$bar_data);
        $data = array();
        $data["title"] = "Search Candidate";
        $data[Variable::Message()] = '';
        $data["request_submit"] = "searchcandidate/resultsearch";
        $this->load->view("searchform",$data);
        $this->load->view('footerbar');

	}

	
	public function result()
	{
		
		$data['title'] = 'Result';
		$this->load->view('header/header',$data);
		$this->load->view('navbar/navbar');
		$this->load->view('result/result');
		$this->load->view('footer/footer');
	}
	public function resultsearch()
	{
		$candidateid = $this->input->post('candidateid');
		//$search = "SELECT * FROM candidate
          //              WHERE candidate_id = '$candidateid' AND program_type_id=2";

        $searchQr="SELECT candidate. * , country.name AS country, district.name AS district
					FROM candidate
					INNER JOIN country ON candidate.country_id = country.country_id
					INNER JOIN district ON candidate.district_id = district.district_id
					WHERE candidate.`candidate_id` ='$candidateid' AND program_type_id=2";

		$queryAdmin = $this->db->query($searchQr);

		if ($queryAdmin->num_rows() > 0) {
            $searchdata =  $queryAdmin->row_array();
		  echo "<pre>";print_r($searchdata);"</pre>";
     	}
     	else
     		{echo "Records not found;";}

		
	}

	public function searchFilter()
	{
		$id = $this->input->post('search');
		$search = "SELECT * FROM student_new
                        WHERE user_id = '$id'";
		$queryAdmin = $this->db->query($search);
		$registerdata =  $queryAdmin->row_array();
		 if(count($registerdata) == 0)
		 {
		 	return "error";
		 }
		 else
		 {
			return $this->resultsearch($registerdata); 	
		 }
	}
		 
}