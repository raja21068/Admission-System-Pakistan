<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//require_once ("my_controller.php");
class Results extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->helper('url');
    }

	public function index()
	{
		echo "<h1>Results 2017</h1>";
	}

    public function import()
    {

        $bar_data = array("is_logged_in"=>false);
        $this->load->view("bar_results",$bar_data );
        $data = array();
        $data["title"] = "Candidate Admission Application Form";
        $data[Variable::Message()] = 'Import Results';
        $data["request_submit"] = "results/importsubmit";
        $this->load->view("import_results",$data);
        $this->load->view('footerbar');

    }

    public function importsubmit()

    {


        $csv_file = $_FILES['filecsv']["tmp_name"];
        $lines = file($csv_file, FILE_IGNORE_NEW_LINES);
     if (($handle = fopen($csv_file, "r")) !== FALSE)
            {
             $csv = array();
                foreach($lines as $key => $value)
		     {
		     	if($key == 0)continue;
		         $csv[$key] = str_getcsv($value);
		     }

               //echo '<pre>';print_r($csv);echo '</pre>';

		        foreach ($csv as $key => $finalvalue){
		        	 //array_push($finalvalue,"Computer Science");
		        		 $insertValues='';
		        	 foreach ($finalvalue as $keyfinal => $finalvalue2){
		        	 	 if($keyfinal==0)$comma='';else $comma=',';
		        	 	 if($keyfinal==1 || $keyfinal==2)$qot='"';else $qot='';
		        	 	 $insertValues.=$comma.$qot.$finalvalue2.$qot;

		        	 	// echo $keyfinal."-".$finalvalue2."<br>";
		        	 }

		        	 echo $insertValues."<hr>";

		      //  	$sql = "INSERT INTO result_bech (seatno, name, fname, perscore, totalscore)
//VALUES (".$insertValues.")";
					
					//$this->db->query($sql);
							
                   
		        }

		  
               fclose($handle);
            }

    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */

