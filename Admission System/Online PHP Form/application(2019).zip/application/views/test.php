<?php
/**
 * Created by PhpStorm.
 * User: Jay
 * Date: 05-Sep-15
 * Time: 10:33 AM
 */
$repo = new Slip_Report(19,"");
$repo->printReport("","");