<style type="text/css">

   .loader

   {

    height: 20px;

    width: 20px;

    position: absolute;

    top: 8px;

    left: 10px;

   }
    #errmsg
    {
    color: red;
    }

</style>

<!-- Content Start -->

         <div id="main">

            <!-- Title, Breadcrumb Start-->

            <div class="breadcrumb-wrapper">

               <div class="container">

                  <div class="row">

                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">

                        <h2 class="title">Next Higher Class Form</h2>

                     </div>

                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">

                       

                     </div>

                  </div>

               </div>

            </div>

            <!-- Title, Breadcrumb End-->

            <!-- Main Content start-->

            <div class="content">

               <div class="container">
                 <?php $error_msg = $this->session->flashdata('error_msg');
                 if(!empty($error_msg)){?><div class="alert alert-danger" role="alert">
        <strong></strong> <?php echo $error_msg;?>.
      </div><?php }?>
                 <div class="container">
                  <div class="row">
                     <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12" id="contact-form">
                        <h3 class="title">Please fill all the fields carefully.</h3>
                        <div class="divider"></div>
                        <form action="http://admission.usindh.edu.pk/index.php/nexthigherclass/candidateProfile/" method="post" class="reply" id="">
                           <fieldset>
                              <div class="row">
                                 

                          
                                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                 <div class="form-group">
                                   <label for='selectBox2'>Select Your Batch</label>
                                <select class="form-control " name="batch" required>
                                  <option value="" selected="selected">Select</option>
                                  <option value="2K15">2K15</option>
                                  <option value="2K16" >2K16</option>
                                  <option value="2K17" >2K17</option>

                                   
                                </select>

                                 <label for='selectBox1'>Select Your  Progam</label>
                                  <select class="form-control" name="progam" id="" required>
                                  <option value="" selected="selected">Select</option>
                                  <option value="BACHELOR">BACHELOR</option>
                                  <option value="MASTER">MASTER</option>
                                 
                                 
                                </select>

                                 <label for='selectBox1'>ID Number (Students ID Card No.)</label>
                                 <br>
                                 <span style="color: red; font-size: 12px;">ID Number is mentioned in your Student ID Card.</span>
                                 <input class="form-control value" id="" name="seatnum" type="text" value="" required>
                                 <span id="errmsg"></span>
                              
                                  </div>
                                 </div>
                              </div>

                           </fieldset>
                           <button class="btn-normal btn-color submit  bottom-pad" type="submit">View Profile</button>
                           
                           <div class="clearfix">
                           </div>
                        </form>
                        <p style="padding: 1px; color: #3a87ad"> The computerized challans of fee by name of students would be sent to the teaching
                                Centers/ Institutes/ Departments as well as concerned Campuses as per list received by
                                teaching Center/ Institute/ Department. The students after obtaining their challan of fee
                                would deposit the amount at the HBL Sindh University Branch Jamshoro and the students
                                of Campuses at the designated Bank branches with effect from <b>12.02.2018 to 28.02.2018</b>.
                                After due date late fee <b>Rs.1000/-</b> will be charged. The staff of the Directorate of
                                Admissions will collect the admission forms from the teaching Centers/ Institutes/
                                Departments.</p>

                     </div>
                     <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
                        <div class="address widget">
                           <h3 class="title">Info</h3>
                           <ul class="contact-us">
                              <li class="text-info">
                                <!-- <p><a href="http://results.usindh.edu.pk/resultarea/Fees_Structure_For_Master.pdf">Fees Structure For Masters</a></p>
                                  <p><a href="http://results.usindh.edu.pk/resultarea/Fees_Structure_For_Bachelors.pdf">Fees Structure For Bachelors</a></p> -->
                                <p style="padding: 1px">The students are required to submit printed copy of the form along with all require
                                documents i.e. Marks Certificate of last semester examination, copy of student ID card, at
                                the concerned teaching Centre /Institute /Department for the signature/ recommendation
                                of the Director/Chairperson as per schedule.<br><br>
                                The students of various Campuses are also required to fill online form and submit the
                                printed copy of same along-with required documents at their concerned Campuses.
                                Incomplete form will not be entertained and student card will not be issued.
                                After scrutiny and verification of Marks Certificate of last examination, the concerned
                                Teaching Center/ Institute/ Department as well as Campuses would forward list (as per
                                specimen given) of recommended students for admission to next higher class through
                                official email to the Directorate of Admissions on the official email
                                <b>dir.adms@usindh.edu.pk</b>

                                </p>   
                              </li>
                           </ul>
                        </div>
                       
                     </div>
                  
                  </div>
                  

                </div>


                </div>

                  <div class="divider"></div>

                  
      
               </div>

                
               </div>



            </div>

            <!-- Main Content end-->

         </div>

         <!-- Content End -->
<script src="<?php echo base_url('htaccess/js/jquery.min.js');?>"></script>
<script type="text/javascript">
  jQuery(document).ready(function(){

     $(".value").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && e.which !=13 && (e.which < 48 || e.which > 57)) {
        //display error message
        $("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });

    $(document).on('keypress','.value',function(e)

        { 
            
            if(e.which ==13)
            {
               
                $('.searchbech').trigger('click');

            }

        })  
    $(document).on('click','.searchbech',function()
{
    $('.loader').children().css('visibility','visible')
    var val = $('.value').val();
    $.ajax({
            type: "POST",
            url: "http://admission.usindh.edu.pk/index.php/nexthigherclass/getStudentInfo",
            data: 'search='+val,
            cache: false,
            success: function(result)
            {
                $('.loader').children().css('visibility','hidden')
               
                $('.error').css('display','none');
                 $('#append').html(result);
                if (result === null || result === '')
                 {
                    $('#append').html('');
                    $('.error').css('display','block');
                 }
            }
        });
    
})
  })

</script>