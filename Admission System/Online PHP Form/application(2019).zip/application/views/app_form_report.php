<?php
/**
 * Description of AppFormReport
 *
 * @author
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AppFormReport{
    var $candidateId;
    var $candidateImage;
    var $degreeProgram;
    var $pd;
    var $columnWidth = 60;
    var $columnHeight = 5;
    var $isMaster;
    var $bean;
    public function __construct($candidateId,$candidateImage) {
        $this->candidateId = $candidateId;
        $this->candidateImage = $candidateImage;

        $this->degreeProgram = "BACHELOR DEGREE PROGRAM";
    }
    
    
    public function printReport($bean,$campusList,$appliedCats,$sscInfo,$hscInfo,$morningChoices,$eveningChoices,$grdInfo=null,$optionals = array() ,$bankName ){

        if($bean->getProgramTypeId() == Variable::$MASTER_ID){
            $this->degreeProgram = "MASTER DEGREE PROGRAM";
        }
        
        $pd = new CellPDF();
        $pd->AddPage();

        $wid = $pd->w;
        $hig = $pd->h;
        //$pd->Image(ASSET_PATH.'images/logo_trans.png',($wid/4),($hig/4),($wid/2),($hig/2));
       $pd->Image(ASSET_PATH.'images/logo.png',20,5,25,25);
       $pd->Image($this->candidateImage,($wid-45),5,35,35);
       // $pd->Image("http://admission.usindh.edu.pk/uploads/".$this->candidateId.".jpg",($wid-50),1,40,40);
        $pd->SetFillColor(0,0,0);
        $pd->SetFont("Arial",'B',20);
        $pd->Cell(0,$this->columnHeight,"University of Sindh, Jamshoro ",0,1,'C',false);
        $pd->Ln(1);
        $pd->SetFont("Times",'',12);
        $pd->Cell(0,$this->columnHeight,"ONLINE ADMISSION FORM - ".Variable::$SESSION_YEAR,0,1,'C',false);
        $pd->SetFont("Times",'',14);
        $pd->Ln(4);
        $pd->Cell(0,$this->columnHeight,"(".$this->degreeProgram.")
",0,1,'C',false);

             
        
        $pd->Ln(4);
        $pd->Cell(($wid/2),$this->columnHeight,"Candidate's Online Registration No. ".$this->candidateId,0,1);
       // $pd->Cell(($wid/2),$this->columnHeight,"Date: ".$bean->getDateOfSumbitForm(),0,1);
//        $pd->Cell(0,$this->columnHeight,"SeatNo. ".$bean->getSeatNo(),0,1,'R');
        $pd->Ln(2);
        $pd->SetFont("Times",'B',12);
        $pd->Cell($this->columnWidth,$this->columnHeight,"Applied Campus",1,0);      
        $campus= "";
        $c_location="";
        if(count($campusList)>0){
            $campus = $campusList[0]['name'];
            $c_location = $campusList[0]['location'];

        }
        $pd->SetFont("Times",'B',12);
        $pd->Cell(0,$this->columnHeight,$campus." ".$c_location,1,1);
        $pd->SetFont("Times",'B',10);$pd->Cell($this->columnWidth,$this->columnHeight,"Applied Category(ies)",1,0);      
        $sizeCats = count($appliedCats);
        $ac = "";
        for($i=0;$i<$sizeCats;$i++){
            if($i == $sizeCats-1){
                $ac.=Variable::$CategoryEnumDesc[$appliedCats[$i]['code']];
            }else{
                $ac.= (Variable::$CategoryEnumDesc[$appliedCats[$i]['code']].",");
            }
        }

        $gender="";
        $fns="";
        if($bean->getGender()==0){
            $gender="MALE";
            $fns=" Son/of";
        }else{
            $gender="FEMALE";
             $fns=" D/of";
        }
          $pd->SetFont("Times",'B',12);
        $pd->Cell(0,$this->columnHeight,$ac,1,1);      
        
        $pd->Ln(2);
        $pd->SetFont("Times",'B',10);
        $pd->Cell(0,$this->columnHeight,"Personal Information",0,1);
        $pd->SetFont("Times",'',10);
        $pd->Cell($this->columnWidth,$this->columnHeight,"Name",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getName(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Father's Name",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getFathersName(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Surname",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getSurname(),1,1,'L');

       // $pd->Cell($this->columnWidth,$this->columnHeight,"Surname",1,0);
      //  $pd->Cell(0,$this->columnHeight,"".$bean->getSurname(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Gender",1,0);
        
        $pd->Cell(0,$this->columnHeight,"".$gender,1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"CNIC No.",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getCnic(),1,1,'L');
        
         $pd->Cell($this->columnWidth,$this->columnHeight,"Date of Birth",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getDateOfBirth(),1,1,'L');
        
        $pd->Cell($this->columnWidth,$this->columnHeight,"Blood Group",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getBlood()."ve",1,1,'L');
        
        $pd->Cell($this->columnWidth,$this->columnHeight,"Religion",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bean->getReligionName(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Nationality",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bean->getCountryName(),1,1,'L');
        
       

         $pd->Cell($this->columnWidth,$this->columnHeight,"Province",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bean->getProvinceName(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"District of Domicile",1,0);
         $area="";
        if ($bean->getAreaCode()=="U"){
            $area="URBAN";
        }else{
            $area="RURAL";
        }
        
         $pd->Cell(0,$this->columnHeight,"".$bean->getDistrictName()." (".$area.")",1,1,'L');
        
       
        

       

       
       // $pd->Cell($this->columnWidth/2,$this->columnHeight,"Urban/Rural",1,0,'C');
      //  $pd->Cell($this->columnWidth/2,$this->columnHeight,"".$area,1,1,'C');
    

      
       // $pd->Cell($this->columnWidth,$this->columnHeight,"Place of Birth",1,0);
      //  $pd->Cell(0,$this->columnHeight,"".$bean->getPlaceOfBirth(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Gurdian's Name",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getGurdianName(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Father's / Gurdian's Occupation",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getOccupation(),1,1,'L');
       
    

        $pd->Cell($this->columnWidth,$this->columnHeight,"Telephone No. (Landline)",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getTelephone(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight,"Mobile No",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getMobile(),1,1,'L');
         

        $pd->Cell($this->columnWidth,$this->columnHeight,"Email Address",1,0);
        $pd->Cell(0,$this->columnHeight,"".$bean->getEmail(),1,1,'L');
        
         $pd->Cell($this->columnWidth,$this->columnHeight+5,"Permenant Home Address",1,0);
        $pd->Cell(0,$this->columnHeight+5,"".$bean->getPermenentAddr(),1,1,'L');
        $pd->Cell($this->columnWidth,$this->columnHeight+5,"Present Postal Address",1,0);
        $pd->Cell(0,$this->columnHeight+5,"".$bean->getPostalAddr(),1,1,'L');

        $pd->Ln(2);
        $pd->SetFont("Times",'BU',10);
        $pd->Cell(0,$this->columnHeight,"Academic Record",0,1);      
        $pd->SetFont("Times",'B',10);
        $pd->Cell($this->columnWidth,$this->columnHeight*2,"Examination Passed",1,0);
        $pd->Cell($this->columnWidth/3,$this->columnHeight*2,"Group",1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight*2,"Marks\n Obtained",1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight*2,"Total \nMarks",1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight*2,"Year",1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight*2,"Seat No.",1,0,'C');
        $pd->Cell(0,$this->columnHeight*2,"Name of Board/\nUniversity",1,1,'C');
        $pd->SetFont("Times",'B',10);
        $pd->Cell($this->columnWidth,$this->columnHeight,"S.S.C (Matriculation)",1,0);
        $pd->SetFont("Times",'',10);
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$sscInfo[0]['group_name'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$sscInfo[0]['marks_obtained'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$sscInfo[0]['total_marks'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$sscInfo[0]['passing_year'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$sscInfo[0]['seat_no'],1,0,'C');
        $pd->Cell(0,$this->columnHeight,"".$sscInfo[0]['issuer_name'],1,1,'C');
        $pd->SetFont("Times",'B',10);
        $pd->Cell($this->columnWidth,$this->columnHeight,"H.S.C (Intermediate)",1,0);
        $pd->SetFont("Times",'',10);
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$hscInfo[0]['group_name'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$hscInfo[0]['marks_obtained'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$hscInfo[0]['total_marks'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$hscInfo[0]['passing_year'],1,0,'C');
        $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$hscInfo[0]['seat_no'],1,0,'C');
        $pd->Cell(0,$this->columnHeight,"".$hscInfo[0]['issuer_name'],1,1,'C');
        if($bean->getProgramTypeId() == Variable::$MASTER_ID){
            $pd->Cell($this->columnWidth,$this->columnHeight,"Graduation (Bachelor Degree)",1,0);
            $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$grdInfo[0]['group_name'],1,0,'C');
            $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$grdInfo[0]['marks_obtained'],1,0,'C');
            $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$grdInfo[0]['total_marks'],1,0,'C');
            $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$grdInfo[0]['passing_year'],1,0,'C');
            $pd->Cell($this->columnWidth/3,$this->columnHeight,"".$grdInfo[0]['seat_no'],1,0,'C');
            $pd->Cell(0,$this->columnHeight,"".$grdInfo[0]['issuer_name'],1,1,'C');
            $countOptional = count($optionals);
            if($countOptional>0){
                $pd->Cell($this->columnWidth,$this->columnHeight,"Optional Subjects",1,0);
                $optionString = "";
                for($i=0;$i<$countOptional;$i++){
                    $nam = $optionals[$i]['name'];
                    $optionString .= (($i+1).".".$nam."  --  ");
                }
                $pd->Cell(0,$this->columnHeight,$optionString,1,1);
            }
        }
        $pd->Ln(2);
        $pd->SetFont("Times",'B',10);
        $pd->Cell(0,$this->columnHeight,"Bank Challan Information",0,1);
        $pd->SetFont("Times",'',10);
        $pd->Cell($this->columnWidth,$this->columnHeight,"Paid Amount",1,0);
         $pd->Cell(0,$this->columnHeight,"".Variable::$FORM_RUPEES."/=",1,1,'L');
         $pd->Cell($this->columnWidth,$this->columnHeight,"Bank Challan No.",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bean->getChallanNo(),1,1,'L');
          
$pd->Cell($this->columnWidth,$this->columnHeight,"Date of Payment",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bean->getChallanDate(),1,1,'L');
          $pd->Cell($this->columnWidth,$this->columnHeight,"HBL Branch",1,0);
         $pd->Cell(0,$this->columnHeight,"".$bankName[0]['name'],1,1,'L');
           
        //$pd->SetXY(50, 240);
        $pd->Ln(5);

        
        $pd->SetFont("Times",'',10);
        $pd->Cell(0,$this->columnHeight,"Note: If any applicant submitted forged / fake documents (detected at any stage) his / her admission shall be cancelled and paid fees  ",0,1);
        $pd->Cell(0,$this->columnHeight,"will not be refunded.",0,1);
        $pd->Ln(5);
        $pd->SetFont("Times",'B',10);
        $pd->Cell(0,$this->columnHeight,"UNDERTAKING",0,1,'C');
         $pd->SetFont("Times",'',10);
        $pd->Cell(0,$this->columnHeight,"I do hereby state that all information and data given by me as above is true and correct and shall always be binding to me and ",0,1);
         $pd->Cell(0,$this->columnHeight,"undertake to abide all provisions of act, statutes, rules and regulations of the University.",0,1);
        
        $pd->Ln(8);
        $pd->SetFont("Times",'B',8);
        $myDateTime= DateTime::createFromFormat('Y-m-d H:i:s',$bean->getDateOfSumbitForm());

        
        $newDateString = $myDateTime->format('d-m-Y H:i:s');

        $pd->SetFont("Times",'',8);
        $pd->SetXY(10, 270);
        $pd->Cell(0,$this->columnHeight,$newDateString,0,0);

        $pd->SetFont("Times",'B',10);
        $pd->SetXY(160, 270);
        $pd->Cell(0,$this->columnHeight," Signature of the applicant",0,0);
         $pd->SetFont("Times",'',8);
        $pd->SetXY(100, 270);
        $pd->Cell(0,$this->columnHeight," Page 1 of 2",0,0);
       


       $pd->AddPage();
       $pd->Image(ASSET_PATH.'images/logo.png',90,10,25,25);
      // $pd->Image($this->candidateImage,($wid-35),5,22,25);
                $pd->SetXY(10, 45);
        $pd->SetFillColor(0,0,0);
       $pd->SetFont("Arial",'B',20);
        $pd->Cell(0,$this->columnHeight,"University of Sindh, Jamshoro ",0,1,'C',false);
        $pd->Ln(1);
        $pd->SetFont("Times",'',12);
        $pd->Cell(0,$this->columnHeight,"ONLINE ADMISSION FORM - ".Variable::$SESSION_YEAR,0,1,'C',false);
        
        $pd->Ln(4);
        $pd->SetFont("Times",'',14);
        $pd->Cell(0,$this->columnHeight,"(".$this->degreeProgram.")
",0,1,'C',false);

             
        
       
       $pd->Ln(2);
       // $pd->SetFont("Times",'',10);
        $pd->Cell(0,$this->columnHeight,"Candidate's Online Registration No. ".$this->candidateId,0,1);      
        


       $pd->Ln(2);
        $pd->SetFont("Times",'BU',10);
        $pd->Cell(0,$this->columnHeight,"Applied Choices",0,1);      
        $pd->SetFont("Times",'B',10);

        $morningLine = 1;

     //Loop for display choices
        $mcSize = count($morningChoices);
        if($mcSize>0){
        $pd->Cell( ($wid/2)-10 ,$this->columnHeight,"SUBJECTS / DISCIPLINES (MORNING)",1,1);

        $pd->SetFont("Times",'',8);

    for($i=0;$i<$mcSize;$i++) {
        if ($i < $mcSize) {
           $pd->Cell(($wid / 2) - 10, $this->columnHeight, (($i + 1) . ". " . $morningChoices[$i]['name']), 1, $morningLine);
     }
    }
        }
        if($bean->getProgramTypeId() == Variable::$MASTER_ID){
            $pd->SetXY(110, 197);

        }else{
            $pd->SetXY(110, 197);
        }



        $ecSize = count($eveningChoices);
        if($ecSize> 0) {
            $pd->SetXY(110, 76);
            $pd->SetFont("Times", 'B', 10);
            $pd->Cell(0, $this->columnHeight, "SUBJECTS / DISCIPLINES (EVENING)", 1, 1);
            $pd->SetFont("Times", '', 8);

            if($bean->getProgramTypeId() == Variable::$MASTER_ID){
                $y=76;

            }else{
                $y = 76;
            }


            for ($i = 0; $i < $ecSize; $i++) {
                $y = $y + 5;
                $pd->SetXY(110, $y);
                if ($i < $ecSize) {
                    $pd->Cell(0, $this->columnHeight, (($i + 1) . ". " . $eveningChoices[$i]['name']), 1, $morningLine);
                }
            }

        }

$pd->Ln(2);

        $pd->SetXY(10, 200);
        $pd->SetFont("Times",'',10);
        $pd->Cell(0,$this->columnHeight,"Note: If any applicant submitted forged / fake documents (detected at any stage) his / her admission shall be cancelled and paid fees  ",0,1);
        $pd->Cell(0,$this->columnHeight,"will not be refunded.",0,1);
        $pd->Ln(5);
        $pd->SetFont("Times",'B',10);
        $pd->Cell(0,$this->columnHeight,"UNDERTAKING",0,1,'C');
         $pd->SetFont("Times",'',10);
        $pd->Cell(0,$this->columnHeight,"I do hereby state that all information and data given by me as above is true and correct and shall always be binding to me and ",0,1);
         $pd->Cell(0,$this->columnHeight,"undertake to abide all provisions of act, statutes, rules and regulations of the University.",0,1);


             
       
        $pd->Ln(8);
        $pd->SetFont("Times",'B',8);
        $myDateTime= DateTime::createFromFormat('Y-m-d H:i:s',$bean->getDateOfSumbitForm());

        
        $newDateString = $myDateTime->format('d-m-Y H:i:s');

        $pd->SetFont("Times",'',8);
        $pd->SetXY(10, 270);
        $pd->Cell(0,$this->columnHeight,$newDateString,0,0);
        $pd->SetFont("Times",'B',12);
        $pd->SetXY(10, 260);
        $pd->Cell(0,$this->columnHeight," Director/ Chairperson",0,0);
         $pd->SetXY(10, 264);
        $pd->Cell(0,$this->columnHeight," Centre/ Institute/ Department",0,0);
       $pd->SetFont("Times",'B',10);
        $pd->SetXY(160, 250);
        $pd->Cell(0,$this->columnHeight," Signature of the applicant",0,0);
        $pd->SetFont("Times",'',8);
        $pd->SetXY(100, 270);
        $pd->Cell(0,$this->columnHeight," Page 2 of 2",0,0);
      
       
       // $pd->ob_clean();//add this line
        $pd->Output($this->candidateId.".pdf",'I');
        //$pd->Output();
    }
}

?>
