<!DOCTYPE html>
<html>
<head>

</script>

	   <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta name="description" content="bootstrap admin template">
	<title>Directorate of Admissions</title>

          <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap-theme.min.css">

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 

        <link rel="stylesheet" href="http://admission.usindh.edu.pk/assets/pos_assets/css/site.min.css">

        <script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "1ddaacf6-19c4-4c1c-80dd-3f5eeb93c1f2",
    });
  });
</script>
</head>

<style type="text/css">
	
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: pink;
}
::-moz-placeholder { /* Firefox 19+ */
  color: pink;
}
:-ms-input-placeholder { /* IE 10+ */
  color: pink;
}
:-moz-placeholder { /* Firefox 18- */
  color: pink;
}

.layout-full .page
{
    background-color: transparent;
}

.page-dark.layout-full:before {
    position: fixed;
    top: 0;
    left: 0;
    z-index: -1;
    width: 100%;
    height: 100%;
    content: '';
    background-position: center top;
    -webkit-background-size: cover;
    background-size: cover;
}

.posinfopara{
    color: #fff;
    opacity: 1 !important;
    font-weight: 400;
    font-family: 'Open Sans', sans-serif;
}
#logout_btn {
    padding: 15px;
    position: absolute;
    right: 30px;
    top: 25px;
    border-radius: 50%;
    background-size: contain;
    background-image:  url(../image/close_btn.png);
    background-repeat: no-repeat;
    opacity: 0.5;
}
.watermarkogo
{
    width: 30%;
    height: 30%;
    overflow: hidden;
    position: absolute;
    left: 35%;
    top: 35%;
	text-align: center;
    /* padding-bottom: 7%; */
}
.posloginInput{
        border: 0;
    border-bottom: 1px solid #929191;
    background: none;
    font-weight: 400;
    padding-left: 24px;
    font-family: 'Open Sans', sans-serif;
    box-shadow: none !important;
    border-radius: 0;
}
.faloginBeta{
    position: absolute;
    top: 10px;
    font-size: 16px;
}
.page-login-v2 {
  height: 100%;
}
.page-login-v2:before {
  background-image: url("http://admission.usindh.edu.pk/assets/images/7-10.jpg");
 
}
.page-login-v2:after {
  background-color: rgba(38, 50, 56, .6) !important;
}
.page-login-v2 .page-brand-info {
  margin: 220px 100px 0 90px;
}
.page-login-v2 .page-brand-info .brand-img {
  vertical-align: middle;
}
.page-login-v2 .page-brand-info .brand-text {
  display: inline-block;
  margin: 11px 0 11px 20px;
  vertical-align: middle;
}
.page-login-v2 .page-brand-info p {
  max-width: 650px;
  opacity: .6;
}
.page-login-v2 .page-login-main {
  position: absolute;
  top: 0;
  right: 0;
  height: auto;
  min-height: 100%;
  padding: 150px 60px 180px;
  color: #76838f;
  background: rgba(255, 255, 255, 0.77);
}
.page-login-v2 .page-login-main .brand {
  margin-bottom: 60px;
}
.page-login-v2 .page-login-main .brand-img {
  vertical-align: middle;
}
.page-login-v2 .page-login-main .brand-text {
  display: inline-block;
  margin: 11px 0 11px 20px;
  color: #62a8ea;
  vertical-align: middle;
}
.page-login-v2 form {
  width: 350px;
  margin: 40px 0 20px;
}
.page-login-v2 form > button {
    margin-top: 40px;
    font-weight: 400;
    font-family: 'Open Sans', sans-serif;
    font-size: 16px;
}
.page-login-v2 form a {
  margin-left: 20px;
}
.page-login-v2 footer {
  position: absolute;
  bottom: 0;
  left: 50%;
  height: 100px;
  margin: 50px 0;
  text-align: center;
  -webkit-transform: translate(-50%, 0px);
      -ms-transform: translate(-50%, 0px);
       -o-transform: translate(-50%, 0px);
          transform: translate(-50%, 0px);
}
.page-login-v2 .social .icon,
.page-login-v2 .social .icon:hover,
.page-login-v2 .social .icon:active {
  color: #fff;
}
@media (min-width: 992px) {
  .page-login-v2 .page-content {
    padding-right: 500px;
  }
}
@media (max-width: 768px) {
  .page-login-v2 .page-login-main {
    padding-top: 60px;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .page-login-v2 .page-login-main {
    padding-top: 80px;
  }
  .page-login-v2 .page-brand-info {
    margin: 160px 0 0 35px;
  }
  .page-login-v2 .page-brand-info > p {
    color: transparent;
    opacity: 0;
  }
}
@media (max-width: 767px) {
  .page-login-v2 .page-login-main {
    width: 100%;
    padding-top: 60px;
  }
  .page-login-v2 form {
    width: auto;
  }
  .brand{
    display: none;
  }

  .page-content-custom
{
    padding: 0;
    height: 100%;
}

.page-login-main-custom
{
   position: inherit !important;
}

}
@media (max-width: 480px) {
  .page-login-v2 .page-login-main {
    padding: 50px 30px 180px;
  }
  .page-login-v2 form {
    width: auto;
  }
}

.navbar-custom
{
   padding-left: 0;
}

.navbar-custom li
{
	display: inline;
	padding: 20px;
}

.navbar-custom li a
{
	color: #fff;
	text-decoration: none;
	cursor: pointer;
	font-weight: 400;
    padding-left: 14px;
    font-family: 'Open Sans', sans-serif;
}

.navbar-default-custom
{
    background: none !important;
    border: none !important;
    z-index: 999999 !important;
    box-shadow: none !important;
}

.navbar-nav-custom li a
{
    box-shadow: none !important;
    background: none !important;
    color: #fff !important;
        font-family: 'Open Sans', sans-serif;
}

.navbar-nav-custom
{
    margin-top: 40px !important;
}

.dropdown-menu-custom li a
{
    color: #565656 !important;
    font-family: 'Open Sans', sans-serif;
}

.navbar-default-custom-two
{
   display: none;
}

.nav.navbar-nav.navbar-nav-custom
{
       margin-top: inherit !important;
    width: 100%;
}

input:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 30px #d5d8db inset !important;
}

</style>

<body class="page-login-v2 page-dark layout-full">

<div class="page">
    <div class="page-content page-content-custom">
     <div class="col-md-12 col-sm-6 col-xs-12" style="padding-left: 0;padding-right: 0;">

      <nav class="navbar navbar-default navbar-default-custom" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header" style="width: 100%;text-align: center;">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" style="float: none;" href="#"><img class="brand-img" src="http://admission.usindh.edu.pk/stuff/Header-Logo2.png" alt="..."></a>
        </div>


        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding: 0;">
          <ul class="nav navbar-nav navbar-nav-custom">
            <li class="">
              <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Fees-Structure-2019.pdf" class="" data-toggle="">Fees Structure <b class="caret"></b></a>
             
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Distribution of Seats <b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Distribution-of-Allocated-Seats-For-Bachelor-Degree-Programs.pdf">Bachelor</a></li>
                <li class="divider"></li>
        <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Distribution-of-Allocated-Seats-for-Master-Degree-Program.pdf">Master</a></li>
        <li class="divider"></li>
        <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Seat-Distribution-faculty-education.pdf">Faculty of Education</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">How to fill admission form<b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/instructions.pdf">Instructions In English</a></li>
                <li class="divider"></li>
        <li><a  target="_blank" href="http://admission.usindh.edu.pk/stuff/instructionsurdu.pdf">Instructions in Sindhi / Urdu</a> </li>

        
        
              </ul>
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">HBL Branches<b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/LIST OF HBL BRANCHES.pdf">List Of HBL Branches</a></li>

                      
                        
            <!--<li><a href="http://admission.usindh.edu.pk/assets//pdf/USER_GUIDE.pdf">User Guide</a></li>-->

          </ul></li>

             <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admission Form Fees Challan<b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Bank_Challan_2019_new.pdf">Admission Form Fees Challan</a></li>

                      
                        
            <!--<li><a href="http://admission.usindh.edu.pk/assets//pdf/USER_GUIDE.pdf">User Guide</a></li>-->

          </ul></li>

           <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Prospectus 2019<b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a target="_blank" href="http://admission.usindh.edu.pk/stuff/Prospectus 2019 (Complete) colour.pdf">Prospectus 2019</a></li>

                      
                        
            <!--<li><a href="http://admission.usindh.edu.pk/assets//pdf/USER_GUIDE.pdf">User Guide</a></li>-->

          </ul></li>

        </div><!-- /.navbar-collapse -->
      </nav>
       <h5 style=" 
    line-height: 1.6;
   
    font-size: 18px;
    padding: 15px">
     <b style="color: red"> Important Notifictions:</b></br>
          1. Pre-Entry Test date for Master Degree Programs has been extended and now it will be held on 4th November 2018.</br>
          2. Last date for registration/ submission of Online Admission forms for Master Degree Programs is 01.11.2018 </br>
          Admit Cards Generation for Master Degree Programs has been disabled temporarily and will be available online on 2nd and 3rd November 2018.</br>



    </h5>
      
   
        <h5>How to fill a admission a form</h5>
        <!-- <img style="width: 775px;margin-left: 10px;" src="http://admission.usindh.edu.pk/stuff/urdutext.PNG"/> -->
        <video style="border: 1px dashed" width="800" height="400" controls>
  				<source src="http://admission.usindh.edu.pk/stuff/admissions2019.mp4" type="video/mp4">
 
			</video>
     

      </div>
      <div class="page-login-main page-login-main-custom">


        <!-- <div class="brand visible-xs">
          <img class="brand-img" src="http://usindh.edu.pk/wp-content/uploads/2017/02/Header-Logo2.png" alt="...">
        </div> -->
        <h5 class="font-size-24" style="font-family: 'Open Sans', sans-serif;color: #565656;">ONLINE REGISTRATION FORM LOGIN</br>
(Please do not use a Cell Phone for Registration)</h5>
        <p style="font-weight: 400;font-family: 'Open Sans', sans-serif;color: #565656;"></p>
        <!-- <form method="post" action="http://admission.usindh.edu.pk/index.php/app_form/login_process"> -->
          <?php echo form_open($request_submit);?>
          <div class="form-group" style="position: relative;">
            <label class="sr-only" for="inputEmail">User Name</label>
            <i class="fa fa-user-circle-o faloginBeta" aria-hidden="true"></i>
            <input type="text" class="form-control posloginInput" id="inputEmail" name="<?php echo Variable::USERNAME();?>" placeholder="Username">
          </div>
          <div class="form-group" style="position: relative;">
            <label class="sr-only" for="inputPassword">Password</label>
            <i class="fa fa-lock faloginBeta" aria-hidden="true"></i>
            <input type="password" class="form-control posloginInput" id="<?php echo Variable::PASSWORD();?>" name="password"
            placeholder="Password">
          </div>
          <div class="form-group clearfix" style="display: none">
            <div class="checkbox-custom checkbox-inline checkbox-primary pull-left">
              <input type="checkbox" id="remember" name="checkbox">
              <label for="inputCheckbox">Remember me</label>
            </div>

            
           
          </div><br>
              <div class="g-recaptcha" data-sitekey="6LdXTmYUAAAAAK-_j1W5bO6fg-IDVrc63vlYpLCs"></div>
          <button type="submit" class="btn btn-primary btn-block" id="login_btn">Login</button>
          <br>
          <div style="width:351px;height: 570px;border: 1px solid;padding: 10px;">
          
             <b style="color: red"> Important Instructions regarding online registration.</b></br>
              1. Registration from Cell Phone is not allowed.</br>Use a PC or Laptop.</br>
              2. Please use the latest version of Google Chrome or Firefox Browser.</br>
              3. Please make sure that you have selected I am not a Robot Security Check. </br>
              4. Please login with your username and password, after a blue check mark appears when you complete I am not a Robot.</br>
              5. If there are any technical issues with the registration, send a message on the given WhatsApp number with your Username and </br>Password alongwith a description of your problem.  </br>

              <b style="color: red">If you are facing any technical problem please contact office of the Web Administrator at:</b></br>
              Tel. No. (Office) 022-9213-217</br>
              WhatsApp No. 0300-837-0101 </br>
              (WhatsApp Messages only with Username & Password & Problem Description)</br>
              Email: info@usindh.edu.pk/br></br>

             <b style="color: red"> If your query is related to General Admission Issues, please contact:</b></br>
              Directorate of Admissions at:</br>
              Tel. No. (Office) : 022-9213-166</br>
              Tel. No. (Office) : 022-9213-199</br>
              Email: dir.adms@usindh.edu.pk </br>
            


          
          </div>
          
        <?php echo form_close("");?>
        
      </div>
    </div>
  </div>
  <script src='https://www.google.com/recaptcha/api.js'></script>
</body>
</html>

<script src="http://admission.usindh.edu.pk/assets/js/jquery-1.11.2.min.js"></script>
<script src="http://exam.usindh.edu.pk/scripts/jquery-ui.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>