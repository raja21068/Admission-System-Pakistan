<!-- Footer Start -->
         <footer id="footer">
            <!-- Footer Top Start -->
            <div class="footer-top">
               <div class="container">
                  <div class="row">
                     <section class="col-lg-6 col-md-6 col-xs-12 col-sm-6 footer-one">
                        <h3>About</h3>
                        <p> 
                         Research & Graduate Studies, University of Sindh, Jamshoro
                        </p>
                     </section>
                     <section class="col-lg-6 col-md-6 col-xs-12 col-sm-6 footer-three">
                        <h3>Contact Us</h3>
                        <ul class="contact-us">
                           <li>
                              <i class="fa fa-map-marker"></i>
                              <p> 
                                 <strong>Address:</strong>Research & Graduate Studies, Ghulam Mustafa Shah Administration Building, University of Sindh, Jamshoro
                              </p>
                           </li>
                           <li>
                              <i class="fa fa-phone"></i>
                              <p><strong>Phone:</strong>Phone: +92-22-9213233
                                </p>
                           </li>
                           <li>
                              <i class="fa fa-envelope"></i>
                              <p><strong>Email:</strong><a href="mailto:director.rgs@usindh.edu.pk">director.rgs@usindh.edu.pk</a></p>
                           </li>
                        </ul>
                     </section>
                  </div>
               </div>
            </div>
            <!-- Footer Top End --> 
            <!-- Footer Bottom Start -->
            <!-- <div class="footer-bottom">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 "> &copy; Copyright 2013 by <a href="#">Pixma</a>. All Rights Reserved. </div>
                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 ">
                        <ul class="social social-icons-footer-bottom">
                           <li class="facebook"><a href="#" data-toggle="tooltip" title="Facebook"><i class="icon-facebook"></i></a></li>
                           <li class="twitter"><a href="#" data-toggle="tooltip" title="Twitter"><i class="icon-twitter"></i></a></li>
                           <li class="dribbble"><a href="#" data-toggle="tooltip" title="Dribble"><i class="icon-dribbble"></i></a></li>
                           <li class="linkedin"><a href="#" data-toggle="tooltip" title="LinkedIn"><i class="icon-linkedin"></i></a></li>
                           <li class="rss"><a href="#" data-toggle="tooltip" title="Rss"><i class="icon-rss"></i></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div> -->
            <!-- Footer Bottom End --> 
         </footer>
         <!-- Scroll To Top --> 
         <a href="#" class="scrollup"><i class="fa fa-angle-up"></i></a>
      </div>
      <!-- Wrap End -->
      <!-- The Scripts -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

      <script src="<?php echo base_url('htaccess/js/jquery.min.js');?>"></script>
      <script src="http://dev.appon.io/global/vendor/switchery/switchery.min.js"></script>
      <script src="<?php echo base_url('htaccess/js/bootstrap.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jquery.parallax.js');?>"></script> 
      <script src="<?php echo base_url('htaccess/js/modernizr-2.6.2.min.js');?>"></script> 
      <script src="<?php echo base_url('htaccess/js/revolution-slider/js/jquery.themepunch.revolution.min.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jquery.nivo.slider.pack.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jquery.prettyPhoto.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/superfish.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/tweetMachine.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/tytabs.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jquery.sticky.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jflickrfeed.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/imagesloaded.pkgd.min.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/waypoints.min.js');?>"></script>
      <script src="<?php echo base_url('htaccess/js/jquery.gmap.min.js');?>"></script>
      <!--<script src="<?php //echo base_url('htaccess/js/custom.js');?>"></script>-->
      <script src="<?php echo base_url('htaccess/css/bootstrap-datepicker/bootstrap-datepicker.js');?>"></script>
      <script type="text/javascript" src="http://dev.appon.io/global/vendor/bootstrap-select/bootstrap-select.js"></script>
      <script type="text/javascript" src="http://dev.appon.io/global/js/components/bootstrap-select.js"></script>
      <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyCDDxrkCbgTanKiH_AF5cNPlyyTEcwOtrc"></script>
      <script src="<?php echo base_url('htaccess/js/dgrs.js');?>"></script>
      <script type='text/javascript'>
    function init_map()
    {   var myOptions = {
            zoom:10,
            center:new google.maps.LatLng(25.419918,68.265331),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        
        map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
        marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(25.419918,68.265331)});
        infowindow = new google.maps.InfoWindow({content:'<strong>University of Sindh (Main Campus), Jamshoro</strong>'});
        google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);
    }
    google.maps.event.addDomListener(window, 'load', init_map);

</script>
<script type="text/javascript">
  $('.datepicker').datepicker(
 {
  mode      : "default",
  format    : 'yyyy-mm-dd',
  autoclose : true,
  endDate: '+0d'
});
$('.selectpicker').selectpicker(  
      {
          style: "btn-select",
          iconBase: "icon",
          tickIcon: "wb-check"
      });
$(".ETswitchery").each(function(index, element)
    {
      var init = new Switchery(element, { color: '#62a8ea' });
      init = null;
    });

jQuery('.testimonials-carousel').carousel({interval: 5000, pause: "hover"});
</script>
</body>
</html>


