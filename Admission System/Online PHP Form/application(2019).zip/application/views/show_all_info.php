<?php $this->load->library("variable");?>
<div id="content">
    <!-- Page Content -->
    <div class="page-content">
        <div class="container">



            <div class="text-danger">
                    
                
                 <p><b>Please recheck all the details given below before generating your slip, in case of any mistakes go to previous steps and fix it.
Once the slip is generated then details cannot be editable. Candidates those are applying for Masters Degree Program must select a valid Group before generating their slip. </br>
<a href="http://admission.usindh.edu.pk/stuff/MasterGroupInfo.pdf" target="_blank">Click here</a> to get help document to find valid Group according to your details. </b></p>
                 
            </div>
            <div class="row">
                <div class="col-md-10" >
                <table class='table table-striped'>
                    <tr>
                        <td >Candidate Online Registration No:</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getCandidateId(); ?></strong></td>
                    </tr>
                    <tr class='success'>
                        <td colspan="2" ><strong>Personal Information</strong></td>
                    </tr>
                    <tr>
                        <td >Applying For:</td>
                        <td ><strong class='text-info'><?php if($candidateBean->getProgramTypeId() == Variable::$MASTER_ID){echo "MASTER";}else{echo "BACHELOR";} ?></strong></td>
                    </tr>
                    <tr>
                        <td >Name:</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getName(); ?></strong></td>
                    </tr>
                    <tr>
                        <td >Father's Name:</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getFathersName(); ?></strong></td>
                    </tr>
                    <tr>
                        <td >Surname:</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getSurname();?></strong></td>
                    </tr>
                    <tr>
                        <td >Gender</td>
                        <td ><strong class='text-info'><?php if($candidateBean->getGender() == 0){echo "MALE";}else{echo "FEMALE";} ?></strong></td>
                    </tr>
                    <tr>
                        <td >CNIC No.</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getCnic();?></strong></td>
                    </tr>
                    <tr>
                        <td >Date of Birth</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getDateOfBirth();?></strong></td>
                    </tr>
                    <tr>
                        <td >Religion</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getReligionName();?></strong></td>
                    </tr>
<!--                    <tr>-->
<!--                        <td >Place of Birth</td>-->
<!--                        <td ><strong class='text-info'>--><?php //echo $candidateBean->getPlaceOfBirth();?><!--</strong></td>-->
<!--                    </tr>-->
                    <tr>
                        <td >District</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getDistrictName();?></strong></td>
                    </tr>
                    <tr>
                        <td >Area</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getAreaCode();?></strong></td>
                    </tr>
                    <tr>
                        <td >Telephone</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getTelephone();?></strong></td>
                    </tr>
                    <tr>
                        <td >Mobile</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getMobile();?></strong></td>
                    </tr>
                    <tr>
                        <td >Email</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getEmail();?></strong></td>
                    </tr>
                    <tr>
                        <td >Postal Address</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getPostalAddr();?></strong></td>
                    </tr>
                    <tr>
                        <td >Permanent Address</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getPermenentAddr();?></strong></td>
                    </tr>
                    <tr class='success'>
                        <td colspan="2" ><strong>Guardian's Information</strong></td>
                    </tr>
                    <tr>
                        <td >Guardian's Name</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getGurdianName();?></strong></td>
                    </tr>
                    <tr>
                        <td >Father's / Guardian's Occupation</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getOccupation();?></strong></td>
                    </tr>
                    <tr>
                        <td >Guardian's Address</td>
                        <td ><strong class='text-info'><?php echo $candidateBean->getGuardianAddr();?></strong></td>
                    </tr>
                    <tr class='success'>
                        <td colspan="2" ><strong>Education</strong></td>
                    </tr>
                </table>
                </div>
                <div class="col-md-2" ></div>
            </div>
            <div class="row">
                <div class="col-md-10">
                <table class="table table-bordered">
                    <tr>
                        <td><strong>Qualification</strong></td>
                        <td><strong>Group</strong></td>
                        <td><strong>Total Marks</strong></td>
                        <td><strong>Marks Obtained</strong></td>
                        <td><strong>Year</strong></td>
                        <td><strong>Seat No</strong></td>
                        <td><strong>Board / University</strong></td>
                    </tr>
                    <tr>
                        <td>S.S.C </td>
                        <td><?php echo $cred->getGroupName();?></td>
                        <td><?php echo $cred->getTotalMarks();?></td>
                        <td><?php echo $cred->getObtainMarks();?></td>
                        <td><?php echo $cred->getPassingYear();?></td>
                        <td><?php echo $cred->getSeatNo();?></td>
                        <td><?php echo $cred->getIssuerName();?></td>
                    </tr>
                    <tr>
                        <td>H.S.C</td>
                        <td><?php echo $credHsc->getGroupName();?></td>
                        <td><?php echo $credHsc->getTotalMarks();?></td>
                        <td><?php echo $credHsc->getObtainMarks();?></td>
                        <td><?php echo $credHsc->getPassingYear();?></td>
                        <td><?php echo $credHsc->getSeatNo();?></td>
                        <td><?php echo $credHsc->getIssuerName();?></td>
                    </tr>
                    <?php if( $candidateBean->getProgramTypeId() == Variable::$MASTER_ID ){
                        ?>
                        <tr>
                            <td>Graduation</td>
                            <td><?php echo $credGrd->getGroupName();?></td>
                            <td><?php echo $credGrd->getTotalMarks();?></td>
                            <td><?php echo $credGrd->getObtainMarks();?></td>
                            <td><?php echo $credGrd->getPassingYear();?></td>
                            <td><?php echo $credGrd->getSeatNo();?></td>
                            <td><?php echo $credGrd->getIssuerName();?></td>
                        </tr>
                        <?php
                        $optionsSize = count($optionals);
                        if($optionsSize >0){
                            $optionString = "";
                            for($i=0;$i<$optionsSize;$i++){
                                $nam = $optionals[$i]['name'];
                                $optionString .= (($i+1).".".$nam."  --  ");
                            }
                            ?>
                            <tr>
                                <td>Optional Subjects</td>
                                <td colspan="6"><?php echo $optionString;?></td>
                            </tr>
                            <?php
                        }
                    }?>
                </table>

            </div>
        </div>

            <div class="row">
                <div class="col-md-10" >
                    <table class="table table-striped table-bordered">
                    <?php if(count($campusList)>0){
                        $campus = $campusList[0]['name'];
                        ?>
                        <tr>
                            <td>Applied Campus</td>
                            <td><?php echo $campus;?></td>
                        </tr>
                        <?php
                    }
                    ?>

                    <?php
                        $ac = "";
                        for($i=0;$i<count($appliedCats);$i++){
                            if($i == count($appliedCats)-1){
                                $ac.=Variable::$CategoryEnumDesc[$appliedCats[$i]['code']];
                            }else{
                                $ac.= (Variable::$CategoryEnumDesc[$appliedCats[$i]['code']].",");
                            }
                        }
                        ?>
                        <tr>
                            <td>Applied Category(ies)</td>
                            <td><?php echo $ac;?></td>

                        </tr>

                </table>
                </div>
            </div>

            <div class="row">
                <div class="col-md-10" >
                <?php
                $mcSize = count($morningChoices);
                echo "<table class='table table-striped'>";
                if($mcSize>0){
                    echo "<tr class='success'>
                    <td><strong>#</strong></td>
                    <td><strong>Morning Choices</strong></td>
                </tr>";
                for($i=0;$i<$mcSize;$i++){
                    echo "<tr><td>".($i+1)."</td>";
                    echo "<td>".$morningChoices[$i]['name']."</td></tr>";
                }
            }
            ?>


            <?php
            $ecSize = count($eveningChoices);
            if($ecSize>0){
                echo "<tr class='success'>
                    <td><strong>#</strong></td>
                    <td><strong>Evening Choices</strong></td>
                </tr>";
                for($i=0;$i<$ecSize;$i++){
                    echo "<tr><td>".($i+1)."</td>";
                    echo "<td>".$eveningChoices[$i]['name']."</td></tr>";
                }
            }
                echo "</table>";

                ?>
        </div>
            </div>

             <div class="col-md-10" style="padding:10px;border: 2px dashed red">
                <?php $attributes = array('class' => 'kdd', 'target' => '_blank');
                 echo form_open_multipart('slip_admin/print_candidate_modified',$attributes);?>
                 <table class="table table-striped table-bordered">

                     <tr><td class="text-danger" colspan="2">
                        <b>Please recheck all the details given below before generating your slip, in case of any mistakes go to previous steps and fix it.
Once the slip is generated then details cannot be editable.</b>
                    </td>
                        <tr>

                   <?php if($candidateBean->getProgramTypeId() == Variable::$MASTER_ID)
                   {?>
                    <tr><td class="text-danger" colspan="2">
                        
                       <b> Important Note Only for the candidates of Master Degree Programs:</br>

All the students are advised to be careful in selecting the group of discipline in online application form. Once submitted, the computerized roll number is generated and their enrollment will be considered in their group of disciplines only. No any excuse will be entertained in this regard.<a href="http://admission.usindh.edu.pk/stuff/MasterGroupInfo.pdf" target="_blank">Click here</a> to get help document to find valid Group according to your details.</br>Candidates those are applying for Bachelor Degree Programs they don't need to select a Group.</b>
                    </td></tr>
                     <tr>
                            <td>Select Group</td>
                            <td><select name="group">
                                <option value="2"> GROUP 1 - ARTS AND SOCIAL SCIENCES GROUP </option>
                                <option value="4"> GROUP 2 - MEDICAL/ BIOLOGICAL GROUP </option>
                                <option value="6"> GROUP 3 - ENGINEERING GROUP </option>
                                <option value="8"> GROUP 4 - COMMERCE GROUP </option>
                                <option value="10"> GROUP 5 - COMPUTER SCIENCE GROUP </option>
                                <option value="12"> GROUP 6 - LAW GROUP </option>
                                <option value="14"> GROUP 7 - EDUCATION GROUP </option>
                                </select></td>
                        </tr>
                    <? }?>


                           <tr> 
                            <td> <?php
            
            echo "<a class='btn btn-success' style='color:white;' href='/app_form/".Variable::$PRINT_FORM."' target='_blank'>Print Form</a>";
          
            ?></td>
                            <?php if($candidateBean->getProgramTypeId() != Variable::$MASTER_ID)
                            {?>
                            <td> <input type="submit" value="Generate Slip For Pre-Entry Test" name="subfrm"></td>
                            <?php } ?>

                        </tr>
                 </table>
                 
                   
                <?php echo form_close(); ?>
                
            </div>



            <div class="col-md-10">

                <div class="text-info">
                    <p>Please use PDF Reader for downloading / printing your form. You can download Adobe Acrobat Reader here. </p>
                    <a href="http://ardownload.adobe.com/pub/adobe/reader/win/9.x/9.1/enu/AdbeRdr910_en_US.exe" > <img style="margin: 2%" src="<?Php echo ASSET_PATH; ?>/images/download_En.jpg"> </a>
                </div>
            </div>

        <div class="col-md-4">
            <?php if(!$is_slip_issued || $admin=="superUser"){?>
                <a href="<?php echo Variable::$GOTO_TAB_APPLY_FOR;?>?<?php echo Variable::$REQUEST;?>=<?php echo Variable::$TAB_PERSONAL;?>" class="btn btn-default"><i class="glyphicon glyphicon-arrow-left"></i> <?php echo Variable::$PREVIOUS;?></a>
                <br/>
               
                <?php } ?>
        </div>
        <div class="col-md-4">
              
                    

               
           
               
        </div>

        <div class="col-md-4">
            <?php
            
            echo "<a class='btn btn-success' style='color:white;' href='/app_form/".Variable::$PRINT_FORM."' target='_blank'>Print Form</a>";
          
            ?>
        </div>

       

        </div>
        
       
        
</br></br>
        </div>
</div>

<script type="text/javascript">
    $('document').ready(function(){

     $('.btnslip').on('click',function(){

     
        alert('Your Data is in the verification process once verification process is completed you can download you slip. (For Master Candidates Only).')

     });

    });


</script>