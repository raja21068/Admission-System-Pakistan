<body class="page">
      <div class="wrap">
         <!-- Header Start -->
         <header id="header">
            <!-- Header Top Bar Start -->
            <div class="top-bar">
               <div class="slidedown collapse">
                  <div class="container">
                     <div class="phone-email pull-left">
                        <a><i class="fa fa-phone"></i> Call Us : +92-22-9213233</a>
                        <a href="director.rgs@usindh.edu.pk"><i class="fa fa-envelope"></i> Email : director.rgs@usindh.edu.pk</a>
                     </div>
                     <div class="pull-right">
                        <ul class="social pull-left">
                           <li class="facebook"><a href="https://www.facebook.com/uosindh"><i class="fa fa-facebook"></i></a></li>
                           <li class="twitter"><a href="https://twitter.com/usindh"><i class="fa fa-twitter"></i></a></li>
                          
                           <li class="linkedin"><a href="https://www.linkedin.com/edu/school?id=15897"><i class="fa fa-linkedin"></i></a></li>
                           <li class="rss"><a href="http://usindh.edu.pk/blogs/?feed=rss2"><i class="fa fa-rss"></i></a></li>
                        </ul>
                        
                     </div>
                  </div>
               </div>
            </div>
            <!-- Header Top Bar End -->
            <!-- Main Header Start -->
            <div class="main-header">
               <div class="container">
                  <!-- TopNav Start -->
                  <div class="topnav navbar-header">
                     <a class="navbar-toggle down-button" data-toggle="collapse" data-target=".slidedown">
                     <i class="fa fa-angle-down fa fa-current"></i>
                     </a> 
                  </div>
                  <!-- TopNav End -->
                  <!-- Logo Start -->
                  <div class="logo pull-left">
                     <h1 style=" position: relative;">
                        <a href="<?php echo site_url(); ?>">
                        <img class="logomain" src="<?php echo base_url('htaccess/img/logo (1).png');?>" alt="pixma" width="125" height="120">
                        <span class="text-muted mainhead">University of Sindh </span>
                        <br>
                        <span style="    font-size: 14px;
    position: relative;
    margin-left: 136px;
    left: 0;
    bottom: 56px;;" class="text-muted mainheadp">Office of the Director, Research & Graduate Studies</span>
                        </a>
                        <!-- <a href="index.html" class="text-muted">a</a><br> -->
                        <!-- <a><small>Office of the Director, Research & Graduate Studies</small></a> -->
                     </h1>
                  </div>
                  <!-- Logo End -->
                  <!-- Mobile Menu Start -->
                  <div class="mobile navbar-header">
                     <a class="navbar-toggle" data-toggle="collapse" href=".navbar-collapse">
                     <i class="fa fa-reorder fa-2x"></i>
                     </a> 
                  </div>
                  <!-- Mobile Menu End -->
                  <!-- Menu Start -->
                  <nav class="collapse navbar-collapse menu">
                     <ul class="nav navbar-nav sf-menu">
                       <li>
                           <a href="#" class="sf-with-ul">
                           View
                           <span class="sf-sub-indicator">
                           <i class="fa fa-angle-down "></i>
                           </span>
                           </a>
                           <ul>
                              <li><a href="<?php echo site_url('dgrs/profile');?>" class="sf-with-ul">Profile</a></li>
                               <li><a target="_new" href="<?php echo base_url().'schedule.php';?>">Schedule/Rules</a></li>
                               <li><a target="_blank" href="<?php echo base_url().'ms_rule.pdf';?>"> MS/MPhil Rules</a></li>
                           </ul>
                        </li>
                        <li>
                           <a style="color:white;" href="http://dgrs.usindh.edu.pk/dgrsci/form_new.php?id=<?php echo $this->session->userdata('std_id')?>" target="_new" class="sf-with-ul">
                           Download Form
                           </a>
                        </li>
                        <li><a target="_new" href="<?php echo base_url().'schedule.php';?>">Schedule/Rules</a></li>
                        <li><a href="<?php echo site_url('dgrs/logout'); ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
                     </ul>
                  </nav>
                  <!-- Menu End --> 
               </div>
            </div>
            <!-- Main Header End -->
         </header>
         <!-- Header End -->  