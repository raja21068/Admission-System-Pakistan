<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: Khalid
 * Date: 11/03/2016
 * Time: 9:26 PM
 */


class Slip_Report
{

    var $candidateId;
    var $candidateImage;

    public function __construct($candidateId,$candidateImage) {
        $this->candidateId = $candidateId;
        $this->candidateImage = $candidateImage;
    }



    public function printReport($bean,$campusList,$group_name,$obj)
    {

        //$pd = new CellPDF();
        ob_start();
        $pd = new CellPDF('P','mm',array(165,260));
        $pd->AddPage();
        $widthCell = $pd->w / 1.6;
        $lmargin = $pd->lMargin;
        $tmargin = $pd->tMargin;
        //$pd->RotatedImage('circle.png',85,60,40,16,45);
        //$pd->Rotate(90);

        $heightCell = 8;
        $left_margin = 50;
        $top_margin = 83;
        $picture_width = $pd->w / 5;


        $pd->SetFillColor(0,0,0);
        $pd->SetFont("Arial",'B',10);
        $pd->SetLeftMargin(15);
        $pd->SetY($top_margin-7);
        //$pd->SetLeftMargin($left_margin);
        $pd->SetFont("Arial",'B',10);
        $pd->SetFont("Arial",'BU',10);

        $pd->SetFont("Arial",'B',10);
        $pd->SetFont("Arial",'B',8);
        if($group_name!="") {
            $pd->Cell(70, $heightCell, $group_name, 0, 0);
            $pd->SetFont("Arial",'B',10);
            $pd->SetXY(11,72);
            $pd->Cell(20,$heightCell,"Seat No:",0,0,0);
            $pd->SetFont("Arial",'B',14);
            $pd->SetTextColor(204, 51, 0);
            $pd->Cell(100,$heightCell," ".$bean->getSeatNo()." ",0,1);

        }else{

            $pd->Cell(10,$heightCell,"Seat No:",0,0,0);
            $pd->SetFont("Arial",'BU',14);
            $pd->SetTextColor(204, 51, 0);
            $pd->Cell(50,$heightCell," ".$bean->getSeatNo()." ",0,1);

        }
        $pd->SetTextColor(0, 0, 0);
        $pd->SetY($top_margin);
        $pd->SetFont("Arial",'',7);
        $pd->Cell(97,$heightCell,"Venue of Pre-Entry Test: ",1,1);
        $pd->SetFont("Arial",'',10);
        $pd->Cell($widthCell,$heightCell,"Name of Applicant:       ",1,1);
        $pd->Cell($widthCell,$heightCell,"Father�s Name:           ",1,1);
       // $pd->Cell($widthCell,$heightCell,"Surname:                 ",1,1);
      //  $pd->Cell($widthCell,$heightCell,"C N I C #:                   ",1,1);
       // $pd->Cell(97,$heightCell,"District of Domicile:    ",1,1);
        $pd->Cell($widthCell-10,$heightCell+5,"Postal Address:          ",1,1);
        // $pd->Cell( ($widthCell/2) + ($picture_width/2) ,$heightCell,"Mobile No.:",1,0);
        // $pd->Cell( ($widthCell/2) + ($picture_width/2) ,$heightCell,"Telephone No.:",1,1);
        // $this->Rotate(90,1,1);
        $pd->Cell($widthCell-10,$heightCell,"Contact #:                   ",1,1);
        $pd->Cell($widthCell-10,$heightCell,"C N I C #:                   ",1,1);
        if($obj !='')
        {
         $pd->Cell($widthCell-10,$heightCell,"Objection:                   ",1,1);
        }

        $pd->SetLeftMargin($left_margin);
        $pd->SetY($top_margin);
        $pd->SetFont("Times",'B',8);

        //$pd->Cell(0,$heightCell,"SINDH UNIVERSITY LAAR CAMPUS BADIN",0,1);

        $pd->Cell(0,$heightCell,$campusList[0]['name']." ".$campusList[0]['location'],0,1);
        $pd->SetFont("Times",'B',8);
        $pd->Cell(0,$heightCell,$bean->getName(),0,1);
        $pd->Cell(0,$heightCell,$bean->getFathersName()." , ".$bean->getSurname() ,0,1);
        //$pd->Cell(0,$heightCell,$bean->getSurname(),0,1);
       
       // $pd->Cell(0,$heightCell,$bean->getDistrictName(),0,1);
        //$pd->SetLeftMargin(10);
        $pd->SetFont("Times",'',8);
       // $current_y = $pd->GetY();
       // $current_x = $pd->GetX();
        $pd->MultiCell(60,$heightCell-4,$bean->getPostalAddr(),0,1);
        $pd->SetXY(50,120);
        $pd->Cell(0,$heightCell,$bean->getMobile(),0,1);
        $pd->SetXY(50,128);
        $pd->Cell(0,$heightCell,$bean->getCnic(),0,1);
         if($obj !='')
         {
            $pd->SetXY(50,138);
            //$pd->Cell(0,$heightCell,$obj,0,1);
            $pd->SetTextColor(194,8,8);
             $pd->MultiCell(60,$heightCell-4,$obj,0,1);
         }
        //$current_x+=$cell_width;                           //calculate position for next cell
        //$pd->SetXY($current_x, $current_y);
        $pd->SetTextColor(0,0,0);               //set position for next cell to print
        $pd->SetFont("Times",'',10);


        $pd->Image($this->candidateImage,($widthCell+$lmargin-5),($top_margin+$tmargin-10),$picture_width,48);

        $pd->SetLeftMargin(($widthCell+$lmargin-5));
        $pd->SetY($top_margin);
        $pd->Cell($picture_width,48,"",1);
        $pd->SetFont("Times",'',8);
        $pd->SetXY(108,133);
        $pd->Cell(0,0,"C.O.R No.".$bean->getCandidateId(),0,0);
        $pd->SetXY(108,137);

        $pd->Cell(0,0,"Form No.".$bean->getFormSNo(),0,0);
        $pd->SetXY(108,141);
        
        $pd->Cell(0,0,"Date of issue: ".date('d-m-Y'),0,0);
       


        //$pd->Cell(0,0," "." ",0,0);
        ob_clean();
        $dialog=true;
        $param=($dialog ? 'true' : 'false');
        $script="print($param);";
        $pd->IncludeJS($script);
        $pd->Output($this->candidateId.".pdf",'I');
        ob_end_flush();

    }


}