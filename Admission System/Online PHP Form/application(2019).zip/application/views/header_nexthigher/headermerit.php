<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
   <head>
      <meta charset="utf-8">
      <title>Next Higher Class</title>
      <meta name="description" content="Officail Results - University Of Sindh Jamshoro">
      <meta name="author" content="Khalid Durani">
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Google Fonts  -->
      <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
      <!-- Library CSS -->
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/bootstrap.css');?>">
      <link rel="stylesheet" href="http://dev.appon.io/global/vendor/switchery/switchery.css">
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/fonts/font-awesome/css/font-awesome.css');?>">
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/animations.css');?>" media="screen">
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/superfish.css');?>" media="screen">
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/prettyPhoto.css');?>" media="screen">
      <!-- Theme CSS -->
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/style.css');?>">
      <!-- Skin -->
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/colors/blue.css');?>">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/theme-responsive.css');?>">
      <!-- Favicons -->
      <link rel='shortcut icon' href="<?php echo base_url('htaccess/img/ico/logo.png');?>" type='image/x-icon'>
      <link rel="shortcut icon" href="<?php echo base_url('htaccess/img/ico/logo.png');?>">
      <link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url('htaccess/img/ico/logo.png');?>">
      <link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url('htaccess/img/ico/logo.png');?>">
      <link rel="apple-touch-icon" sizes="144x144" href="<?php echo base_url('htaccess/img/ico/logo.png');?>">
      <!-- datepicker -->
      <link rel="stylesheet" href="<?php echo base_url('htaccess/css/bootstrap-datepicker/bootstrap-datepicker.css');?>">
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="http://dev.appon.io/global/vendor/bootstrap-select/bootstrap-select.css">
   </head>