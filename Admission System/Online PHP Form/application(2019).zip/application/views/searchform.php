    <!-- Page Content -->
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class='col-md-10'>
                    <div class="text-center"><h3><span class="label label-default">Search Candidate</span></h3></div>
                    </br>
                    <div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                        <?php echo form_open($request_submit);?>

                    <div class="text-danger">
                    <?php echo $message;?>
                    </div>
                            <div class="form-group has-feedback">
                                <input type="text" class="form-control" placeholder="Candidate Id" name="candidateid" required>
                                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                            </div>
                           
                           
                           </br>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" align="center">Search
                                    <i class="glyphicon glyphicon-log-in"></i>
                                </button>
                            </div>




                            <?php echo form_close("");?>
                    </div>

                        <div class="col-md-4"></div>

                    </div>

                </div>

        </div>
            <!--IMPORTANT INSTRUCTION -->

            <div class="row">

                
                </div>
            </div>
        </div>




