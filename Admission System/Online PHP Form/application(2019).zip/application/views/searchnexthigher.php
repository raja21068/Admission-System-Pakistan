   <div class="breadcrumb-wrapper">

               <div class="container">

                  <div class="row">

                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">

                        <h2 class="title">Next Higher Class Form</h2>

                     </div>

                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">

                       

                     </div>

                  </div>

               </div>

            </div>
<div class="container">
<div class="row"> 
                    <form action="http://admission.usindh.edu.pk/index.php/nexthigherclass/updatePrint/" method="post" class="reply" id="">
                    <div class="col-md-12">
                        <table class="w3-table-all w3-hoverable">
                      
                      <tr>
                        <td>ID#</td>
                        <td><?php echo $data[0]['id_no']?></td>
                      </tr>
                    <!--   <tr>
                        <td>Candidate ID</td>
                        <td><?php //echo $data[0]['candidate_id']?></td>
                      </tr> -->
                      <tr>
                        <td>Batch</td>
                        <td><?php echo $data[0]['batch']?></td>
                      </tr>
                      <tr>
                        <td>Program</td>
                        <td><?php echo $data[0]['program']?></td>
                      </tr>
                      
                      <tr>
                        <td>Name</td>
                        <td><?php echo $data[0]['name']?></td>
                      </tr>
                      
                      <tr>
                        <td>Father Name</td>
                        <td><?php echo $data[0]['father_name']?></td>
                      </tr>
                      <tr>
                        <td>Surname</td>
                        <td><?php echo $data[0]['surname']?></td>
                      </tr>
                      <tr>
                        <td>Roll #</td>
                        <td><?php echo $data[0]['roll_no']?></td>
                      </tr>
                      <tr>
                        <td>CNIC#</td>
                        <td><?php echo $data[0]['cnic_no']?></td>
                      </tr>
                     
                       
                    <tr>
                        <td>Class</td>
                        <td><?php echo $data[0]['next_higher_class']?></td>
                      </tr>
            
                     <tr>
                        <td>Department</td>
                        <td><?php echo $data[0]['dept_name']?></td>
                      </tr>

                      <tr>
                        <td>Permanenet Address</td>
                        <td><input type="text" name="peraddress" style="width: 450px" required="">
                            <input type="hidden" name="rowid" value="<?php echo $data[0]['candidate_id']?>">
                        </td>
                      </tr>


                       <tr>
                        <td>Postal Adress</td>
                        <td><input type="text" name="posaddress" style="width: 450px" required=""></td>
                      </tr>

                       <tr>
                        <td>Contact#</td>
                        <td><input type="text" name="mobile" required=""></td>
                      </tr>
                      <tr>
                        <td>Contact# In Case of emergency</td>
                        <td><input type="text" name="phone"></td>
                      </tr>

                      <tr>
                        <td>Blood Group</td>
                        <td>
                          <select class="form-control " name="blood" required>
                                  <option value="" selected="selected">Select</option>
                                  <option value="A+">A Positive</option>
                                  <option value="A-">A Negative</option>

                                  <option value="B+">B Positive</option>
                                  <option value="B-">B Negative</option>
                                  
                                  <option value="AB+">AB Positive</option>
                                  <option value="AB-">AB Negative</option>
                                  
                                  <option value="O+">O Positive</option>
                                  <option value="O-">O Negative</option>
                                 

                          </select>
                              </td>
                      </tr>
                      
                      
                   
                      </table>
                     </div>
                     <div align="center" style="margin-top: 20px">
                      <button class="btn-normal btn-color submit  bottom-pad" type="submit">Export Form</button>
                     </div>
                   </form>
                     
             </div>        

</div>