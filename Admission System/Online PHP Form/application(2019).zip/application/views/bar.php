<!DOCTYPE html>

<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->

<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<head>

<!-- <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "1ddaacf6-19c4-4c1c-80dd-3f5eeb93c1f2",
    });
  });
</script> -->


	<!-- Fevicon

    ================================================== -->

	<link rel="shortcut icon" href="<?Php echo ASSET_PATH ?>favicon.ico">

	<link rel="icon" type="image/gif" href="<?Php echo ASSET_PATH ?>images/animated_favicon1.gif">



	<!-- Basic Page Needs

    ================================================== -->

	<meta charset="utf-8">

	<title>Directorate of Admissions</title>



	<!-- Mobile Specific Metas

    ================================================== -->

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">



	<!-- CSS

    ================================================== -->

	<!-- CSS

    ================================================== -->

	<link rel="stylesheet" href="<?Php echo ASSET_PATH ?>css/style.css">

	<link rel="stylesheet" href="<?Php echo ASSET_PATH ?>css/stylenew.css">

	<link type="text/css" rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/themes/smoothness/jquery-ui.min.css" media="screen" />


    <link type="text/css" rel="stylesheet" href="https://www.plupload.com/plupload/js/jquery.ui.plupload/css/jquery.ui.plupload.css" media="screen" />


	<!--<link rel="stylesheet" href="--><?Php //echo ASSET_PATH ?><!--css/colors/blue.css" id="colors">-->

	<!--<link rel="stylesheet" href="--><?Php //echo ASSET_PATH ?><!--css/bootstrap.min.css">-->

	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">



	<link rel="stylesheet" href="http://exam.usindh.edu.pk/css/colors/blue.css" id="colors">



	<link rel="stylesheet" href="http://exam.usindh.edu.pk/bootstrap/css/bootstrap.css">

	<link rel="stylesheet" href="http://exam.usindh.edu.pk/bootstrap/css/bootstrap.min.css">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

	<link rel="stylesheet" href="http://beta.simplesign.io/assets/examples/css/forms/advanced.css">

	<link rel="stylesheet" href="http://beta.simplesign.io/assets/css/site.min.css">

	<link rel="stylesheet" href="http://beta.simplesign.io/global/vendor/icheck/icheck.css"> 

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">



	<!--[if lt IE 9]>

	<script src="<?Php echo ASSET_PATH; ?>/js/html5.js"></script>

	<![endif]-->



	<!-- Java Script

    ================================================== -->

	<script src="http://exam.usindh.edu.pk/scripts/jquery.selectnav.js"></script>

	<script src="<?Php echo ASSET_PATH; ?>/js/bootstrap.min.js"></script>

	<script src="<?Php echo ASSET_PATH; ?>/scripts/chosen.jquery.js"></script>

	<script src="http://exam.usindh.edu.pk/scripts/custom.js"></script>

	<!--for date picker -->

	<!--<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">-->

	<!--<link rel="stylesheet" href="--><?Php //echo ASSET_PATH ?><!--datepicker/res/css/dateselector.min.css" type="text/css" />-->

	<script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>

	<!-- <script src="http://exam.usindh.edu.pk/scripts/jquery-ui.min.js"></script> -->

	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js" charset="UTF-8"></script>

	<!--<script src="--><?Php //echo ASSET_PATH ?><!--datepicker/res/libs/dateselector.min.js"></script>-->

	<script src="<?Php echo ASSET_PATH; ?>datepicker/dropdowndate/jquery.date-dropdowns.js"></script>

	<script src="<?Php echo ASSET_PATH; ?>js/jquery.maskedinput.js"></script>
    
    <script src="http://beta.simplesign.io/global/vendor/formvalidation/formValidation.min.js"></script>

    <script src="http://beta.simplesign.io/global/vendor/formvalidation/framework/bootstrap.min.js"></script> 

    <script src="http://admission.usindh.edu.pk/assets/plupload/plupload.full.min.js"></script>

    <script src="http://admission.usindh.edu.pk/assets/plupload/jquery.ui.plupload/jquery.ui.plupload.js"></script>




<style type="text/css">
.sticky-fixed 
{
      
}     







.userguideImg img
{
   display: none;
}

</style>

</head>

<body>



<!-- Wrapper / Start -->

<div id="wrapper">



	<!-- Header

    ================================================== -->



	<!-- 960 Container -->

	<div class="container">



		<!-- Header -->

		<header id="header">



			<!-- Logo -->

			<div class="ten columns">

				<div id="logo">

					<h1><a href="#"><img src="<?Php echo ASSET_PATH ?>images/logo.png" alt="Exma- University of Sindh" />

							<div id="tagline">University of Sindh </br><p style='font-size:23px;'> Directorate of Admissions</p></div>



				</div>

			</div>



			<!-- Social / Contact -->

			<div class="six columns">



				<!-- Social Icons -->

				<ul class="social-icons">

					<li class="twitter"><a href="https://twitter.com/usindh" target="_blank">Twitter</a></li>

					<li class="facebook"><a href="https://www.facebook.com/usindh" target="_blank">Facebook</a></li>



					<li class="linkedin"><a href="https://www.linkedin.com/edu/school?id=15897&trk=edu-cp-title" target="_blank">LinkedIn</a></li>

					<li class="rss"><a href="http://usindh.edu.pk/blogs/" target="_blank">RSS</a></li>

				</ul>



				<div class="clearfix"></div>



				<!-- Contact Details -->



				<div class="clearfix"></div>





			</div>

		</header>

		<!-- Header / End -->



		<div class="clearfix"></div>



	</div>

	<!-- 960 Container / End -->



	<?php

	//			if (!isset($_SESSION)) include('admin/session.php');//session_start();

	?>

	<!-- Navigation ================================================== -->

	<nav id="navigation" class="style-1">



		<div class="left-corner"></div>

		<div class="right-corner"></div>



		<ul class="menu" id="responsive">



<!--			<li><a href="http://admission.usindh.edu.pk/"><i class="halflings white home"></i> Home</a></li>-->

			<li><a href="<?php //echo base_url("index.php/app_form");?>"><i class="halflings white list-alt"></i>Admission Form</a></li>

<!--<li><a href="#">Bachelor Results</a>

		  <li><a href="#">Master Results</a>



				<ul>

					<li><a href="#">Pre-Entry Test (Search)</a></li>

			<!--

                                <li><a  style='background-color:#FFF5FE;' href="search.php?admission_session=2016&program_type=2&admission_list_detail=1">First Merit Selection (Search)</a></li>



                                            <li><a  style='background-color:#FFF5FE;' href="merit_list.php?admission_session=2015&program_type=2&admission_list_detail=1"><span></span> First Merit Selection (List)</a></li>







                                <li><a  style='background-color:#F0FCED;' href="search.php?admission_session=2015&program_type=2&admission_list_detail=2">Second Merit Selection (Search) </a></li>

                                <li><a  style='background-color:#F0FCED;' href="merit_list.php?admission_session=2015&program_type=2&admission_list_detail=2"><span></span> Second Merit Selection (List)</a></li>



                                <li><a  style='background-color:#FFFFE1;' href="search.php?admission_session=2015&program_type=2&admission_list_detail=3">Third Merit Selection (Search) </a></li>

                                <li><a  style='background-color:#FFFFE1;' href="merit_list.php?admission_session=2015&program_type=2&admission_list_detail=3"><span></span> Third Merit Selection (List)</a>



				</ul>

		  </li>

	<li><a href="#">MPHIL Result</a></li></li>-->

			<li> <a href="#">Fees Structure</a>

				<ul>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Fees_Structure_For_Bachelor_Degree_Programs.pdf">Bachelor</a></li>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Fees_Structure_For_Master_Degree_Programs.pdf">Master</a></li>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Fees_Structure_for_Faculty_of_Education.pdf">Faculty of Education</a></li>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/FEES_STRUCTURE_FOR_CAMPUSES_OF_UNIVERSITY_OF_SINDH.pdf">Campuses</a></li>

				</ul>

			</li>



			<li> <a href="#">Distribution of Seats</a>

				<ul>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Distribution_of_Allocated_Seats_for_Bachelor_Degree_Program.pdf">Bachelor</a></li>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Distribution_of_Allocated_Seats_for_Master_Degree_Program.pdf">Master</a></li>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Seat_Distribution_Faculty_of_Education.pdf">Faculty of Education</a></li>

	            </ul>

			</li>

			<li><a href="#"> Bachelors Courses Offered</a>

		      <ul>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelor-courses-arts.pdf">Faculty of Arts </a></li>

					<li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelors-courses-commerce.pdf">Faculty of Commerce</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelor-courses-education.pdf">Faculty of Education</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelors-courses-iistudies.pdf">Faculty of Islamic Studies</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelors-courses-law.pdf">Faculty of Law</a> </li>

                                       <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelors-courses-phar.pdf">Faculty of Pharmacy</a> </li>

                                       <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelor-courses-ns.pdf">Faculty of Natural Science</a> </li>

                                       <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Bachelo-courses-ss.pdf">Faculty of Social Science</a> </li>

				</ul>

		  </li>

			<li><a href="#">Masters Courses Offered</a> 

				<ul>

					<li>	<a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-Courses-arts.pdf">Faculty of Arts </a></li>

					<li><a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-courses-commerce.pdf">Faculty of Commerce </a></li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-courses-iistudies.pdf">Faculty of Islamic Studies</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-courses-law.pdf">Faculty of Law</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-courses-ns.pdf">Faculty of Natural Science</a> </li>

                                        <li><a href="<?Php echo ASSET_PATH; ?>/pdf/Masters-courses-ss.pdf">Faculty of Social Science</a> </li>

				</ul>

		  </li>

			<!--<li> <a href="<?Php echo ASSET_PATH; ?>/pdf/specimen for affidavit.pdf">Specimen for Affidavit</a>-->





			<li> <a href="<?Php echo ASSET_PATH; ?>/pdf/USER_GUIDE.pdf">User Guide</a></li>

			<!--<li> <a href="<?Php echo ASSET_PATH; ?>/pdf/AFFIDAVIT.pdf">Affidavit & Undertaking </a></li>-->

			<?php if($is_logged_in){?><li> <a href="<?=base_url()?>/app_form/logout"><i class="halflings white expand"></i>Logout</a> </li>

			<?php }?>
		</ul>
	</nav>

	<!-- new header html here -->

	<nav class="navbar navbar-default navbar-default-custom" role="navigation" style="min-height: 88px!important;">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img style="max-width: 70%;" class="brand-img" src="http://usindh.edu.pk/wp-content/uploads/2017/02/Header-Logo2.png" alt="..."></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-nav-custom" style="margin-top: 25px!important;">
            <li class="active"><a href="#">Admission Form</a></li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Fees Structure <b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li><a href="http://admission.usindh.edu.pk/assets//pdf/Fees_Structure_For_Bachelor_Degree_Programs.pdf">Bachelor</a></li>
                <li class="divider"></li>
                <li><a href="http://admission.usindh.edu.pk/assets//pdf/Fees_Structure_For_Master_Degree_Programs.pdf">Master</a></li>
                <li class="divider"></li>
                <li><a href="http://admission.usindh.edu.pk/assets//pdf/Fees_Structure_for_Faculty_of_Education.pdf">Faculty of Education</a></li>
                <li class="divider"></li>
                <li><a href="http://admission.usindh.edu.pk/assets//pdf/FEES_STRUCTURE_FOR_CAMPUSES_OF_UNIVERSITY_OF_SINDH.pdf">Campuses</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Distribution of Seats <b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a href="http://admission.usindh.edu.pk/assets//pdf/Distribution_of_Allocated_Seats_for_Bachelor_Degree_Program.pdf">Bachelor</a></li>
                <li class="divider"></li>
				<li> <a href="http://admission.usindh.edu.pk/assets//pdf/Distribution_of_Allocated_Seats_for_Master_Degree_Program.pdf">Master</a></li>
				<li class="divider"></li>
				<li> <a href="http://admission.usindh.edu.pk/assets//pdf/Seat_Distribution_Faculty_of_Education.pdf">Faculty of Education</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Bachelors Courses Offered <b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a href="http://admission.usindh.edu.pk/assets//pdf/Bachelor-courses-arts.pdf">Faculty of Arts </a></li>
                <li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelors-courses-commerce.pdf">Faculty of Commerce</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelor-courses-education.pdf">Faculty of Education</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelors-courses-iistudies.pdf">Faculty of Islamic Studies</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelors-courses-law.pdf">Faculty of Law</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelors-courses-phar.pdf">Faculty of Pharmacy</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelor-courses-ns.pdf">Faculty of Natural Science</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Bachelo-courses-ss.pdf">Faculty of Social Science</a> </li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Masters Courses Offered <b class="caret"></b></a>
              <ul class="dropdown-menu dropdown-menu-custom">
                <li> <a href="http://admission.usindh.edu.pk/assets//pdf/Masters-Courses-arts.pdf">Faculty of Arts </a></li>
                <li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Masters-courses-commerce.pdf">Faculty of Commerce </a></li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Masters-courses-iistudies.pdf">Faculty of Islamic Studies</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Masters-courses-law.pdf">Faculty of Law</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Masters-courses-ns.pdf">Faculty of Natural Science</a> </li>
				<li class="divider"></li>
				<li><a href="http://admission.usindh.edu.pk/assets//pdf/Masters-courses-ss.pdf">Faculty of Social Science</a> </li>
              </ul>
            </li>

            <!--<li class="userguideImg"><a href="http://admission.usindh.edu.pk/assets//pdf/USER_GUIDE.pdf">User Guide</a></li>-->

            <li> <a href="<?=base_url()?>/app_form/logout"><i class="fa fa-sign-out" aria-hidden="true" style="color: #fff;font-size: 18px;vertical-align: middle;padding-right: 4px;"></i>Logout</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>

	<div class="clearfix"></div>

	<script type="text/javascript">

    $(document).ready(function(){
     $(window).scroll(function(){  
             var scrollTop = parseInt($(window).scrollTop());
             if ( scrollTop > 0) 
             {
                  $('.navbar-default-custom').css({
                     
                      'width':'100%',
                      'background-color':'rgb(255, 255, 255)',
                      'z-index':'999999',
                      'box-shadow':'0px 0px 10px #d2d2d2'
                  });
                  
             }
             else
             {
                  $('.navbar-default-custom').css({
                     'position':'',
                      'width':'100%',
                      'background-color':'rgb(255, 255, 255)',
                      'z-index':'999999',
                      'box-shadow':''
                  });
                
             }

            });

            $(function() {   
						    $("#uploadernew").plupload({
						        // General settings
						        runtimes : 'html5,flash,silverlight,html4',
						        url : "/index.php/app_form/testUpload",
						 
						        // Maximum file size
						        max_file_size : '5mb',
						 
						        chunk_size: '4mb',
						 
						        // Resize images on clientside if we can
						        /*resize : {
						            width : 200,
						            height : 200,
						            quality : 90,
						            crop: true // crop to exact dimensions
						        },*/
						 
						        // Specify what files to browse for
						        filters : [
						            {title : "Image files", extensions : "jpg,gif,png"}
						           
						        ],

						 
						        // Rename files by clicking on their titles
						        rename: true,
						         
						        // Sort files
						        sortable: true,
						 
						        // Enable ability to drag'n'drop files onto the widget (currently only HTML5 supports that)
						        dragdrop: false,
						 
						        // Views to activate
						        views: {
						            list: true,
						            thumbs: true, // Show thumbs
						            active: 'thumbs'
						        },

						         init : {
							            PostInit: function() {
							                // Called after initialization is finished and internal event handlers bound
							               
				
							            },

						        UploadComplete: function(up, files) {
					                // Called when all files are either uploaded or failed
					                
					            },
					        },
						 
						        // Flash settings
						        flash_swf_url : '/plupload/js/Moxie.swf',
						     
						        // Silverlight settings
						        silverlight_xap_url : '/plupload/js/Moxie.xap',

						     });
    
      
   		});

    });


	</script>
	
	
<!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
window.__lc = window.__lc || {};
window.__lc.license = 9974915;
(function() {
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
<!-- End of LiveChat code -->
