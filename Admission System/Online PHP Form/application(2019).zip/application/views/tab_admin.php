<?php $this->load->library("variable");?>
<style>
    .custom-bg-red{
        background-color: #de5959;
        color: white;
    }

    .copy{
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
    text-decoration: none;

    color: #333;
    background-color: #fff;
    border-color: #ccc;
}
</style>

<div class="page-content">
    <div class="container">
        <?php echo form_open('slip_admin/search_candidate');?>
        <div class="row">
                <div class="col-lg-4">
                    <div class="input-group">
                        <input type="text" name="corn" class="form-control" placeholder="Candidate Online Registration No." required>
                          <span class="input-group-btn">
                            <input type="submit" class="btn btn-default" >Search</input>
                          </span>
                    </div>
                <?php if($is_data){ ?>    
                <div class="input-group" style="margin-top: 10px;border: 1px solid;float: right;">
                    <img src="<?php echo base_url("uploads/".$candidate->getCandidateId()).".jpg";?>" style="width:150px">
                </div>
                <?php } ?>
                </div>
            <?php echo form_close(); ?>

           
            <?php
            if($is_data){ ?>
            <div class="col-lg-6">
                <table class="table table-bordered">


                    <tr>
                        <td>C.R NO</td>
                        <td> <?php echo $candidate->getCandidateId();?> </td>
                    </tr>

                    <tr>
                        <td>Form Date And Time</td>
                        <?php
                        $myDateTime= DateTime::createFromFormat('Y-m-d H:i:s',$candidate->getDateOfSumbitForm());

                        $newDateString = $myDateTime->format('d-m-Y H:i:s');

                        ?>
                        <td> <?php echo $newDateString ; ?> </td>
                    </tr>

                    <tr>

                        <td>PROGRAM NAME</td>
                        <td> <?php if($candidate->getProgramTypeId()==1){ echo "BACHELOR";} else{ echo"MASTER";} ?> </td>
                    </tr>

                    <tr>
                        <td>Name</td>
                        <td> <?php echo $candidate->getName();?> </td>
                    </tr>
                    <tr>
                        <td>Father Name</td>
                        <td> <?php echo $candidate->getFathersName();?> </td>
                    </tr>
                    <tr>
                        <td>Surname</td>
                        <td> <?php echo $candidate->getSurname();?> </td>
                    </tr>

                            <form action="<?php echo base_url("index.php/slip_admin/print_candidate") ?>" method="post" target="_blank">
                                <div class="form-group has-feedback">
                                    <input type="hidden" name="corn" value="<?php echo $corn;?>">

                                    <?php if($candidate->getFormSNo()==0){ ?>

                                    <tr>
                                       <td>FormNo</td>

                                       <td><input type="number" name="formNo" required></td>
                                   </tr>

                                        <?php
                                              }
                                        ?>


                                    <?php if($candidate->getProgramTypeId()==2){ ?>
                                    <tr>
                                        <td>GROUP</td>

                                        <td><select name="group">
                                                <?php
                                                foreach( $master_group as $master )

                                                {
                                                $id=$master['id'];
                                                $name=	$master['name'];

                                                ?>
                                                    <option  value="<?php echo '' . $id ?>" <?php if($this->candidate->getGroupId() == $id){echo "selected class='custom-bg-red' ";}?>> <?php echo '' . $name ?>  </option>

                                                <?php
                                                }
                                                ?>
                                            </select></td>

                                    </tr>

                                    <?php } ?>

                                    <tr>
                                        <td>Objection</td>
                                        <td><input type="text" style="width: 374px" name="objection" id="objection" class="paste"></td>
                                    </tr>
                                     <tr>
                                       <td>Objection </td>
                                       <td>
                                      <?php if($candidate->getProgramTypeId()==2){ ?>

                                       <div class="copy">Graduation Orignal Marsheet</div>
                                       <div class="copy">HCS Marks Certificate</div>
                                       <div class="copy">SSC Marks Certificate</div>
                                       <div class="copy">Domicile Certificate</div>
                                      <?php }  else {?>
                                            <div class="copy">HSC Orignal Marsheet</div>
                                           <div class="copy">SSC Marks Certificate</div>
                                           <div class="copy">Domicile Certificate</div>

                                      <?php } ?>

                                       </td>

                                      

                                      </tr>

                                    <tr>

                                        <td>Print</td>
                                        <td>

                                        <input type="submit" name="<?php echo Variable::LOGIN();?>" value="Print and Save">
                                    <span class="glyphicon glyphicon-print form-control-feedback"></span>
                                </div>
                            </form>
                        </td>
                    </tr>
                </table>

 <div class="row">
                <div class="col-md-10">
                <table class="table table-bordered">
                    <tr>
                        <td><strong>Qualification</strong></td>
                        <td><strong>Group</strong></td>
                        <td><strong>Total Marks</strong></td>
                        <td><strong>Marks Obtained</strong></td>
                        <td><strong>Year</strong></td>
                        <td><strong>Seat No</strong></td>
                        <td><strong>Board / University</strong></td>
                    </tr>
                    <tr>
                        <td>S.S.C </td>
                        <td><?php echo $cred->getGroupName();?></td>
                        <td><?php echo $cred->getTotalMarks();?></td>
                        <td><?php echo $cred->getObtainMarks();?></td>
                        <td><?php echo $cred->getPassingYear();?></td>
                        <td><?php echo $cred->getSeatNo();?></td>
                        <td><?php echo $cred->getIssuerName();?></td>
                    </tr>
                    <tr>
                        <td>H.S.C</td>
                        <td><?php echo $credHsc->getGroupName();?></td>
                        <td><?php echo $credHsc->getTotalMarks();?></td>
                        <td><?php echo $credHsc->getObtainMarks();?></td>
                        <td><?php echo $credHsc->getPassingYear();?></td>
                        <td><?php echo $credHsc->getSeatNo();?></td>
                        <td><?php echo $credHsc->getIssuerName();?></td>
                    </tr>
                    <?php if( $candidate->getProgramTypeId() == Variable::$MASTER_ID ){
                        ?>
                        <tr>
                            <td>Graduation</td>
                            <td><?php echo $credGrd->getGroupName();?></td>
                            <td><?php echo $credGrd->getTotalMarks();?></td>
                            <td><?php echo $credGrd->getObtainMarks();?></td>
                            <td><?php echo $credGrd->getPassingYear();?></td>
                            <td><?php echo $credGrd->getSeatNo();?></td>
                            <td><?php echo $credGrd->getIssuerName();?></td>
                        </tr>
                        <?php
                        $optionsSize = count($optionals);
                        if($optionsSize >0){
                            $optionString = "";
                            for($i=0;$i<$optionsSize;$i++){
                                $nam = $optionals[$i]['name'];
                                $optionString .= (($i+1).".".$nam."  --  ");
                            }
                            ?>
                            <tr>
                                <td>Optional Subjects</td>
                                <td colspan="6"><?php echo $optionString;?></td>
                            </tr>
                            <?php
                        }
                    }?>
                </table>

            </div>
        </div>


            </div>
                <div class="col-lg-8">
                <form action="<?php echo base_url("index.php/slip_admin/print_candidate_form") ?>" method="post" target="_blank">
                    <input type="hidden" name="corn" value="<?php echo $corn;?>">
                    <input type="submit"  name="<?php echo Variable::LOGIN();?>" value="Print Student Form">

                </form>

                    </div>
                <hr>
               <!-- <div class="col-lg-8">
                    <button  class="btn btn-danger btn-lg" id="unLock">UN LOCKED</button>
                </div> -->
            <?php } ?>

        </div>
    </div>
</div>
<script>
    $("#unLock").click(function(){
        var id = $("#select-morning").val();
        $.post("<?php echo base_url("index.php/slip_admin/unlock_candidate_form"); ?>",
            {
                corn: '<?php echo $corn;?>'
            }
            , function(data) {
                alert("Sucessfully Unlocked...");
            });


    });

    $(document).on('click', '.copy', function(e){
    e.preventDefault(); //for <a>
    var vl=$('.paste').val();
    var comma='';
    if(vl != '')
    {
     comma=' - ';
    }
    $('.paste').val(vl+comma+$(this).text());
});
</script>
