    <!-- Page Content -->
    <div class="page-content">
        <div class="container">

            <div class="row">
                <div class='col-md-10'>
                 <!--<marquee style="color: #f00; font-weight: bold;">
                    The date of submission of online as well as manual admission forms for Bachelor Degree Programs 2017 has been extended up to November 07, 2016. This date extension facility will be for only those candidates who have already obtained forms. As per this announcement, the office of the Director Admissions, University of Sindh will stay open on Saturday, 05.11.2016 and Sunday, 06.11.2016 to receive admission forms. However, the date of issuance of forms has already expired; hence, no new forms will be issued hereafter.
                   </marquee>-->
                    <div class="text-center"><h3><span class="label label-default">Import Results<?php// echo $title;?></span></h3></div>
                    </br>
                    <div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                        <?php echo form_open_multipart($request_submit);?>
                   
                    <div class="text-danger">
                
                    </div>
                            
                            <div class="form-group has-feedback">
                               <input type="file" name="filecsv">
                                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            </div>
                           
                           </br>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" align="center">Login
                                    <i class="glyphicon glyphicon-log-in"></i>
                                </button>
                            </div>




                            <?php echo form_close("");?>
                    </div>

                        <div class="col-md-4"></div>

                    </div>

                </div>

        </div>
            <!--IMPORTANT INSTRUCTION -->

          




