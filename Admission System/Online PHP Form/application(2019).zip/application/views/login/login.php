<!-- Content Start -->
         <div id="main">
            <!-- Title, Breadcrumb Start-->
            <div class="breadcrumb-wrapper">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                        <h2 class="title">Login</h2>
                     </div>
                     <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                        <div class="breadcrumbs pull-right">
                           <ul>
                              <li>You are here:</li>
                              <li><a href="index.html">Home</a></li>
                              <li>Login</li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Title, Breadcrumb End-->
            <!-- Main Content start-->
            <div class="content">
               <div class="container">
               <?php $error_msg = $this->session->flashdata('error_msg');
                 if(!empty($error_msg)){?><div class="alert alert-danger" role="alert">
        <strong></strong> <?php echo $error_msg;?>.
      </div><?php }?>
                  <div class="row">
                  <div class="col-md-6 col-md-offset-3" style="text-align: center;">
                     <div class="panel panel-primary" style="border-color: #323B44;
}">
                     <div class="panel-heading text-center" style="font-size: 21px;    color: #ffffff;
    background-color: #323B44;
    border-color: #323B44;">Log-In to Your Account</div>
                     <div class="panel-body">
                     <div class="divider"></div>
                        <form action="<?php echo base_url().'dgrs/userlogin'?>" method="post" class="reply" id="contact">
                           <fieldset>
                              <div class="row">
                                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <label>User Name: <span>*</span></label>
                                    <input class="form-control" id="name" name="user" type="text" value="" required placeholder="User">
                                 </div>
                                 </div>
                                 <div class="row">
                                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <label>Password: <span>*</span></label>
                                    <input class="form-control" type="password" id="email" name="user_password" value="" required placeholder="User Password">
                                 </div>
                              </div>
                           </fieldset>
                           <button type="submit" class="btn-normal btn-color submit  bottom-pad" >Login</button>
                           </form>
                           
                     </div>
                  </div>

                  </div>
      
                  <div class="divider"></div>
               </div>
               </div>
            </div>
            <!-- Main Content end-->
         </div>
         <!-- Content End -->
