<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: Khalid
 * Date: 11/03/2016
 * Time: 9:26 PM
 */
use Dompdf\Dompdf;
//use Dompdf\Dompdf\Options;
require_once 'dompdf0.8.2/autoload.inc.php';

class New_Slip
{

    var $candidateId;
    var $candidateImage;


    public function __construct($candidateId,$candidateImage) {
        $this->candidateId = $candidateId;
        $this->candidateImage = $candidateImage;
    }



    public function printReport($bean,$campusList,$group_name,$obj)
    {


    /*echo "<pre>";
     print_r($bean);
     exit();*/
     if($bean->getProgramTypeId()==1)
        {$prg="BACHELOR";

        $dt="11th November 2018 9:00 A.M";
        }
        else
        {$prg="MASTER";
         $dt="28th October 2018 9:00 A.M";

            }

     $campname=$campusList[0]['name'];
     $camploc=$campusList[0]['location'];
      $cont="
            <html>
            <head>
            <style>
            table, th, td {
                font-family: Arial, Helvetica, sans-serif;
                    font-size:16px;
                    border: 1px solid black;

            }
            ul li {margin-top:10px}
            tr.noBorder{
            border:none;
            }
            th{
                text-align:left;
            }
            .p3{
                     
                font-family: Arial, Helvetica, sans-serif;
                position:absolute; 
                top:0px; left:0px; 
                width:100%;

                }
             body{
                background-image: url('logotr2.png');
                background-size:100px 100px;
             }   
            </style>
            </head>
            <body>
            <div class='p3'>
            <div style=' width:100%; height:100%;'>
            <img src='logo (1).png' style='position:absolute; top: 15px; left:290px;  width:100px; height: 100px; '> 
            <div style='position:absolute; top:90px; left: 140px;' ><h2>UNIVERSITY OF SINDH, JAMSHORO</h2></div> 
            <div style='position:absolute; top:125px; left:200px; '><h3>PRE-ENTRY TEST ADMIT CARD</h3></div>
            <div style='position:absolute; top:145px; left:180px; '><h3>".$prg." DEGREE PROGRAMS - 2019</h3></div>

            <img style='width:180px; height:180px; position:absolute; top:300px; left:560px; width:140px; height:170px; ' src='".$this->candidateImage."' /> 
            </div>

            <div style='position:absolute; top:190px; left:200px;'><b><u>Sunday, ". $dt."</u></b></div>
             <h5><div style='position:absolute; top:210px; left:200px;'><b>(For which no separate notice will be issued.)</b></div></h5>
             <h3><div style='position:absolute; top:240px; left:90px;'><b>MOBILE PHONE IS NOT ALLOWED IN EXMINATION CENTER</b></div></h3>
             <h5><div style='position:absolute; top:280px; left:570px;'>C.O.R.No:  ".$bean->getCandidateId()."</div></h5>



            <div style='position:absolute; top:300px; left:20px;' >Seat No.</div>
            <h3><div style='position:absolute; top:300px; left:150px;' ><b>".$bean->getSeatNo()."   ".$group_name."</b></div></h3>

             <div style='position:absolute; left:20px; top:330px;'>VENUE:</div>
             <div style='position:absolute; left:150px; top:330px;'><b>".$campname." ".$camploc."</b></div>
           
           <div style='position:absolute; top:360px; left:20px;'>Name:</div>
           <div style='position:absolute; top:360px; left:150px;'><b>".strtouPper($bean->getName())."</b></div>
           
            <div style='position:absolute; top:390px; left:20px;'>Father's Name: </div>
            <div style='position:absolute; top:390px; left:150px;'><b>".strtoupper($bean->getFathersName())."</b></div>
            
            <div style='position:absolute; top:420px; left:20px;'>Surname:</div>
             <div style='position:absolute; top:420px; left:150px;'><b>".strtoupper($bean->getSurname())."</b></div>
           

            <div style='position:absolute; top:450px; left:20px;'>C.N.I.C No:</div>
            <div style='position:absolute; top:450px; left:150px;'><b>".strtoupper($bean->getCnic())."</b></div>

           
            <div style='position:absolute; left:20px; top:570px;'>Signature of Candidate</div>

            <img src='qr2019/qr2019".$bean->getSeatNo().".png' style='position:absolute; top: 490spx; left:600px;  width:100px; height: 100px; '>
            

            <div style='position:absolute; top:590px; 0px;'><hr></div>
            <div style='position:absolute; left:20px; top:610px;'><b><u>IMPORTANT INFORMATION FOR THE DAY OF TEST:</u></b></div>
            <div style='position:absolute; left:20px; top:610px;'>
            <ul style='position:absolute; left:20px; font-size: small;'>
            <li>Please bring this admit card to the test center. You will not be admitted without it.</li>
            <li>Please bring black ball point</li>
            <li>Please note down your Seat Number carefully. The result of Pre-Entry Test will be announced by the Seat Number and <b>NOT</b> by name. </li>

            <li>No candidate shall be permitted to appear in the test unless he/she bring the original <b>Admit Card</b> at the time specified for the Pre-Entry Test.</li>

            <li>Please Retain a photocopy of this Admit Card with you.</li>

            <li>Please bring you original CNIC when you come to the examination center of Pre-Entry Test.</li>

            <li>You are required to be present in your respective block up to 09:00 a.m. whereas the Test will be started at 09:30 a.m. sharp.</li>


            </ul>

            </div>
            <div style='position:absolute; left:30px; top:880px;'><b>The candidate is required not to bring items such as Mobile Phone, calculators, handbook, purse etc at the examination center of Pre Entry Test.</b></div>
            <div style='position:absolute; top:930px; left:20px;'><b>MOBILE PHONE IS NOT ALLOWED IN EXMINATION CENTER; IF FOUND, HE/SHE WILL BE DISQUALIFIED.</b></div>
            </div>
            </div>

            </body>
            </html>";

            $dompdf = new Dompdf();

            $dompdf->loadHtml($cont);

            // (Optional) Setup the paper size and orientation

            $dompdf->setPaper('portrait', 'portrait');
            $dompdf->render();
            $f;
            $l;
            if(headers_sent($f,$l))
            {
               echo $f,'<br/>',$l,'<br/>';
               die('now detect line');
            }

            // Output the generated PDF to Browser

            $dompdf->stream('Application Form NO:',array('Attachment'=>0));

    }


}