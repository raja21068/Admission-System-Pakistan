<?php
/**
 * Created by PhpStorm.
 * User: RAJA DELL LAPTOP
 * Date: 10/3/2015
 * Time: 1:27 PM
 */
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.gmail.com'; //change this
    $config['smtp_port'] = '465';
    $config['smtp_user'] = 'auto.alumni@usindh.edu.pk'; //change this
    $config['smtp_pass'] = 'Raja123@$'; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes to comply with RFC 822 standard
