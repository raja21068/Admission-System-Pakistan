<?php

function printProgramOfStudy($hscProgramId, $cposRS,$hscIssuer=0) {
    while ($cposRow = mysqli_fetch_array($cposRS)) {
        $disc = $cposRow['name'];
        $campusName = $cposRow['campus_name'];
        $location = $cposRow['location'];
        $posId = $cposRow['program_of_study_id'];
        $cposId = $cposRow['campus_program_of_study_id'];
        $feesRS = DatabaseManager::getFirstPartFees($cposId," AND jfs.`admission_year_id`=6");
        $isOk = false;
        $cposFees= 0;
        $totalFess=0;
        if($feesRow = mysqli_fetch_array($feesRS)){
            $cposFees = $feesRow['fee_amount'];
            $remarks = $feesRow['remarks'];
            $pieces = explode(",", $remarks);
            $boardFess=$pieces[0];
            $meritFess=$pieces[1];

            if($hscIssuer==1){
                $totalFess=$cposFees+$meritFess;

            }else{
                $totalFess=$cposFees+$meritFess+$boardFess;

            }
            //$cposFees=$cposFees+$pieces[1];
            // echo  // piece1
            echo $pieces[1]; // piece2

            // echo($cposFees);
            // echo($remarks);
        }
        $progSubjectRs = DatabaseManager::getProgramSubject($hscProgramId,$posId);
        $preCount = mysqli_num_rows($progSubjectRs);
        if ($preCount > 0) {
            $isOk = true;
        }
        if ($isOk) {
            echo "<option fees='$totalFess' value='$cposId' discipline='$disc' campus='$campusName' location='$location' >$disc ($location)</option>";
        }
    }
}

if (isset($_POST['SEAT_NO']) && ( isset($_POST['CNIC']) || isset($_POST['DOB']))) {
    $seatNo = $_POST['SEAT_NO'];
    $cnic = $_POST['CNIC'];
    $dob = $_POST['DOB'];
    require_once './DatabaseManager.php';
    $resultSet = DatabaseManager::getStudent($seatNo, $cnic, $dob,1,6);
    $count = mysqli_num_rows($resultSet);
    while ($row = mysqli_fetch_array($resultSet)) {
$candidateId=$row['candidate_id'];       
	   $sNo = $row['seat_no'];
        $name = $row['name'];
        $father = $row['fathers_name'];
        $testScore = $row['test_score'];
        $CPN = $row['percentage'];
        $hscGroup = $row['hsc_group'];
        $hscMarks = $row['hsc_marks'];
        $sscMarks = $row['ssc_marks'];
        $hscProgramId = $row['hsc_program_id'];
        $provinceId = $row['province_id'];
        $hscIssuer = $row['hsc_is_jurisdiction'];
       $resultSetPaidAmount = DatabaseManager::paidAmount($candidateId);
 $paidAmount=0;
 if ($rowPaidAmount = mysqli_fetch_array($resultSetPaidAmount)) {
	
        $paidAmount = $rowPaidAmount['paid_amount'];
 }

        echo "<table class='table table-bordered table-striped'>";
        echo "<tr><td><strong>Seat#</strong></td><td>$sNo</td></tr>";
        echo "<tr><td><strong>Name</strong></td><td>$name</td></tr>";
        echo "<tr><td><strong>Father's Name </strong></td><td>$father</td></tr>";
        echo "<tr><td><strong>SSC Marks </strong></td><td>$sscMarks</td></tr>";
        echo "<tr><td><strong>HSC Marks </strong></td><td>$hscMarks</td></tr>";
        echo "<tr><td><strong>Degree </strong></td><td>$hscGroup</td></tr>";
        //echo "<tr><td><strong>Test Score </strong></td><td>$testScore</td></tr>";
        // echo "<tr><td><strong>CPN </strong></td><td>$CPN</td></tr>";
        if($paidAmount != 0){
            echo "<tr class='success'><td><strong>Paid Amount</strong> </td><td>$paidAmount</td></tr>";
        }
        echo "</table>";
        echo "<div class='row'>";
        echo "<div class='col-md-5'>";
        echo "<select id='cpos_select'>";
        echo "<option value='-1'>--SELECT CHOICE--</option>";
        $cposRS = DatabaseManager::getProgramOfStudy(1, 1, 1,"AND cm.`campus_id`=1 AND  cpos.campus_program_of_study_id in (38,41,39,45,62,37,34,204,9,36,42,43,31,46)");

        printProgramOfStudy($hscProgramId, $cposRS,$hscIssuer);
        echo "</select>";
        echo "</div>";
        echo "<div class='col-md-2'>";
        echo "<input type='button' class='btn btn-default' id='add_btn' value='Add  ' onclick='addChoiceInTable()' >";
        echo "</div>";
        echo "<div class='col-md-2'>";
        echo "<input type='button' class='btn btn-default' id='reset_btn' value='Reset' onclick='resetChoice()' >";
        echo "</div>";
        echo "<form action='bachelor_morning_print.php' method='post' >";
        echo "<input type='submit' class='btn btn-default' id='print_btn' value='Done' onclick='done()' style='display: none;' >";
        echo "<input type='hidden' name='SEAT_NO' value='$sNo'>";
        echo "<input type='hidden' name='CNIC' value='$cnic'>";
        echo "<input type='hidden' name='DOB' value='$dob'>";
        echo "<input type='hidden' name='CN_NAME' value='$name'>";
        echo "<input type='hidden' name='FATHERS_NAME' value='$father'>";
        echo "<input type='hidden' name='SSC_MARKS' value='$sscMarks'>";
        echo "<input type='hidden' name='HSC_MARKS' value='$hscMarks'>";
        echo "<input type='hidden' name='HSC_GROUP' value='$hscGroup'>";
        echo "<input type='hidden' name='TEST_SCORE' value='$testScore'>";
        echo "<input type='hidden' name='CPN' value='$CPN'>";
        echo "<input type='hidden' name='CHOICES' id='choices' value=''>";
        echo "<input type='hidden' name='FEES' id='fees' value=''>";
        echo "<input type='hidden' name='PAIDAMOUNT' id='fees' value='$paidAmount'>";
        echo "</div>";
        echo "</div>";


        echo "<table id='choices_table' class='table table-considered table-striped table-bordered'>";
        echo "<tr>";
        echo "<td>#</td>";
        echo "<td>Discipline</td>";
        echo "<td>Campus</td>";
        echo "<td>Fees</td>";
        echo "</tr>";
        echo "</table>";
        echo "</div>";
    }
    if ($count < 1) {
        echo "<font color='red'>Your input data is invalid</font>";
    }
}
?>
