<?php

class DatabaseManager {

    public static function getStudent($seatNo, $cnic, $dob, $programTypeId, $admissionYearId) {
        include("./connection.php");
        $query = "select c.seat_no,c.name, c.fathers_name, c.test_score, c.percentage,c.candidate_id
                  , (select p.name from credential_details cd inner join program p on p.program_id = cd.program_id where detail_of = 1 and cd.candidate_id = c.candidate_id) as hsc_group
                  , (select marks_obtained from credential_details cd where detail_of = 0 and cd.candidate_id = c.candidate_id) as ssc_marks
                  , (select marks_obtained from credential_details cd where detail_of = 1 and cd.candidate_id = c.candidate_id) as hsc_marks
                  , (select is_jurisdiction from credential_details cd inner join issuer i on i.issuer_id = cd.issuer_id where detail_of = 1 and cd.candidate_id = c.candidate_id) as hsc_is_jurisdiction
                  , (select program_id from credential_details cd where detail_of = 1 and cd.candidate_id = c.candidate_id) as hsc_program_id
                  , (select dv.province_id from district d inner join division dv on dv.division_id = d.division_id where d.district_id = c.district_id) as province_id
                                   from candidate c where c.seat_no = $seatNo and c.admission_year_id = $admissionYearId and c.program_type_id = $programTypeId";

        if ($cnic == "") {
            $query .= " AND c.date_of_birth = '$dob'";
        } else {
            $query .= " AND c.cnic_no = '$cnic'";
        }
        //echo ("$query");
        $result = mysqli_query($con, $query);
        return $result;
    }
public static function paidAmount($candidateId){
	        include("./connection.php");
        $query = "select sum(amount)  as paid_amount from part_registry where type=0 and account_id = (select a.account_id from accounts a where a.candidate_id = $candidateId)";
        $result = mysqli_query($con, $query);
        return $result;

}

    public static function getCredentialInfo($candidateId, $detailof) {
        include("./connection.php");
        $query = "select p.program_id, p.name,cd.marks_obtained,cd.total_marks,cd.passing_year from credential_details cd
                  inner join program p on p.program_id = cd.program_id
                   where cd.candidate_id = $candidateId and detail_of = $detailof";
        $result = mysqli_query($con, $query);
        return $result;
    }

    public static function getProgramOfStudy($campusId, $shiftId, $programTypeId, $filteration = "") {
        include("./connection.php");
        $query = "select pos.name, cm.name as campus_name, cm.location, pos.program_of_study_id, campus_program_of_study_id from campus_program_of_study cpos 
                  inner join program_of_study pos on pos.program_of_study_id = cpos.program_of_study_id
                  inner join program p on p.program_id = pos.program_id
                  inner join campus cm on cm.campus_id = cpos.campus_id
                  where 
                  cpos.shift_id = $shiftId 
                  and p.program_type_id = $programTypeId

                  $filteration    
                  order by pos.name";
echo($query);
        $result = mysqli_query($con, $query);
        return $result;
    }

//    public static function getLawProgramOfStudy($campusId, $shiftId, $programTypeId){
//        include("./connection.php");
//        $query = "SELECT POS.NAME,POS.PROGRAM_OF_STUDY_ID,CPOS.CAMPUS_PROGRAM_OF_STUDY_ID FROM CAMPUS_PROGRAM_OF_STUDY CPOS 
//                  INNER JOIN PROGRAM_OF_STUDY POS ON POS.PROGRAM_OF_STUDY_ID = CPOS.PROGRAM_OF_STUDY_ID
//                  INNER JOIN PROGRAM P ON P.PROGRAM_ID = POS.PROGRAM_ID
//                  INNER JOIN CAMPUS CM ON CM.CAMPUS_ID = CPOS.CAMPUS_ID
//                  WHERE 
//                  CPOS.SHIFT_ID = $shiftId 
//                  AND P.PROGRAM_TYPE_ID = $programTypeId AND POS.NAME LIKE '%LAW%'
//                  ORDER BY POS.NAME";
////        echo $query;
//        $result = mysqli_query($con, $query);
//        return $result;        
//    }

    public static function getProgramSubject($programId, $programOfStudyId) {
        include("./connection.php");
        $query = "select * from prerequisite pr where program_of_study_id = $programOfStudyId 
                  and program_subject_id in( 
                   select ps.program_subject_id from program p 
                   inner join program_subject ps on ps.program_id = p.program_id
                   where p.program_id = $programId)";

//        echo $query;
        $result = mysqli_query($con, $query);
        return $result;
    }

    public static function getPrerequisite($programOfStudyId, $programSubjectId) {
        include("./connection.php");
        $query = "select * from prerequisite pr where program_of_study_id = $programOfStudyId and program_subject_id = $programSubjectId";
        $result = mysqli_query($con, $query);
        return $result;
    }

    public static function getFirstPartFees($cposId, $filteration = "") {
        include("./connection.php");
        $query = "select * from j_fee_structure jfs where jfs.j_pos_part_id in ( select jpp.id from j_pos_part jpp where part = 1 and jpp.campus_program_of_study_id = $cposId ) 
                  $filteration
                ";
        //echo($query);
        $result = mysqli_query($con, $query);
        return $result;
    }

    public static function getStudentOfMaster($seatNo, $cnic, $dob, $programTypeId, $admissionYearId) {
        include("./connection.php");
        $query = "select c.seat_no,c.name, c.fathers_name, c.test_score, c.percentage,candidate_id
                  , (select p.name from credential_details cd inner join program p on p.program_id = cd.program_id where detail_of = 2 and cd.candidate_id = c.candidate_id) as hsc_group
                  , (select marks_obtained from credential_details cd where detail_of = 0 and cd.candidate_id = c.candidate_id) as ssc_marks
                  , (select marks_obtained from credential_details cd where detail_of = 1 and cd.candidate_id = c.candidate_id) as hsc_marks
                  , (select marks_obtained from credential_details cd where detail_of = 2 and cd.candidate_id = c.candidate_id) as grd_marks
                  , (select is_jurisdiction from credential_details cd inner join issuer i on i.issuer_id = cd.issuer_id where detail_of = 2 and cd.candidate_id = c.candidate_id) as hsc_is_jurisdiction
                  , (select program_id from credential_details cd where detail_of = 2 and cd.candidate_id = c.candidate_id) as hsc_program_id
                  , (select dv.province_id from district d inner join division dv on dv.division_id = d.division_id where d.district_id = c.district_id) as province_id
                 
                  from candidate c where c.seat_no = $seatNo and c.admission_year_id = $admissionYearId and c.program_type_id = $programTypeId";
        if ($cnic == "") {
            $query .= " AND c.date_of_birth	= '$dob'";
        } else {
            $query .= " AND c.cnic_no = '$cnic'";
        }

        $result = mysqli_query($con, $query);
        return $result;
    }

}

?>