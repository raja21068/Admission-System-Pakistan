<?php

$con = mysqli_connect("localhost", "usindh_self", "Jh#dswrft", "us_admission_v2");

// Check connection

if (mysqli_connect_errno($con)) {

    header("Location: error_page.php?message=Failded%20to%20connect%20Database");

}

?>