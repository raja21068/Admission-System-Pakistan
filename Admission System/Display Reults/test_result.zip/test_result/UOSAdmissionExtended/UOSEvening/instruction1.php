<div>

Those candidates who have appeared in the Pre Entry Test for Bachelors' Degree Programs are invited to submit an online application perfoma for admission to selected disciplines in  Morning Programs 

<b>ARABIC, COMPARATIVE RELIGION, EDUCATION(B.ED ELEMENTRY), FRESH WATER BIOLOGY, MUSLIM HISTORY, PERSIAN, PHILOSOPHY, RURAL DEVELOPMENT STUDY, URDU, ART HISTORY, FINE ARTS, COMMUNICATION DESIGN, TEXTILE DESIGN, HEALTH & PHYSICAL EDUCATION</b>

<br/>

<b>Note:</b><font color="red">Those candidates who are appling in  BS(Physical Education Health & Science) will have conducted separate test to be conducted on Monday,11-January-2016 at 09:00 A.M</font></br>

<b>Note:</b><font color="red">Those candidates who will appling in  Instt: of Arts and Design will have conducted separate test to be conducted on Tuesday,12-January-2016 at 09:00 A.M</font>



    <br/>

<b>Procedure:</b> 

<ol>

<li>Please fill out maximum 3 choices of disciplines</li>

<li>Please fill out the given application form according to choices of discipline avilable to you and submit it online.</li> 

<li>Print out a copy of your application on A4 size paper. </li>

<li>Desposit the required amount of Fees in the format of a Demand Draft (for your first choice) in favor of Director Admissions, University of Sindh.</li>

<li>Submit the printed application to the Directorate of Admissions, University of Sindh, Jamshoro, alongwith original Demand Draft upto 08-01-2016 and obtain the receipt from the concerned clerk.</li>

</ol>

<div>