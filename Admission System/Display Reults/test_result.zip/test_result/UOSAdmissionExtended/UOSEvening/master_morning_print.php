<?php

require('fpdf/cellpdf.php');

class PDF extends FPDF {

    function Header() {
        $this->Image('images/logo.png', 50, 50, 100);

        //$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size 

        $this->SetFont('Arial', 'B', 15);
        $this->Cell($w, 9, "University of Sindh, Jamshoro", 1, 1, 'C', false);
        $this->Ln(10);
    }

    function Footer() {
        //Position at 1.5 cm from bottom
        $this->SetY(-15);
        //Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        //Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

}
if (isset($_POST['SEAT_NO']) && ( isset($_POST['CNIC']) || isset($_POST['DOB']))) {
        $seatNo = $_POST['SEAT_NO'];
        $cnic = $_POST['CNIC'];
        $dob = $_POST['DOB'];
        $name = $_POST['CN_NAME'];
        $father = $_POST['FATHERS_NAME'];
        $sscMarks = $_POST['SSC_MARKS'];
        $hscMarks = $_POST['HSC_MARKS'];
        $testScore = $_POST['TEST_SCORE'];
        $hscGroup = $_POST['HSC_GROUP'];
        $cpn = $_POST['CPN'];
        $choices = $_POST['CHOICES'];
        $fees = $_POST['FEES'];
        $paidAmount = $_POST['PAIDAMOUNT'];
        $choicesArray =  explode("-", $choices);
        $pdf = new CellPDF();
        $pdf->SetFont('Times', '', 20);
        $pdf->AddPage();
        $pdf->Image('images/new_logo2_trans.png', 50, 80, 100,100);
        $pdf->Image('images/logo.png', 20, 5, 20);
        $pdf->Cell(0, 8, "University of Sindh, Jamshoro", 0, 1, 'C', false);
        $pdf->SetFont('Times', '', 14);
        $pdf->Cell(0, 8, "Master Morning  Self Finance Program 2016", 0, 1, 'C', false);
        $pdf->Cell(0, 8, "Application Form", 0, 1, 'C', false);
        $pdf->SetFont('Times', '', 9);
        $pdf->Cell(0, 8, "Those candidates who have apeared in pre-entry test for master degree program 2016 can apply in evening program for admission to available limited seats", 0, 1, 'C', false);
        $pdf->Image('images/right_logo.jpg', 170, 5, 18);
        $pdf->Ln(1);
        
        $pdf->SetFillColor(180,180,180);
        
        PrintData::getStudentData($pdf, $seatNo, $name, $father, $sscMarks, $hscMarks, $hscGroup,$testScore, $cpn);
        $yOfLinesAndRect = 115; 
        
        $pdf->SetFont('Times', 'B', 12);
        $pdf->SetTextColor(255,255,255);
        $pdf->Cell(192, 6, "DEMAND DRAFT", 0, 0, 'L',true);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetFont('Times', '', 12);
        $pdf->Ln(8);
        $pdf->Cell(20, 6, "D.D Number", 0, 0, 'L',false);
        $pdf->Cell(40, 6, "", 1, 0, 'L',false);
        $pdf->Cell(10, 6, "Date", 0, 0, 'L',false);
        $pdf->Cell(30, 6, "", 1, 0, 'L',false);
        $pdf->Cell(14, 6, "Amount", 0, 0, 'L',false);
        $pdf->Cell(20, 6, ($fees-$paidAmount).".00", 1, 0, 'L',false);
        $pdf->Cell(10, 6, "NIC *", 0, 0, 'L',false); 
        $pdf->Cell(41, 6, "", 1, 0, 'L',false);
        $pdf->Ln(8);
        $pdf->Cell(40, 6, "Bank Name and Branch", 0, 0, 'L',false);
        $pdf->Cell(145, 6, "", 1, 0, 'L',false);
        $pdf->Ln();
        $pdf->SetFont('Times', '', 8);
        $pdf->Cell(145, 6, "* NIC number at which demand draft is issued by bank", 0, 0, 'L',false);

        $pdf->Ln(6);
        $pdf->SetTextColor(255,255,255);
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(192, 6, "DOCUMENT ATTACHED WITH THIS APPLICATION FORM", 0, 0, 'L',true);
        $pdf->SetTextColor(0,0,0);
        $pdf->Ln();
        $pdf->SetFont('Times', '', 11);
        $pdf->Cell(192, 8, "1. Original demand draft of fees", 0, 0, 'L',false);

    $pdf->Ln(4);
    $pdf->Cell(192, 8, "Note:  Desposit the required amount of Fees in the format of a Demand Draft (for your first choice) in favor of Director Admissions, University of Sindh.", 0, 0, 'L',false);

    $pdf->Cell(192, 8, "", 0, 0, 'L',false);
        $pdf->Ln(42);
        $pdf->setX(160);
        $pdf->Cell(40, 0, "", 1, 0, 'L',false);
        $pdf->setX(160);
        $pdf->Cell(40, 6, "Applicant's Signature", 0, 0, 'L',false);
        
        
        $pdf->Ln(10);
        $pdf->Cell(192, 6, "-----------------------------------------------------------------------------------------------------------------------------------------------", 0, 0, 'L',false);
        $pdf->Ln(3);
        $pdf->SetFont('Times', 'B', 14);
        $pdf->Cell(192, 6, "RECEIPT", 0, 0, 'C',false);
        $pdf->Ln();
        PrintData::getStudentData($pdf, $seatNo, $name, $father, $sscMarks, $hscMarks, $hscGroup,$testScore, $cpn);
        $pdf->Cell(20, 6, "D.D Number", 0, 0, 'L',false);
        $pdf->Cell(40, 6, "", 1, 0, 'L',false);
        $pdf->Cell(10, 6, "Date", 0, 0, 'L',false);
        $pdf->Cell(30, 6, "", 1, 0, 'L',false);
        $pdf->Cell(14, 6, "Amount", 0, 0, 'L',false);
        $pdf->Cell(20, 6, ($fees-$paidAmount).".00", 1, 0, 'L',false);
        $pdf->Cell(10, 6, "NIC *", 0, 0, 'L',false); 
        $pdf->Cell(41, 6, "", 1, 0, 'L',false);
        $pdf->Ln(8);
        $pdf->Cell(40, 6, "Bank Name and Branch", 0, 0, 'L',false);
        $pdf->Cell(145, 6, "", 1, 0, 'L',false);
        $pdf->Ln(18);
        $pdf->Ln();
        $pdf->setX(160);
        $pdf->Cell(40, 0, "", 1, 0, 'L',false);
        $pdf->setX(160);
        $pdf->Cell(40, 6, "Signature and Stamp", 0, 0, 'L',false);
        
        PrintData::printChoice($pdf,$choicesArray,43);
        PrintData::printChoice($pdf,$choicesArray,184);
        
        $pdf->SetFont('Times', 'BU', 8);
        $pdf->SetXY(10, 30);
        $pdf->Cell(40, 6, "Last Date: 31-December-2015", 0, 0, 'L');
       

        $pdf->Ln();
        $pdf->Output();
}

class PrintData {

    
    public static function getStudentData($pdf, $seatNo, $name, $father, $ssc_marks, $hsc_marks,$hscGroup,$test_perc, $cpn) {
        $w = array(90, 35, 120, 50, 40, 20);
        
        $h = 6;
        $pdf->SetFont('Times', 'B', 12);
        $pdf->SetTextColor(255,255,255);
        $pdf->Cell(120, $h, "PERSONAL INFORMATION", 0, 0, 'L',true);
        $pdf->SetTextColor(0,0,0);
        $pdf->Ln();
        $pdf->SetFont('Times', '', 12);

        $pdf->Cell($w[1], $h, "Seat#", 0, 0, 'L');
        $pdf->Cell($w[2], $h, "$seatNo", 0, 0, 'L');
        $pdf->Ln();
        $pdf->Cell($w[1], $h, "Name", 0, 0, 'L');
        $pdf->Cell($w[2], $h, "$name", 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell($w[1], $h, "Father's Name:", 0, 0, 'L');
        $pdf->Cell($w[2], $h, "$father", 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell($w[1], $h, "SSC Marks:", 0, 0, 'L');
        $pdf->Cell($w[2], $h, $ssc_marks, 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell($w[1], $h, "HSC Marks:", 0, 0, 'L');
        $pdf->Cell($w[2], $h, $hsc_marks, 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell($w[1], $h, "HSC Group:", 0, 0, 'L');
        $pdf->Cell($w[2], $h, $hscGroup, 0, 0, 'L');
        $pdf->Ln();

       // $pdf->Cell($w[1], $h, "TEST SCORE:", 0, 0, 'L');
       // $pdf->Cell($w[2], $h, $test_perc, 0, 0, 'L');
      //  $pdf->Ln();

       // $pdf->Cell($w[1], $h, "CPN:", 0, 0, 'L');
       // $pdf->Cell($w[2], $h, $cpn, 0, 0, 'L');
       // $pdf->Ln();
    }

    public static function printChoice($pdf,$choicesArray,$yChoices=34){
        $pdf->SetFont('Times', 'B', 12);
        $pdf->SetXY(122, $yChoices);
        $pdf->SetTextColor(255,255,255);
        $pdf->Cell(80, 6, "DISCIPLINE", 0, 0, 'L',true);
        $pdf->SetTextColor(0,0,0);
        
        $pdf->SetFont('Times', '', 12);
        $size = count($choicesArray);
        $y = 42;
        for($i=0;$i<$size;$i++,$y+=8){
            $pdf->Ln();
            $pdf->SetX(122);
            $pdf->cell(80, 8, (($i+1).". ".$choicesArray[$i]),0,0,'L',false);
        }
        $pdf->Ln();
    }
    
}

//end class
?>	








