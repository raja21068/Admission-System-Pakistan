<?php

function printProgramOfStudy($hscProgramId, $cposRS) {
    while ($cposRow = mysqli_fetch_array($cposRS)) {
        $disc = $cposRow['name'];
        $campusName = $cposRow['campus_name'];
        $location = $cposRow['location'];
        $posId = $cposRow['program_of_study_id'];
        $cposId = $cposRow['campus_program_of_study_id'];
        $feesRS = DatabaseManager::getFirstPartFees($cposId,"AND jfs.`admission_year_id`=6");
        $isOk = false;
        $cposFees= 0;
    if($feesRow = mysqli_fetch_array($feesRS)){
        $cposFees = $feesRow['fee_amount'];
    }
        $progSubjectRs = DatabaseManager::getProgramSubject($hscProgramId,$posId);
            $preCount = mysqli_num_rows($progSubjectRs);
            if ($preCount > 0) {
                $isOk = true;
            }
        if ($isOk) {
            echo "<option fees='$cposFees' value='$cposId' discipline='$disc' campus='$campusName' location='$location' >$disc ($location)</option>";
        }
    }
}

if (isset($_POST['SEAT_NO']) && ( isset($_POST['CNIC']) || isset($_POST['DOB']))) {
    $seatNo = $_POST['SEAT_NO'];
    $cnic = $_POST['CNIC'];
    $dob = $_POST['DOB'];
    require_once './DatabaseManager.php';
    $resultSet = DatabaseManager::getStudentOfMaster($seatNo, $cnic, $dob,2,6);
    $count = mysqli_num_rows($resultSet);
    while ($row = mysqli_fetch_array($resultSet)) {
        $sNo = $row['seat_no'];
        $name = $row['name'];
        $father = $row['fathers_name'];
        $testScore = $row['test_score'];
        $CPN = $row['percentage'];
        $hscGroup = $row['hsc_group'];
        $hscMarks = $row['hsc_marks'];
        $sscMarks = $row['ssc_marks'];
        $hscProgramId = $row['hsc_program_id'];
        $provinceId = $row['province_id'];
        $hscIssuer = $row['hsc_is_jurisdiction'];
        $paidAmount = $row['paid_amount'];

        echo "<table class='table table-bordered table-striped'>";
        echo "<tr><td><strong>Seat#</strong></td><td>$sNo</td></tr>";
        echo "<tr><td><strong>Name</strong></td><td>$name</td></tr>";
        echo "<tr><td><strong>Father's Name </strong></td><td>$father</td></tr>";
        echo "<tr><td><strong>SSC Marks </strong></td><td>$sscMarks</td></tr>";
        echo "<tr><td><strong>HSC Marks </strong></td><td>$hscMarks</td></tr>";
        echo "<tr><td><strong>Degree </strong></td><td>$hscGroup</td></tr>";
        //echo "<tr><td><strong>Test Score </strong></td><td>$testScore</td></tr>";
       // echo "<tr><td><strong>CPN </strong></td><td>$CPN</td></tr>";
        if($paidAmount != null){
            echo "<tr class='success'><td><strong>Paid Amount</strong> </td><td>$paidAmount</td></tr>";
        }
        echo "</table>";
        echo "<div class='row'>";
        echo "<div class='col-md-5'>";
        echo "<select id='cpos_select'>";
        echo "<option value='-1'>--SELECT CHOICE--</option>";
        $cposRS = DatabaseManager::getProgramOfStudy(1, 2, 2," AND cpos.campus_program_of_study_id IN (189,108,115,165)");
        printProgramOfStudy($hscProgramId, $cposRS);
        echo "</select>";
        echo "</div>";
        echo "<div class='col-md-2'>";
        echo "<input type='button' class='btn btn-default' id='add_btn' value='Add  ' onclick='addChoiceInTable()' >";
        echo "</div>";
        echo "<div class='col-md-2'>";
        echo "<input type='button' class='btn btn-default' id='reset_btn' value='Reset' onclick='resetChoice()' >";
        echo "</div>";
        echo "<form action='master_evening_print.php' method='post' >";
        echo "<input type='submit' class='btn btn-default' id='print_btn' value='Done' onclick='done()' style='display: none;' >";
        echo "<input type='hidden' name='SEAT_NO' value='$sNo'>";
        echo "<input type='hidden' name='CNIC' value='$cnic'>";
        echo "<input type='hidden' name='DOB' value='$dob'>";
        echo "<input type='hidden' name='CN_NAME' value='$name'>";
        echo "<input type='hidden' name='FATHERS_NAME' value='$father'>";
        echo "<input type='hidden' name='SSC_MARKS' value='$sscMarks'>";
        echo "<input type='hidden' name='HSC_MARKS' value='$hscMarks'>";
        echo "<input type='hidden' name='HSC_GROUP' value='$hscGroup'>";
        echo "<input type='hidden' name='TEST_SCORE' value='$testScore'>";
        echo "<input type='hidden' name='CPN' value='$CPN'>";
        echo "<input type='hidden' name='CHOICES' id='choices' value=''>";
        echo "<input type='hidden' name='FEES' id='fees' value=''>";
        echo "</div>";
        echo "</div>";


        echo "<table id='choices_table' class='table table-considered table-striped table-bordered'>";
        echo "<tr>";
        echo "<td>#</td>";
        echo "<td>Discipline</td>";
        echo "<td>Campus</td>";
        echo "<td>Fees</td>";
        echo "</tr>";
        echo "</table>";
        echo "</div>";
    }
    if ($count < 1) {
        echo "<font color='red'>Your input data is invalid</font>";
    }
}
?>
