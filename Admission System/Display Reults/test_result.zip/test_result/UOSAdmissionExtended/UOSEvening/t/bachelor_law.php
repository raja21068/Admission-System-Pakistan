﻿<?php include("bar.php"); ?>

<script>
    $(document).ready(function() {
        var width = $("#seatNoInput").width();
        $("#dobInput").width(width);
    });
</script>

<!-- Content
================================================== -->

<div id="content">

    <!-- 960 Container -->
    <div class="container floated">

        <div class="sixteen floated page-title">

            <h2>Application Form For L.L.B (Self Finance) Morning</h2>

        </div>

    </div>
    <!-- 960 Container / End -->

    <!-- Page Content -->
    <div class="page-content">

        <div class="container">
            <div class="sixteen columns">
                <div class="row"> 
                    <div class='col-md-4'>
                        <table>
                            <tr>
                                <td>Seat No.<font color="red">*</font></td><td><input type="text" maxlength="5" id="seatNoInput" /></td>
                            </tr>
                            <tr>
                                <td>CNIC No.</td><td><input type="text"  id="cnicInput" placeholder="i.e. 40321-1234478-2" /></td>
                            </tr>
                            <tr>
                                <td colspan="2" style="text-align: center;">OR</td>
                            </tr>
                            <tr>
                                <td>Date of Birth.</td><td><input type="date" id="dobInput" /></td>
                            </tr>
                            <tr>
                                <td colspan="2" ><input type="button" class="btn btn-default" onclick="submitInfo();" value="View"><img id="busy" src="images/busy.gif" style="display: none;"></td>
                            </tr>
                        </table>
                        <select id="hidden_progs" style="display: none;"></select>
                    </div>
                    <div class='col-md-6'>
                        <div id="candidate_content">

                        </div>
                    </div>
                </div>
				<?php include("instruction.php");?>
            </div>
        </div>

    </div>
    <!-- Page Content / End -->

</div>
<!-- Content / End -->

</div>
<!-- Wrapper / End -->
<script>
    function submitInfo() {
        var seatNo = $.trim($("#seatNoInput").val());
        var cnic = $("#cnicInput").val();
        var dob = $("#dobInput").val();
        if (seatNo == "") {
            alert("Seat number is required..");
            return;
        }
        if (cnic == "" && dob == "") {
            alert("CNIC or Date of Birth must be given..");
        } else {
            $('#busy').show();
            $.post("bachelor_law_candidate_search.php", {
                SEAT_NO: seatNo,
                CNIC: cnic,
                DOB: dob
            }, function(response) {
                $('#busy').hide();
                $("#candidate_content").html(response);
                $("#hidden_progs").html( $("#cpos_select").html() );
            });
        }

    }
    
    function addChoiceInTable(){
        var cposId = $("#cpos_select").val();
        if(cposId == -1){
            alert("Please select any choice from list");
            return;
        }else{
            var feesAmount=$("#cpos_select option:selected").attr('fees');
            var location=$("#cpos_select option:selected").attr('location');
            var discipline=$("#cpos_select option:selected").attr('discipline');
            $("#print_btn").show();
            var rowCount = $('#choices_table tr').length;
            $("#choices_table").append("<tr><td>"+rowCount+"</td><td>"+discipline+"</td><td>"+location+"</td><td>"+feesAmount+"</td></tr>");
            $("#cpos_select option[value='"+cposId+"']").remove();
            $("#cpos_select").val(-1);
            if(rowCount == 1){
                $("#choices").val(discipline)+" ("+location+")";
                $("#fees").val(feesAmount);
            }else{
                var choiceValue = "" + $("#choices").val() + "-"+discipline+" ("+location+")";
                $("#choices").val(choiceValue);            
            }
            if(rowCount == 5){
                $("#cpos_select").html("");
            }
        }
    }
    function resetChoice(){
         $("#print_btn").hide();
         $("#cpos_select").html($("#hidden_progs").html());
         $("#choices_table").html("<tr><td>#</td><td>Discipline</td><td>Campus</td><td>Fees</td></tr>");
    }
    
</script>
<?php include("footerbar.php");  ?>