<div>
Those candidates who have appeared in the Pre Entry Test for Masters' Degree Programs are invited to submit an online application for admission in <b> BIOCHEMISTRY, BIOTECHNOLOGY, CHEMISTRY, COMMERCE, COMPUTER SCIENCE,ENGLISH, ISLAMIC CULTURE, MASS COMMUNICATION, MATHEMATICS, PAKISTAN STUDIES, PHYSICS PHYSIOLOGY</b> in Self Morning.
<br/>
<b>Note:</b>There are limited seats available in selected disciplines. 
<br/>
<b>Procedure:</b> 
<ol>
    <li>Please fill out maximum 3 choices of disciplines</li>
    <li>Please fill out the given application form according to choices of discipline avilable to you and submit it online.</li>
<li>Print out a copy of your application on A4 size paper. </li>
<li>Desposit the required amount of Fees in the format of a Demand Draft (for your first choice) in favor of Director Admissions, University Of Sindh.</li>
<li>Submit the printed application to the Directorate of Admissions, University of Sindh, Jamshoro, alongwith original Demand Draft upto 31-12-2015 and obtain the receipt from the concerned clerk.</li>
</ol>
<div>