<link rel="stylesheet"  href="css/bootstrap.min.css">
                    <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
<?php
 require_once './DatabaseManager.php';
   $con=DatabaseManager::connect();

if (isset($_REQUEST['admission_list_detail'])) {
//    echo "<option value=''>--SELECT CATEGORY--</option>";
    $admListDetailId = mysqli_real_escape_string($con, $_REQUEST['admission_list_detail']);
    $campusId = mysqli_real_escape_string($con, $_REQUEST['campus_id']);
    $discip = mysqli_real_escape_string($con, $_REQUEST['discipline']);
	//echo("admListDetailId: ".$admListDetailId."</br>");
	//echo("cam: ".$campusId."</br>");
	//echo("disp ".$discip."</br>");
?>	
        <h3 align="center" style="color: red;"><?php echo $discip; ?></h3>

<?php
	    $result = DatabaseManager::getDistinctCategories($admListDetailId, $campusId, $discip);
    while ($row = mysqli_fetch_array($result)) {
        $cat = $row['CATEGORY'];
        ?>

        <h3><?php echo $cat; ?></h3>


       <div class="col-xs-12">
	   <table   class="table table-striped table-bordered">
            <tr class='info'>
				<th style="text-align: center;">S#</th>
                <th style="text-align: center;">SEAT#</th>
                <th style="text-align: center;">CANDIDATE NAME</th>
                <th style="text-align: center;">FATHER<SPAN>'</SPAN>S NAME</th>
                <th style="text-align: center;">DISTRICT</th>
            <?php
					if($discip=='LL.B (LAW)' || $discip=='LAW' || $discip=='B.B.A (HONS) (BUSINESS ADMINISTRATION)' || $discip=='BUSINESS ADMINISTRATION' || $discip== 'PHARM-D (PHARMACY)' || $discip=='PHARMACY' || $discip=='BS (PUBLIC ADMINISTRATION)' || $discip=='PUBLIC ADMINISTRATION' || $discip=='BS (COMPUTER SCIENCE)' || $discip=='COMPUTER SCIENCE' || $discip=='BS (INFORMATION TECHNOLOGY)' || $discip=='INFORMATION TECHNOLOGY' || $discip=='BS (SOFTWARE ENGINEERING)' ||  $discip=='SOFTWARE ENGINEERING' || $discip=='BS (ELECTRONICS)' ||  $discip=='ELECTRONICS' || $discip=='BS (TELECOMMUNICATION)' || $discip=='TELECOMMUNICATION' || $discip=='BS (GENETICS)' || $discip=='GENETICS'){
				
				if($discip=='BS (COMPUTER SCIENCE)' || $discip=='COMPUTER SCIENCE'){
					echo('<th style="text-align: center;">GROUP</th>');
				}
			     echo('<th style="text-align: center;">U/R</th>');
				}				 
				echo(' <th style="text-align: center;">CPN</th>');
				echo("</tr>");
				
			
		 if(($discip=='LL.B (LAW)' || $discip=='LAW' || $discip=='B.B.A (HONS) (BUSINESS ADMINISTRATION)' || $discip=='BUSINESS ADMINISTRATION' || $discip== 'PHARM-D (PHARMACY)' || $discip=='PHARMACY' || $discip=='BS (PUBLIC ADMINISTRATION)' || $discip=='PUBLIC ADMINISTRATION' ||   $discip=='BS (INFORMATION TECHNOLOGY)' || $discip=='INFORMATION TECHNOLOGY' || $discip=='BS (SOFTWARE ENGINEERING)' ||  $discip=='SOFTWARE ENGINEERING' || $discip=='BS (ELECTRONICS)' ||  $discip=='ELECTRONICS' || $discip=='BS (TELECOMMUNICATION)' || $discip=='TELECOMMUNICATION' || $discip=='BS (GENETICS)' || $discip=='GENETICS')  && ($cat=="General Merit (Out of Jurisdiction)  MORNING" || $cat=="General Merit (Jurisdiction)  MORNING")){
				
		   $result2 = DatabaseManager::getAllCandidates($admListDetailId, $campusId, $discip, $cat,"ORDER BY `DISTRICT` , AREA");
		 
		 }else if ($discip=='BS (COMPUTER SCIENCE)' || $discip=='COMPUTER SCIENCE'){
			$result2 = DatabaseManager::getAllCandidates($admListDetailId, $campusId, $discip, $cat,"ORDER BY `DISTRICT` , AREA, DEGREE");
		 
		  }else{
			  $result2 = DatabaseManager::getAllCandidates($admListDetailId, $campusId, $discip, $cat);
		  }
            
            $sNo=0;
			while ($row2 = mysqli_fetch_array($result2)) {
				$sNo++;             
				echo "<tr>";
				echo "      <td>" . $sNo . "</td>";
                echo "      <td>" . $row2['SEAT_NO'] . "</td>";
                echo "      <td>" . $row2['NAME'] . "</td>";
                echo "      <td>" . $row2['FATHER'] . "</td>";
                echo "      <td>" . $row2['DISTRICT'] . "</td>";
					if($discip=='LL.B (LAW)' || $discip=='LAW' || $discip=='B.B.A (HONS) (BUSINESS ADMINISTRATION)' || $discip=='BUSINESS ADMINISTRATION' || $discip== 'PHARM-D (PHARMACY)' || $discip=='PHARMACY' || $discip=='BS (PUBLIC ADMINISTRATION)' || $discip=='PUBLIC ADMINISTRATION' || $discip=='BS (COMPUTER SCIENCE)' || $discip=='COMPUTER SCIENCE' || $discip=='BS (INFORMATION TECHNOLOGY)' || $discip=='INFORMATION TECHNOLOGY' || $discip=='BS (SOFTWARE ENGINEERING)' ||  $discip=='SOFTWARE ENGINEERING' || $discip=='BS (ELECTRONICS)' ||  $discip=='ELECTRONICS' || $discip=='BS (TELECOMMUNICATION)' || $discip=='TELECOMMUNICATION' || $discip=='BS (GENETICS)' || $discip=='GENETICS'){
								if($discip=='BS (COMPUTER SCIENCE)' || $discip=='COMPUTER SCIENCE' ){
						echo('<td>'.$row2['DEGREE'].'</th>');
					}
					
						$area='';
						if($row2['AREA']=='0' || $row2['AREA']=='U')$area='U';
						else $area='R';
			 
						echo "      <td>" . $area . "</td>";
					}
                echo "      <td>" . $row2['CPN'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
		</div>
            <?php
        }
    }
    ?>
