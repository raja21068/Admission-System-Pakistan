<?php  if ($admListDetailId==0){
	?>
	<h4  align='center' >ENTRY TEST  RESULT FOR MASTERS DEGREE PROGRAM 2016</h4>

<?php } ?>

<?php  if ($admListDetailId==1){
    ?>
       <h4  align='center' >FIRST  MERIT SELECTION RESULT FOR MASTERS DEGREE PROGRAM 2016</h4>
<div style="color:red" align="center">Objecction of First  Merit List for Master Degree Programs 2016 is <B>NOVEMBER 06, 2015</B>.</div>
	
<!--	<div style="color:red" align="center">Admission challans of First Merit List Master 2016 are available  from  <B>OCTOBER 29, 2015 to NOVEMBER 06, 2015 </B>.</div>-->


<?php } ?>
	   <?php
      
	   if ($admListDetailId==2){
	   

?>


<h4  align='center' >SECOND MERIT SELECTION RESULT FOR MASTERS DEGREE PROGRAM 2016</h4>
<div style="color:red" align="center">Last date for payment of Admission fees under Second Merit List for Master Degree Programs 2016 is <B>NOVEMBER 25, 2015</B>.</div>
   <div style="color:red" align="center">Admission challans of Second Merit List Master 2015 are available  from  <B>NOVEMBER 17, 2015</B>.</div>
<?php

	   }
?>


	   <?php
      
	   if ($admListDetailId=='3'){
	   

?>

<!--<h4  align='center' >THIRD PROVISIONAL MERIT SELECTION RESULT FOR MASTERS DEGREE PROGRAM 2016</h4>-->
<h4  align='center' >THIRD MERIT SELECTION RESULT FOR MASTERS DEGREE PROGRAM 2016</h4>

<!--<div style="color:red" align="center">LAST DATE FOR SUBMISSION OF OBJECTION (IF ANY) AT DIRECTORATE OF ADMISSIONS DURING OFFICE HOURS UPTO <b>MONDAY 07.12.2015</b></div>
<div style="color:red" align="center"> 3rd LIST (AFTER REMOVING OBJECTIONS) WILL BE DISPLAYED ON TUESDAY 08.12.2015</div>-->

<div style="color:red" align="center">Last date for payment of Admission fees under Third Merit List for Master Degree Programs 2016 is  <B>DECEMBER 15, 2015</B>.</div>
<!--<div style="color:red" align="center">Admission challans of Third Merit List Master 2015 are available  from   <B>DECEMBER 31, 2014 to JANUARY 02, 2015 </B>.</div>-->

<?php

	   }
?>


