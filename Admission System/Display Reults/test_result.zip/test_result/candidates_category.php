<?php
    include_once './DatabaseManager.php';

if (isset($_REQUEST['seatNo'])) {
$con=DatabaseManager::connect();
    $programType = mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo =mysqli_real_escape_string($con,   $_REQUEST['seatNo']);
    $admListDetailId = mysqli_real_escape_string($con,  $_REQUEST['admission_list_detail_id']);

    $result = DatabaseManager::getCandidate($seatNo, $programType, $admListDetailId);
    ?>
    <ul>
        
            <?php
            $i = 0;
			
            if ($row = mysqli_fetch_array($result)) {
                if ($i == 0) {
                    $i++;
                    ?>
                    <div style="background-color: #169fe6; padding-top: 10px ;padding-bottom: 10px; padding-left: 5px;color: white; border-radius:  5px 0px 5px 0px; width: 200px;">CATEGORY</div>
                    <ul>
					<?php
                }
                $candidateId = $row['CANDIDATE_ID'];
				//echo($candidateId);
                 $categoryResult = DatabaseManager::getCategory($candidateId);
				//print_r($categoryResult);
					$count=0;
					while ($categoryRow = mysqli_fetch_array($categoryResult)) {
					$count++;
					   $category_name = $categoryRow['CATEGORY_NAME'];
                    echo "<li style='padding-bottom:2px; color:rgb(208, 88, 3); '>$count. $category_name</li>";
                }
                        
            }
            ?>
    </ul>
    <?php
}


?>

<!--       <div style="background-color: 169fe6; padding-top: 10px ;padding-bottom: 10px; padding-left: 5px; color: white; border-radius:  5px 0px 5px 0px; width: 200px;">IMPORTANT INSTUCTIONS </div>
  -->
  <?php         
  
	//echo("1.If you found any of the given details incorrect i.e. Your name, fname, domicile, marks, score, CPN and choices,  then please download the correction form and submit its scanned copy (with your own signature) on it and email it to the given addresses OR you can submit it in person to the Directorate of Admissions, Allama I.I. Kazi Campus, Jamshoro, from Monday to Friday, during office hours only.</br> ");
	//echo("2.However, if you have any objection regarding your selection then please then please download the correction form and submit its scanned copy (with your own signature) on it and email it to the given addresses alongwith details of your objection in Sindh, Urdu or English OR you can submit it in person to the Directorate of Admissions, Allama I.I. Kazi Campus, Jamshoro, from Monday to Friday, during office hours only.");


  ?>

