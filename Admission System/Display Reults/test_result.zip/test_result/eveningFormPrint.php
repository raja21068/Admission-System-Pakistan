<?php

//if (isset($_REQUEST['s'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
/* 
 $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['s']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);
    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
    if ($row = mysqli_fetch_array($result)) {
        $candidateId = $row['CANDIDATE_ID'];
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
        $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];

	
*/

require('fpdf/cellpdf.php');
class PDF extends FPDF{
		function Header(){
				$this->Image('images/logo.png',50,50,100);
		   
		//	$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size 
			 
			$this->SetFont('Arial','B',15);
			  $this->Cell($w,9,"University of Sindh Jamshoro Admission",1,1,'C',false);
			$this->Ln(10);
  		
		}
		function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}


		}

		$pdf=new CellPDF();
		$pdf->SetFont('Times','',20);
		$pdf->AddPage();
		$pdf->Image('images/logo.png',20,5,20);
		$pdf->Cell(0,8,"University of Sindh Jamshoro",0,1,'C',false);
		$pdf->Ln();
		$pdf->text(80,22,"Evening Admission");
		$pdf->Ln();
		$pdf->Image('images/right_logo.jpg',170,5,18);
		$pdf->Line(10,30,200,30);
		
		//getStudentData($seatNo,$name,$father,$ssc_perc,$hsc_perc,$test_perc,$cpn);
		PrintData::getStudentData($pdf,'12','dfsd','dfsd','sdfds','232','2132','121');
		$pdf->SetFont('Times','B',12);
		$pdf->text(125,38,"Choices");
		$pdf->Ln();
		$pdf->SetFont('Times','',12);
		$pdf->text(125,48,"Evening Admission");
		$pdf->Ln();
//getStudentData($seatNo,$name,$father,$ssc_perc,$hsc_perc,$test_perc,$cpn);
		
		$pdf->Ln();
		$pdf->Output();
	
	


//	$pdf->Cell(0,9,"Admission Resuls",0,1,'C',false);
		//$pdf->Ln();
	
       ?>
	   
	    	
	<?php
	class PrintData{	
		function getStudentData($pdf,$seatNo,$name,$father,$ssc_perc,$hsc_perc,$test_perc,$cpn){
		
		
			$w = array(90, 45, 120, 50,40,20);
			$h=8;
			$pdf->SetFont('Times','B',12);
	
		$pdf->Cell($w[1],$h,"PERSONAL INFORMATION",0,0,'C');
		$pdf->Ln();
		$pdf->SetFont('Times','',12);
		
		$pdf->Cell($w[1],$h,"Seat#",0,0,'L');
		$pdf->Cell($w[1],$h,"$seatNo",0,0,'L');
		$pdf->Ln();
		$pdf->Cell($w[1],$h,"Name",0,0,'L');
		$pdf->Cell($w[1],$h,"$name",0,0,'L');
		$pdf->Ln();
		
		$pdf->Cell($w[1],$h,"Father's Name:",0,0,'L');
		$pdf->Cell($w[1],$h,"$father",0,0,'L');
		$pdf->Ln();
		
		
		
		$pdf->Cell($w[1],$h,"SSC (Matric) Score:",0,0,'L');
		$pdf->Cell($w[1],$h,$ssc_perc,0,0,'L');
		$pdf->Ln();
		
	
			
		$pdf->Cell($w[1],$h,"HSC (Inter) Score:",0,0,'L');
		$pdf->Cell($w[1],$h,$hsc_perc,0,0,'L');
		$pdf->Ln();
		
		$pdf->Cell($w[1],$h,"TEST SCORE :",0,0,'L');
		$pdf->Cell($w[1],$h,$test_perc,0,0,'L');
		$pdf->Ln();
			
		$pdf->Cell($w[1],$h,"Total Score (CPN):",0,0,'L');
		$pdf->Cell($w[1],$h,$cpn,0,0,'L');
		$pdf->Ln();
		
		
	

}
		function getStudentChoices($pdf){
		
		
		
		}


	}//end class
		?>	
			
	   			  
		
		
      



