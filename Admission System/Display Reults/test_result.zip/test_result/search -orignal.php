

        <html>
            <head>
			<?php include('bar.php'); ?>
       
                <meta charset="utf-8">
                <title>University of Sindh</title>
                <link rel="icon" type="image/png" href="images/logo.png" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="description" content="">
                <meta name="author" content="">

               
                <link href="scripts/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">

                <link href="scripts/camera/css/camera.css" rel="stylesheet" type="text/css" />

                     </head>
            <body id="pageBody">
</br>
</br>
                <div id="container" class="container">

                    <div class="transparent-bg" style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;z-index: -1;zoom: 1;"></div>

                    <div class="divPanel notop nobottom" >
                        <div class="row-fluid" >
                            <div class="span12" >

                                                   </div>

                        <div class="row-fluid">
                            <div class="span12" >

                                <div class="camera_full_width" style="margin: -54px 0 0 0;">
                                    <div id="camera_wrap" style="margin: 0 0 0 0;">
                                        <div data-src="slider-images/uni_one.jpg" >
                                            
											<!--<div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                There are two powers in the world; <br>
                                                one is the sword and the other is the pen.<br> 
                                                There is a great competition and rivalry between the two.<br> 
                                                There is a third power stronger than both, that of the women<br>
                                                <strong>(Quaid-e-Azam Address to women).</strong>
                                                <br>
                                            </div>-->
                                        </div>
                                        <div data-src="slider-images/uni_two.jpg" >
                                            <!--<div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                Pakistan is proud of her youth, <br>
                                                particularly the students,<br>
                                                who are nation builders of tomorrow. <br>
                                                They must fully equip themselves by discipline,<br> 
                                                education, and training for the arduous task lying ahead of them <br>
                                                <strong>(Quaid-e-Azam Address to students).</strong><br>
                                            </div>-->
                                        </div>
                                        <div data-src="slider-images/uni_three.jpg" >
                                            <!--<div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                I insist you to strive. <br>
                                                Work, Work and only work for<br> 
                                                satisfaction with patience,<br>
                                                humbleness and serve thy nation. <br>
                                                <strong>(Quaid-e-Azam Quotes for Students).</strong><br>
                                            </div>-->
                                        </div>
                                    </div>
                                    <br style="clear:both"/><div style="margin-bottom:40px"></div>
                                </div>               

                                <div id="headerSeparator2"></div>

                            </div>
                        </div>
                    </div>

                    
  
 
                       

                            <script src="scripts/carousel/jquery.carouFredSel-6.2.0-packed.js" type="text/javascript"></script><script type="text/javascript">$('#list_photos').carouFredSel({responsive: true, width: '100%', scroll: 2, items: {width: 320, visible: {min: 2, max: 6}}});</script><script src="scripts/camera/scripts/camera.min.js" type="text/javascript"></script>
                            <script src="scripts/easing/jquery.easing.1.3.js" type="text/javascript"></script>
                            <script type="text/javascript">function startCamera() {
                                    $('#camera_wrap').camera({fx: 'scrollLeft', time: 4000, loader: 'none', playPause: false, navigation: true, height: '35%', pagination: true});
                                }
                                $(function() {
                                    startCamera()
                                });</script>

                            </body>
                            </html>
                  
                