<?php




if (isset($_REQUEST['seatNo'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['seatNo']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);


    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
	$countrows=mysqli_num_rows($result);
	 if ($row = mysqli_fetch_array($result)) {
	    $candidateId = $row['CANDIDATE_ID'];
		//echo($candidateId);
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
        $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];


		
       ?>
	   
        <table class='table table-bordered' >

             <!--<tr><td style="background-color: #006633; color: white; " colspan="2"><strong>Congratulations, You are selected..!</strong></td></tr>-->
      
   <tr><td>Seat#:</td><td><strong><?php echo $seatNo; ?></strong></td></tr>
            <tr><td>Name of the Candidate:</td><td><strong><?php echo $name; ?></strong></td></tr>
            <tr><td>Father<span>'<span>s Name:</td><td><strong><?php echo $father; ?></strong></td></tr>
            <tr><td>District (Domicile):</td><td><strong><?php echo $district; ?></strong></td></tr>
            <tr><td>Urban/Rural:</td><td><strong><?php  if ($area=="U" || $area=="0" ){echo("URBAN");}else{echo("RURAL");} ?></strong></td></tr>
			
            <tr><td>SSC (Matric) Marks:</td><td><strong><?php echo $ssc_obt; ?></strong></td></tr>
			<?php
			//if($admissionListDetailId!=0){
			?>
			<tr><td>SSC Total Marks:</td><td><strong><?php echo $ssc_total_marks; ?></strong></td></tr>
			<tr><td>SSC Year:</td><td><strong><?php echo $ssc_year; ?></strong></td></tr>
		<?php //} ?>
			<!-- change 68 to 71-->
			<!-- change finish to -->
<!-- change start -->
		<!-- change finish to -->
          
		<tr><td>HSC (Inter) Marks:</td><td><strong><?php echo $hsc_obt; ?></strong></td></tr>
				<?php
			//if($admissionListDetailId!=0){
			?>	
			<tr><td>HSC Total Marks:</td><td><strong><?php echo $hsc_total_marks; ?></strong></td></tr>
			<tr><td>HSC Year:</td><td><strong><?php echo $hsc_year; ?></strong></td></tr>
			
			<?php //}?>
			
		   <tr><td><?php if($programType == 1) echo("HSC Group"); else echo("Degree");?>:</td><td><strong><?php echo $degree; ?></strong></td></tr>
				<?php
	//		if($admissionListDetailId!=0){
			?>	
		
   		<tr><td>HSC Board:</td><td><strong><?php echo $last_issuer; ?></strong></td></tr>
			<?php 	// }?>

		<tr><td>TEST MARKS:</td><td><strong><?php echo $test_score; ?></strong></td></tr>

				  <tr><td>SSC (Matric) Score[10]:</td><td><strong><?php echo $ssc_perc; ?></strong></td></tr>
            <tr><td> HSC (Inter) Score[<?php if ($programType == 2) {
            echo "15";
        } else {
            echo "50";
        } ?>]:</td><td><strong><?php echo $hsc_perc; ?></strong></td></tr>
		
		
            <?php if ($programType == 2) { ?>
                <tr><td>Graduation:</td><td><strong><?php echo $degree; ?></strong></td></tr>
                <tr><td>Graduation / Post-Graduation  marks:</td><td><strong><?php echo $grad_obt; ?></strong></td></tr>
                <tr><td>Graduation / Post-Graduation score[35]:</td><td><strong><?php echo $grad_perc; ?></strong></td></tr>
            <?php } ?>
        <?php if ($deductionMarks != 0) { ?>
                <tr><td>DEDUCTION MARKS:</td><td><strong><?php echo $deductionMarks; ?></strong></td></tr>
                <tr><td>MARKS AFTER DEDUCTION:</td><td><strong><?php echo $marksAfterDeduction; ?></strong></td></tr>
            <?php } ?>
        
            <tr><td>TEST SCORE [40]:</td><td><strong><?php echo $test_perc; ?></strong></td></tr>
            <tr><td>Total Score (CPN)[100]:</td><td><strong><?php echo $cpn; ?></strong></td></tr>
                        <?php if ($objectionRemarks != "") { ?>
                <tr><td style="color: white; background-color: red;">Objection Remarks:</td><td style="color: white; background-color: red;"><strong><?php echo "$objectionRemarks"; ?></strong></td></tr>
        <?php } ?>
        <?php
		
		if($admissionListDetailId==0){
		return;
		}
		
		if ($campus == "") {
		
	    echo '<br/><h4>Yor are not selected, please wait for next merit list</h4>';
    	return;
		}
		if($discipline=='0'){
		echo '<br/><h4>Yor are not selected, please wait for next merit list</h4>';
		return;
	    }
            ?>   

                
                <tr><td colspan='2'><strong>You are selected in:</strong></td></tr>

                <tr><td>Program:</td><td><strong><?php echo $discipline; ?></strong></td></tr>
                <tr><td>Category:</td><td><strong><?php echo $category; ?></strong></td></tr>
				<tr style="margin-bottom:10px;"><td>Campus: </td><td ><strong> <?php echo $campus; ?></strong></td></tr>
				<tr><td colspan=2></td></tr>
                
                <?php
                while ($row = mysqli_fetch_array($result)) {
                    $campus = $row['CAMPUS'];
                    $category = $row['CATEGORY'];
                    $discipline = $row['DISCIPLINE'];
                    $campusId2 = $row['CAMPUS_ID'];

                    ?>
                    <tr><td>Program:</td><td><strong><?php echo $discipline; ?></strong></td></tr>
                    <tr><td>Category:</td><td><strong><?php echo $category; ?></strong></td></tr>

                <?php
				
//                if ($campusId2 != $campusId) {
                    echo "<tr><td>Campus: </td>  <td><strong>$campus</strong></td></tr>";
					
                    $campusId = $campusId2;
                    //              }
				?>
				<tr><td colspan=2></td></tr>
              
				<?php
            }
        
		
		
					$resultfees=DatabaseManager::getFees($candidateId);
					$count=mysqli_num_rows($resultfees);
			
						if($count>0){		
						$rowfees = mysqli_fetch_array($resultfees);
						
						if ($rowfees) {
						$challan_no = $rowfees['CHALLAN_NO'];
						$amount = $rowfees['AMOUNT'];
						$challan_date = $rowfees['CHALLAN_DATE'];
						$fees_type = $rowfees['FEE_TYPE'];

        ?>
								<tr><td>Paid Amount:</td><td><strong><?php echo $amount; ?></strong></td></tr>
								<tr><td>Challan No:</td><td><strong><?php echo $challan_no; ?></strong></td></tr>
								<tr><td>Date Of Payment:</td><td><strong><?php echo $challan_date; ?></strong></td></tr>

		



        <?php
		
		    }
	}//end count if
        if ($choiceNo != 1) {
            ?>    
					<!--
                        <p style="font-size:18px; color: #8C0209;" align="right">&#1580;&#1610;&#1706;&#1679;&#1726;&#1606; &#1706;&#1608; &#1575;&#1615;&#1605;&#1610;&#1583;&#1608;&#1575;&#1585; &#1605;&#1615;&#1606;&#1578;&#1582;&#1576; &#1663;&#1610;&#1604; &#1605;&#1590;&#1605;&#1608;&#1606; &#1790; &#1574;&#1610; &#1662;&#1689;&#1726;&#1723; &#1670;&#1575;&#1726;&#1610; &#1663;&#1608; &#1578;&#1607; &#1583;&#1575;&#1582;&#1604;&#1575; &#1601;&#1616;&#1610;&#1587; &#1705;&#1575;&#1606; &#1593;&#1604;&#1575;&#1608;&#1607; 2 &#1587;&#1574;&#1608; &#1585;&#1608;&#1662;&#1610;&#1606; &#1580;&#1608; &#1670;&#1575;&#1604;&#1575;&#1606; &#1580;&#1605;&#1593; &#1706;&#1585;&#1575;&#1574;&#1610;  &#1789; &#1575;&#1726;&#1689;&#1610; &#1583;&#1585;&#1582;&#1608;&#1575;&#1587;&#1578;  &#1578;&#1607; &#1580;&#1574;&#1610;&#1606; &#1575;&#1606; &#1575;&#1615;&#1605;&#1610;&#1583;&#1608;&#1575;&#1585; &#1580;&#1610; &#1583;&#1575;&#1582;&#1604;&#1575; &#1706;&#1606;&#1726;&#1606; &#1659;&#1574;&#1610; &#1605;&#1590;&#1605;&#1608;&#1606; &#1790; &#1578;&#1576;&#1583;&#1610;&#1604; &#1606;&#1607; &#1663;&#1574;&#1610; 
                </p>
                <p style="font-size:18px; color: #8C0209;" align="right">&#1575;&#1711;&#1585; &#1705;&#1608;&#1574;&#1740; &#1575;&#1605;&#1740;&#1583;&#1608;&#1575;&#1585; &#1605;&#1606;&#1578;&#1582;&#1576; &#1588;&#1583;&#1729; &#1726;&#1608;&#1574;&#1746; &#1605;&#1590;&#1605;&#1608;&#1606; &#1605;&#1740;&#1722; &#1729;&#1574; &#1662;&#1681;&#1726;&#1606;&#1575; &#1670;&#1575;&#1726;&#1578;&#1575; &#1729;&#1746; &#1578;&#1608; &#1575;&#1587;&#1746; &#1670;&#1575;&#1729;&#1574;&#1746; &#1705;&#1729; &#1583;&#1575;&#1582;&#1604;&#1575; &#1601;&#1740;&#1574;&#1587; &#1705;&#1729; &#1593;&#1604;&#1575;&#1608;&#1729; &#1583;&#1608; &#1587;&#1574;&#1608; &#1585;&#1608;&#1662;&#1740;&#1729; &#1670;&#1575;&#1604;&#1575;&#1606; &#1580;&#1605;&#1593; &#1705;&#1585;&#1575;&#1747; &#1578;&#1575; &#1705;&#1729; &#1575;&#1587; &#1575;&#1605;&#1740;&#1583;&#1608;&#1575;&#1585; &#1705;&#1740; &#1583;&#1575;&#1582;&#1604;&#1575; &#1705;&#1587;&#1740; &#1575;&#1608;&#1585;  
                    </p>
                <p style="font-size:15px;">
                    If any candidate wish to study in selected choice, he/she must deposit rs.200 in separate bank challan with application so that his/her choice may not be changed.
                </p>-->
				
            <?php
        }
    ?>
	<?php
    } // end if mysql_affected_rows (candidate)
	else {
		if($admissionListDetailId==0){
		
	
	echo ("<tr><td class='danger'><h4>Invaild Seat No</h4></td></tr>");
		 return;
		}
		if($admissionListDetailId==1){
		 echo '<br/><h4>You are not selected, please wait for next merit list..</h4>';
		 return;
		}
		
	
		
		$resultAdmi = DatabaseManager::getCandidateFromSession($seatNo, $programType, $admission_session);
		 if ($rowAdmi = mysqli_fetch_array($resultAdmi)) {
		   echo '<br/><h4>You are selected in Pervious Merit List</br>';
				$candidateId = $rowAdmi['CANDIDATE_ID'];
		   		$resultfees1=DatabaseManager::getFees($candidateId);
				$rowfees = mysqli_fetch_array($resultfees1);
							if($rowfees==false){
						echo("<tr><td  colspan='2' class='danger'>Your admission is cancelled now, as you haven<span>'</span>t paid the fees within due date i.e. 15th December 2014. Now you are out of competition and you will not be considered for admission in 3rd merit selection.</td></tr> ");		
						}
		   	return;

		 }
       		
		else {
            echo '<br/><h4>You are not selected, please wait for next merit list..</h4>';
					 return;

        }
				
    }
}//if seatNo
					echo("<tr><td colspan='2'><a href='print.php?program_type=$programType&s=$seatNo&admission_list_detail_id=$admissionListDetailId&admission_session=$admission_session'><img src='images/print-icon.jpg' height='10' width='10' align='center'></a></td></tr>");

?>

           </table>
    				
</br>
