<link rel="stylesheet"  href="css/bootstrap.min.css">
                    <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
<?php
 require_once './DatabaseManager.php';
   $con=DatabaseManager::connect();

if (isset($_REQUEST['program_type'])) {
    $program_type_id = mysqli_real_escape_string($con, $_REQUEST['program_type']);
    $deptName = mysqli_real_escape_string($con, $_REQUEST['dept_name']);

 ?>	
        <h3 align="center" style="color: red;"><?php echo $deptName; ?></h3>

       <div class="col-xs-12">
	   <table   class="table table-striped table-bordered">
            <tr class='info'>
				<!--<th style="text-align: center;">S#</th>-->
                <th style="text-align: center;">SEAT#</th>
                <th style="text-align: center;">CANDIDATE NAME</th>
                <th style="text-align: center;">FATHER<SPAN>'</SPAN>S NAME</th>
                <th style="text-align: center;">PERCENT SCORE</th>
                <th style="text-align: center;">TEST SCORE</th>
                <th style="text-align: center;">REMARKS</th>
            </tr>
            <?php
            $result2 = DatabaseManager::getMphliDepartmentList($deptName, $program_type_id);
            $sNo=0;
			while ($row2 = mysqli_fetch_array($result2)) {
				$sNo++;             
				echo "<tr>";
				//echo "      <td>" . $sNo . "</td>";
                echo "      <td>" . $row2['SEAT_MO'] . "</td>";
                echo "      <td>" . $row2['NAME'] . "</td>";
                echo "      <td>" . $row2['FATHER_NAME'] . "</td>";
				echo "      <td>" . $row2['PERCENT_SCORE'] . "</td>";
				echo "      <td>" . $row2['TOTAL_SCORE'] . "</td>";
				echo "      <td>" . $row2['REMARKS'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
		</div>
            <?php
        }
    
    ?>
