﻿<!DOCTYPE HTML>
<style>

    .sidebar {
        float: left;
        width: 220px;
        padding: 0;
        font-size: 12px;
    }
    #sidebar1 {
        float: left;
    }
    #sidebar2 {
        float: right;
    }
    .sidebar ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }
    .sidebar li {
        padding: 0 0 20px 0;
    }

    .sidebar li li {
        margin: 0 20px 0 15px;
        padding: 8px 0px;
        border-bottom: 1px #BBBBBB dashed;
    }
    .sidebar li h2 {
        height: 30px;
        margin: 0 0 0 0;
        padding: 10px 15px 0px 15px;
        background: #890208 url(images/img05.jpg) no-repeat left top;
        letter-spacing: -1px;
        font-size: 16px;
        color: #FFFFFF;
    }

    #sidebar {
        float: right;
        width: 300px;
    }

    #sidebar-bgtop {
        height: 3px;
    }

    #sidebar-bgbtm {
        height: 3px;
    }

    #sidebar-content {
        padding: 20px;
    }

    #sidebar ul {
        margin: 0px;
        padding: 0px;
        list-style: none;
    }

    #sidebar li ul {
        margin-bottom: 1.8em;
        list-style: none;
    }

    #sidebar li li {
        padding: 5px 0;
        border-bottom: #BFC9AE dashed 1px;
    }

    #sidebar h2 {
        padding: 4px 20px;
        background: #393939;
        font-size: 1.2em;
        color: #FFFFFF;
    }

    #sidebar a {
        text-decoration: none;
        color: #232F01;
    }

    #sidebar a:hover {
        text-decoration: underline;
    }
    #content {
        float: left;
        width: 550px;
    }

    .campus{
        font-weight: bold;
    }
</style>

<?php
if (isset($_REQUEST['admission_session'])) {
    $admSession = $_REQUEST['admission_session'];
    $progType = $_REQUEST['program_type'];
    $admListDetailId = $_REQUEST['admission_list_detail'];

    require_once './DatabaseManager.php';
    $result = DatabaseManager::getAdmissionSession($admListDetailId);

    if ($rowSession = mysqli_fetch_array($result)) {
        $admission_session = $rowSession['ADMISSION_SESSION'];
        ?>
        <html>
            <head>
			<?php include('header.php'); ?>
       
                <meta charset="utf-8">
                <title>University of Sindh</title>
                <link rel="icon" type="image/png" href="images/logo.png" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="description" content="">
                <meta name="author" content="">

                <link href="scripts/bootstrap/css/bootstrap.min.css" rel="stylesheet">
                <link href="jk_style.css" rel="stylesheet">
                <link href="scripts/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">


                <!-- Icons -->
                <link href="scripts/icons/general/stylesheets/general_foundicons.css" media="screen" rel="stylesheet" type="text/css" />  
                <link href="scripts/icons/social/stylesheets/social_foundicons.css" media="screen" rel="stylesheet" type="text/css" />
                <!--[if lt IE 8]>
                    <link href="scripts/icons/general/stylesheets/general_foundicons_ie7.css" media="screen" rel="stylesheet" type="text/css" />
                    <link href="scripts/icons/social/stylesheets/social_foundicons_ie7.css" media="screen" rel="stylesheet" type="text/css" />
                <![endif]-->
                <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
                <!--[if IE 7]>
                    <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome-ie7.min.css">
                <![endif]-->

                <link href="scripts/carousel/style.css" rel="stylesheet" type="text/css" />
                <link href="scripts/camera/css/camera.css" rel="stylesheet" type="text/css" />

                <link href="http://fonts.googleapis.com/css?family=Syncopate" rel="stylesheet" type="text/css">
                <link href="http://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
                <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" type="text/css">
                <link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
                <link href="http://fonts.googleapis.com/css?family=Pontano+Sans" rel="stylesheet" type="text/css">
                <link href="http://fonts.googleapis.com/css?family=Oxygen" rel="stylesheet" type="text/css">

                <link href="styles/custom.css" rel="stylesheet" type="text/css" />
				     </head>
            <body id="pageBody">
</br>
</br>

                <div id="divBoxed" class="container">

                    <div class="transparent-bg" style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;z-index: -1;zoom: 1;"></div>

                    <div class="divPanel notop nobottom" >
                        <div class="row-fluid" >
                            <div class="span12" >

                        
<!--<div style="float:right; width:90px; ">
                                <?php echo date("d.m.Y"); ?>
                            </div>-->
                                                        </div>

                        <div class="row-fluid">
                            <div class="span12" >

                                <div class="camera_full_width" style="margin: 0 0 0 0;">
                                    <div id="camera_wrap" style="margin: 0 0 0 0;">
                                        <div data-src="slider-images/uni_one.jpg" >
                                            <div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                There are two powers in the world; <br>
                                                one is the sword and the other is the pen.<br> 
                                                There is a great competition and rivalry between the two.<br> 
                                                There is a third power stronger than both, that of the women<br>
                                                <strong>(Quaid-e-Azam Address to women).</strong>
                                                <br>
                                            </div>
                                        </div>
                                        <div data-src="slider-images/uni_two.jpg" >
                                            <div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                Pakistan is proud of her youth, <br>
                                                particularly the students,<br>
                                                who are nation builders of tomorrow. <br>
                                                They must fully equip themselves by discipline,<br> 
                                                education, and training for the arduous task lying ahead of them <br>
                                                <strong>(Quaid-e-Azam Address to students).</strong><br>
                                            </div>
                                        </div>
                                        <div data-src="slider-images/uni_three.jpg" >
                                            <div class="camera_caption fadeFromRight cap2" style="background:none;  opacity: 0.0;height: 100%;  text-transform: none;">
                                                I insist you to strive. <br>
                                                Work, Work and only work for<br> 
                                                satisfaction with patience,<br>
                                                humbleness and serve thy nation. <br>
                                                <strong>(Quaid-e-Azam Quotes for Students).</strong><br>
                                            </div>
                                        </div>
                                    </div>
                                    <br style="clear:both"/><div style="margin-bottom:40px"></div>
                                </div>               

                                <div id="headerSeparator2"></div>

                            </div>
                        </div>
                    </div>

                    <div class="contentArea">

                        <div class="divPanel notop page-content" >


                            <div class="row-fluid">
                                <!--Edit Main Content Area here-->
                                <div class="span12" id="divMain" style="margin-top: -5px;">
                                    <?php include './heading.php'; ?>
                                    <br />                   


                                    <div id="sidebar1" class="sidebar"  >

                                    </div>

                                    <div id="content"  style="padding-left:20px; border-radius: 5px 0 5px 0px;  border:1px solid #002a80;">
                                        <input type="radio" style="display: none;" name="program_type" id="bachelor_program_type" value="1" <?php if ($progType == 1) echo "checked='true'" ?> />
                                        <input type="radio" style="display: none;" name="program_type" value="2" id="master_program_type" <?php if ($progType == 2) echo "checked='true'" ?>/>
                                        <br/>
                                        Seat No.<input style="margin-left: 5px;" type="text" name="s" id="seat" size="15" value="" />
                                        <input type="button" id="search" class="button" style="border: none; border-radius: 4px 4px 4px 4px;" value="Search" />





                                        <img src="images/ajax-process-small.gif" id="ajax-ico" style="display: none;"/>

                                        <div id="panel">
                                        </div>
                                    </div>
                                     <!--
                                    <div id="sidebar2" class="sidebar"  >
                                        <ul>
                                            <li>
                                                <ul><li><a href="" style="color: blue;" href="">Home </a></li>
                                                    <li><a href="" style="color: blue;" href="http://www.usindh.edu.pk/faculty-a-staff.html">Faculty & Staff</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/financial-support.html">Financial Support</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/academics/central-library.html">Central Library</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/sutc.html">Testing Center</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/blogs">News & Events</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/distribution-of-seats.html">Distribution of Seats</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/fees-structure.html">Fees Structure</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/how-to-apply.html">How to apply?</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/general-regulations.html">General Regulation</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/graduate-degree-programs.html">Graduation Degree Programs</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/post-graduate-degree-programs.html">Post Graduation Degree Programs</a></li>
                                                    <li><a href=""style="color: blue;" href="http://www.usindh.edu.pk/admissions/student-welfare-programs.html">Student Welfare Programs</a></li> \
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                </div> -->
                                <!--End Main Content-->
                            </div>
</br>
  </br>
 </br>
  </br>
  
 
                            <div id="footerInnerSeparator">
                                <?php
                                if($progType==2){
                                include './footer.php';
                                }else{
                                    
                              include './footer1.php';
                                    
                                    
                                }
                                ?>
                            </div>
                            <div id="footerOuterSeparator">
                                <?php include './info.html'; ?>
                            </div>
							 		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1801.8774815946902!2d68.2629579!3d25.4130116!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc33e04561e85ca48!2sUniversity+of+Sindh!5e0!3m2!1sen!2s!4v1415361348827" width="100%" height="600" frameborder="0" style="border:0"></iframe>

                            <br /><br /><br />
                                       
					<div class="navbar-inner">
	
                                        <div class="nav-collapse collapse">
                                            <ul class="nav nav-pills ddmenu">
                                          <li><a href="http://www.usindh.edu.pk" style="color: blue;" href="">Home </a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/faculty-a-staff.html">Faculty & Staff</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/financial-support.html">Financial Support</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/academics/central-library.html">Central Library</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/sutc.html">Testing Center</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/blogs">News & Events</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/distribution-of-seats.html">Distribution of Seats</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/fees-structure.html">Fees Structure</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/how-to-apply.html">How to apply?</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/general-regulations.html">General Regulation</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/graduate-degree-programs.html">Graduation Degree Programs</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/post-graduate-degree-programs.html">Post Graduation Degree Programs</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/student-welfare-programs.html">Student Welfare Programs</a></li> \
                                             </ul>
                                        </div>
                               </div>
    


                            <script src="scripts/jquery.min.js" type="text/javascript"></script> 
                            <script src="scripts/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
                            <script src="scripts/default.js" type="text/javascript"></script>


                            <script src="scripts/carousel/jquery.carouFredSel-6.2.0-packed.js" type="text/javascript"></script><script type="text/javascript">$('#list_photos').carouFredSel({responsive: true, width: '100%', scroll: 2, items: {width: 320, visible: {min: 2, max: 6}}});</script><script src="scripts/camera/scripts/camera.min.js" type="text/javascript"></script>
                            <script src="scripts/easing/jquery.easing.1.3.js" type="text/javascript"></script>
                            <script type="text/javascript">function startCamera() {
                                    $('#camera_wrap').camera({fx: 'scrollLeft', time: 4000, loader: 'none', playPause: false, navigation: true, height: '35%', pagination: true});
                                }
                                $(function() {
                                    startCamera()
                                });</script>

                            <script>
                                $('#search').click(function() {
                                    $('#ajax-ico').show();
                                    var type = $('input[name=program_type]:checked').val();
                                    var seat = $("#seat").val();
                                    if (seat == "") {
                                        $('#ajax-ico').hide();
                                        return;
                                    }
                                    $.post("result.php", {
                 
                                        seatNo: seat
                                    }, function(response) {
                                        $("#panel").html(response);

                                        $.post("choices.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#sidebar1").html(response);
                                            $('#ajax-ico').hide();
                                        });
                                    });
                                });

                                $("#seat").keypress(function(e) {
                                    if (e.which == 13) {
                                        $('#ajax-ico').show();
                                        var type = $('input[name=program_type]:checked').val();
                                        var seat = $("#seat").val();
                                        if (seat == "") {
                                            $('#ajax-ico').hide();
                                            return;
                                        }
                                        $.post("selection.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            admission_session: <?php echo "$admission_session"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#panel").html(response);

                                            $.post("choices.php", {
                                                admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                                program_type: type,
                                                seatNo: seat
                                            }, function(response) {
                                                $("#sidebar1").html(response);
                                                $('#ajax-ico').hide();
                                            });
                                        });
                                    }
                                });
                            </script>
                            </body>
                            </html>
                            <?php
                        } else {
                            echo "<h2>Unexpected Path...</h2>";
                        }
                    } else {
                        echo "<h2>Unexpected Path...</h2>";
                    }
                    ?>