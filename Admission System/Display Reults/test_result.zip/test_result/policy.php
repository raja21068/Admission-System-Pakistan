<link 'http://fonts.googleapis.com/css?family=Open+Sans'>

</br>
</br>
<h4 align="center"><B>ADMISSION CRITERIA(RULES & REGULATIONS)</B><H4>
<P style="font-size: 14; font-family:Times New Roman;">

a.     The merit for admissions shall be determined on the basis of Pre-entry Test score and the total marks obtained in the first attempt as well as previous academic record. However, candidates not qualify the Pre-Entry-Test will not be considered for admission in any discipline..
The weightage assigned to the Pre-entry test and previous academic record will be as under:-
For Admission to
</p>
<TABLE BORDER="1" align="center">
<TR>
<TD>SNO</TD>
<TD></TD>
<TD>Bachelor</TD>
<TD>Master</TD>
</TR>
<TR>
<TD>1</TD>
<TD>S.S.C.</TD>
<TD> 10<SPAN>%</SPAN> </TD>
<TD> 10<SPAN>%</SPAN></TD>
</TR>
<TR>
<TD>2</TD>
<TD>H.S.C. (adjusted marks)</TD>
<TD>50<SPAN>%</SPAN></TD>
<TD>15<SPAN>%</SPAN></TD>
</TR>
<TR>
<TD>3</TD>
<TD>Bachelor Degree (-do-) </TD>
<TD>--</TD>
<TD>35<SPAN>%</SPAN></TD>
</TR>
<TR>
<TD>4</TD>
<TD>Pre-Entry Test / Aptitude test</TD>
<TD>40<SPAN>%</SPAN></TD>
<TD>40<SPAN>%</SPAN></TD>
</TR>
<TR>
<TD>5</TD>
<TD>Interview </TD>
<TD>--</TD>
<TD>--</TD>
</TR>
 </TABLE>           
<P style="font-size: 14; font-family:Times New Roman;">
 b.     In case of improvers/ repeaters, marks shall be deducted as per rules from the total marks of the candidates in order to prepare the adjusted merit list. This deduction shall not alter the division/ grade of the candidates.</BR>
(i)   05 marks to be deducted if the candidate has appeared second time in H.S.C. Examination in order to improve his/ her Division/ Grade.</BR>
(ii)  In case H.S.C. Examination has not been cleared within the minimum period required for passing the same after passing Matriculation Examination, every additional year or part of a year beyond this period shall be treated as candidate’s attempt for the purpose of deducting marks irrespective of his/ her having not appeared in the examination in each year.</BR>
(iii) 05 marks shall be deducted from the total marks for the loss of each extra year or part thereof.</BR>
However, a maximum of 25 marks may be deducted.
(iv)  Same rules shall apply if a candidate fails to clear Bachelor degree Examination within the minimum period required for passing such examination after Matriculation Examination.</BR>
(v)   05 marks per year shall be deducted from the total marks if the candidate has not passed the pre-requisite examination in the preceding year.</BR>
Eligibility & other Rules
a)    No admission shall be allowed to a candidate who has passed the pre-requisite examination in Third Division from any Board  or University.</BR>
b)    A student of B.A./ Hons./ B.S/ B.Com. (Hons.) Part-I Class shall be allowed transfer from the University to an affiliated college within three months from the last date of admission, but no transfer from college to University is allowed.</BR>
c) No change of subject shall be allowed after closing of admission.</BR>
d) The admissions to various Bachelor (Honours) and Master (Prev.) professional/ quota-oriented courses of study shall be made in accordance with the Regulations prescribed for the purpose.</BR>
e)    The fairness, transparency and correctness in admissions will be monitored and enforced by a committee of Senior Professors of the University appointed by the Vice-chancellor with Director Admissions as its Secretary. Pre-Entry Test will also be conducted under the supervision of this Committee.</BR>
f)      A candidate who has passed H.S.C. Science,  Commerce or H.S.C. Home Economics Examination is also eligible for admission to 4-yr. Bachelor/ B.A. (Hons) program.
g)    Candidates who are interested in seeking admission in the Institute of Art & Design shall also have to take up Aptitude Test to be conducted by the Institute, as per schedule to be announced by the Director.</BR>
Aptitude Test is also mandatory for admission to the newly introduced B.S.H.P.E. Part-I course of study.</BR>
h)    A candidate who has already completed his/her course of study in a University Teaching Institute/ Department/ Centre leading to Bachelor’s (Pass/ Honours) degree shall NOT be eligible for admission to another  or second Bachelor’s (Pass/ Honours) course (except B.Ed./ B.H. P.E., and Post Graduate Diplomas)  in the University Teaching Institute/ Department/ Centre.</BR>
i)      A candidate who has already passed Bachelor’s Pass degree course examination from the University of Sindh or any other university, shall NOT be eligible for admission to another Bachelor’s (Pass/ Honours) course excepting  B.Ed. or B.H. P.E., and Post Graduate Diploma courses programs.</BR>
j)      Admission on migration basis from other Universities to this University shall be considered on the following grounds:</BR>
a)  The student has cleared all the subjects/papers of the last examination from the parent University.
b)  Parents of the student who are Government Officials are posted within the territorial jurisdiction of the University of Sindh.</BR>
c)   Admission on migration basis in the following Quota-Oriented disciplines will only be permissible under Self Finance Scheme:-</BR>
Business Administration/ Computer Science/ Information Technology/Telecommunication/ Electronics/ Geology/ Pharmacy/ Public Administration.</BR>
</p>