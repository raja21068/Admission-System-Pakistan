<?php
require_once  './fpdf.php';
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFontSize(10);
$pdf->Cell(20, 40, "hello");
$pdf->Output();

?>
