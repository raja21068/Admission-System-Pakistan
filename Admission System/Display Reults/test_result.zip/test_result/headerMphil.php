<?php
/**
 * Created by PhpStorm.
 * User: RAJA DELL LAPTOP
 * Date: 10/18/2015
 * Time: 6:17 PM
 */?>
<h4 align="center" >ENTRY TEST  RESULT FOR MS/MPHIL DEGREE PROGRAMS 2016</h4>
