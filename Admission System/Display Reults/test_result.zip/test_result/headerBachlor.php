<?php  if ($admListDetailId==0){
    
	?>
	<h4 align="center" >ENTRY TEST  RESULT FOR BACHELORS DEGREE PROGRAMS 2016</h4>

	<?php
	}
	?>
<?php  if ($admListDetailId==1){
    ?>

	<h4>FIRST  MERIT SELECTION  RESULT FOR BACHELORS DEGREE PROGRAMS 2016</h4>
	
<!--<div style="color:red" align="center">Last date for sumbmission of  objection (if any) <B>NOVEMBER 25, 2015</B>.</div>-->
	<div style="color:red" align="center">Last date for the payment of Admission Fees is  <B>DECEMBER 08, 2015</B>.</div>

<!--<div style="color:red" align="center">After removing of objection first merit list will be displayed on  <B>NOVEMBER 26, 2015</B>.</div>-->

<!--<div style="color:red" align="center">admission fee challans of First Merit List are available from  <B>NOVEMBER 26, 2015</B>.</div>-->
</br>
<?php }?>
	
<?php  if ($admListDetailId==2){
    ?>

	<h4 >SECOND  MERIT SELECTION RESULT FOR BACHELORS DEGREE PROGRAMS 2016</h4>
<!--<div style="color:red" align="center">Last date for sumbmission of  objection (if any) <B>DECEMBER 12, 2015</B>.</div>-->
	<div style="color:red" align="center">Last date for the payment of Admission Fees is  <B>DECEMBER 23, 2015</B>.</div>
	<!--<div style="color:red" align="center">Admission Challans of Second Merit Selection of Bachelors' Degree Programs 2015 can be obtained from the Directorate of Admissions and deposited in Bank with effect from <B>DECEMBER 24, 2014 to  DECEMBER 29, 2014</B>.</div>-->
	 
	
	<?php }?>

	<?php  if ($admListDetailId==3){
    ?>

<!--	<h4 >THIRD PROVISIONAL MERIT RESULT FOR BACHELORS DEGREE PROGRAMS 2016</h4>-->
		<h4 >THIRD  MERIT RESULT FOR BACHELORS DEGREE PROGRAMS 2016</h4>

    <!--<div style="color:red" align="center">Last date for sumbmission of  objection (if any) <B>DECEMBER 28, 2015</B>.</div>-->

	<div style="color:red" align="center">Last date for the payment of Admission Fees is  <B>DECEMBER 31, 2015</B>.</div> 
	
	<?php } ?>

		<?php  if ($admListDetailId==4){
    ?>

	<h5>FOURTH SUPPLEMENTAL ADMISSIONS LIST  FOR BACHELOR DEGREE (EVENING) PROGRAMS 2016</h5>
	
	<?php }?>
	
		<?php  if ($admListDetailId==5){
    ?>

	<h5>PROVISIONAL SUPPLEMENTAL ADMISSIONS LIST  FOR BACHELOR DEGREE  PROGRAMS 2015</h5>
	<div style="color:red" align="center">The candidates can submit objections (if any) upto Friday, <B>20-03-2015</B> at Directorate of Admissions University of Sindh within office hours.
	</BR>Final List of candidates enrolled on leftover vacant seats along-with roll numbers will be sent to the concerned institutes / departments on <B>MARCH 24, 2015</B>.</div>
	<div style="color:red" align="center">The University of Sindh reserves the right to rectify any error / omission detected later on and also reserves the right to cancel any provisional admission at any time without issuing notice.</div>

	<?php }?>
