</div>
</div>
</div>
</div>
<!-- Footer / End -->


<!-- Footer Bottom / Start  -->
<footer id="footer-bottom">
		<!-- Copyrights -->
	
	<!-- 960 Container -->
	<div class="container">


		<!-- Menu -->
		<div class="eight columns">
			<nav id="sub-menu">
				<ul>
		
                                                      <li><a href="http//www.usindh.edu.pk" href="">Home </a></li>
                                                    <li><a   href="http://www.usindh.edu.pk/faculty-a-staff.html">Faculty & Staff</a></li>
                                                    <li><a  href="http://www.usindh.edu.pk/academics/central-library.html">Central Library</a></li>
                                                    <li><a  href="http://www.usindh.edu.pk/sutc.html">Testing Center</a></li>
                                                    <li><a  href="http://www.usindh.edu.pk/blogs">News & Events</a></li>
                                                     
    		</ul>
			</nav>
			<!--<font color="white">Devloped By:  <a href="">Raja </a></font>-->
		</div>

	</div>

	<!-- 960 Container / End -->

</footer>
<!-- Footer Bottom / End -->




</body>
</html>