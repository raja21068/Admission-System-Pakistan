<?php
	if ($admListDetailId==1 || $admListDetailId==2){

?>
<ol type='1'>
<div>
<li>    The student desirous of retaining the discipline allocated in first offer may do so by submitting their acceptance in writing along-with paid challan of Rs.200/- to be issued by the Assistant Director Admissions up to last date of submission of admission fee.  Otherwise their choice of preference may be changed automatically (if eligible) in next merit list. </li></br>
</div>
<li><div> Those prospective students selected in their subject as mentioned at choice No: 01 are not required to deposit challan of retaining fee.  </div></li></br>
<li><div>After due date no request for retaining of subject will be entertained</div></li></br>
<li><div>No application will be entertained for change of choice/subject.   </div></li></br>
<li><div>Once a choice of the discipline is assigned to a student, he/she will not be assigned lower choice(s) at later stage or in next merit list(s) </div></li></br>
<li><div>The candidates selected on reserve seats under category of Sindh University Employees Quota are required to show Service Certificate countersigned by the Registrar, University of Sindh, Jamshoro. </div></li></br>
<li><div>The candidates selected for admissions on reserved seats of affiliated college teachers are required to submit service certificate signed by the Director Colleges Education.</div></li></br>




<!--
<div style="color:blue" >

	
"If you are selected for anyother discipline in 2nd merit selection and you are not interested in the automatic transfer of your admission to that discipline then please follow the  instructions.
<ul>
<li> Submit a  applications  and  obtain separate challan of Rs. 200 to the Directorate of Admissions for retaining your admission in the choice, failing which your admission will be transfered automatically and a new challan of fee difference (if any) will be issued .</li>
</ul>

However, if you are interested in the automatic transfer of your admission in next  choice based on 2nd Merit Selection then please follow the  instructios.
<ul>
<li>Obtain the fee difereence challan (if any) from counters  of Directorate of Admissions, within stipulated time and deposit in bank. If you fail to do so then your admission will not be automatically transfered and you will not be considered for 3rd Merit Selection."</li>
	</ul>
	</b>
</div>
-->



<?php
	}

?>


<?php
	if ($admListDetailId==3){

?>
<ol type='1'>
<div>
<li>   It is further announced that those candidates who were selected in 1st & 2nd Merit Lists for admission to M.B.A., LL.M., M.Sc. (Criminology), M.A. English M.B.A ,M.P.A., B.H.P.E & M.H.P.E  (Evening Programs) as well as in M.B.A. (Hons) M.Sc. Biotechnology, Botany, Enviromental Science, Physiology, Pscyhology, Fresh Water Biology, MCS, M.A. Arabic, General History, International Relations, Muslim History, Social Work, Sociology, Urdu and MLIS  but not deposit admission fees within due date, they may also deposit fees and obtain challan of fees </li></br>
</div>
	<?php } ?>
<!--</br>
</br>
<div>NOTE:<i>The date of payment of Masters  degree program under all the categories has been extended by <strong> November 21<span>,</span >2014</strong> </i></div>
<div>The students whose names have been concluded in first merit list for admissions in Masters degree programs have been advised to deposit their admission fees by November 21. According to Director Admissions, those who remained unable to deposit their fees, their names will be omitted and they will be considered no more for admissions.</div>!-->

<div><li> The candidates selected in Quota-oriented disciplines (listed below) are required to show their Original Domicile and PRC certificates at the time of collection of Admission Fees Challan.</li></b>


<table border='1'><tr><td>M.B.A (Master of Business Administration)    </td><td>M.P.A (Previous) - Master of Public Administration </td></tr></table></div></br><div>
<div>
        <div>
 <li> You can submit your application for objection/correction (if any) at the Directorate of Admission, Ghulam Mustafa Shah Administration building, University Of Sindh Allama I.I Kazi Campus ,Jamshoro.</li> 
        </div>
   
</div>
</br>




<!--

<div class='row'>
<div class='col-md-3'></div>

<div class="col-md-5" style="  background-color: #D0D0D0;">
    <a href="http://www.admission.usindh.edu.pk/test_result//assets/masters/Objection_Form Master.pdf" style="color: #000;">
        
            <strong>Click on the link given below to download the Application Form.
        
                </strong>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>
<div class="col-md-2"></div>

<div class="col-md-5" style=" background-color: #D0D0D0;">
    <a href="http://www.usindh.edu.pk/mast_list_2015/assets/pdf/Correction.pdf" style="color:blue;">
                  <strong>You can submit your objection (if any) regarding your marks and scores.</strong><br>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>


</div>

-->