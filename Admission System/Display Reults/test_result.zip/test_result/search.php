 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
 <!-- Fevicon
================================================== -->
<link rel="shortcut icon" href="favicon.ico">
<link rel="icon" type="image/gif" href="images/animated_favicon1.gif">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Search Results</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


<?php
require_once './DatabaseManager.php';
     $con=DatabaseManager::connect();

if (isset($_REQUEST['admission_session'])) {
    $admSession = mysqli_real_escape_string($con,  $_REQUEST['admission_session']);
    $progType = mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $admListDetailId = mysqli_real_escape_string($con,  $_REQUEST['admission_list_detail']);

     $result = DatabaseManager::getAdmissionSession($admListDetailId);

    if ($rowSession = mysqli_fetch_array($result)) {
        $admission_session = $rowSession['ADMISSION_SESSION'];
        ?>
        <html>
            <head>
			<?php include('bar.php'); ?>
       
                <meta charset="utf-8">
                <title>University of Sindh</title>
                <link rel="icon" type="image/png" href="images/logo.png" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="description" content="">
                <meta name="author" content="">

                <link href="scripts/bootstrap/css/bootstrap.min.css" rel="stylesheet">
                <link href="jk_style.css" rel="stylesheet">
                <link href="scripts/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">


                <!-- Icons -->
                <!--[if lt IE 8]>
                    <link href="scripts/icons/general/stylesheets/general_foundicons_ie7.css" media="screen" rel="stylesheet" type="text/css" />
                    <link href="scripts/icons/social/stylesheets/social_foundicons_ie7.css" media="screen" rel="stylesheet" type="text/css" />
                <![endif]-->
                <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
                <!--[if IE 7]>
                    <link rel="stylesheet" href="scripts/fontawesome/css/font-awesome-ie7.min.css">
                <![endif]-->

               

                <link href="styles/custom.css" rel="stylesheet" type="text/css" />
				     </head>
            <body id="pageBody">

<?php
if($progType==1){
?>
<script>
	$(document).ready(function(){
		$('nav ul li a').each(function() {
			if($(this).text() == "Bachelor Results"){
				$(this).attr("id","current");
			}else {
				$(this).removeAttr("id");
			}
    	});
	});
</script>
<?php }else{?>
<script>
	$(document).ready(function(){
		$('nav ul li a').each(function() {
			if($(this).text() == "Master Results"){
				$(this).attr("id","current");
			}else {
				$(this).removeAttr("id");
			}
    	});
	});
</script>
<?php }?>


                <div id="container"  class="container">

                    <div class="transparent-bg" style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;z-index: -1;zoom: 1;"></div>

                    <div class="divPanel notop nobottom" >
                        <div class="row-fluid" >
                            <div class="span12" >

                                                   </div>

                       
                    <div class="contentArea">

                        <div class="divPanel notop page-content" >


                            <div class="row-fluid">
                                <!--Edit Main Content Area here-->
                                <div class="span12" id="divMain" style="margin-top: -5px;">
          <?php 
if($progType==1){
	require_once('headerBachlor.php');
}
else{
	require_once('headerMaster.php');
	
}
    ?>
	
	
	


                                    <br /> 
									<div class="row">									
									<div class="col-md-3">
                                    <div id="sidebar1" class="sidebar"  >
								
									</div>
  
									
								</div>
								
                                  <div class="col-md-6">
  <div class="form-inline" >       
	   <div class="form-group">
    
    <p class="form-control-static">Seat No:</p>
  </div>
  <div class="form-group">
   
    <input type="text" class="form-control"  name="s" id="seat" placeholder=""  required>
  </div>
  <button type="button" id="search" class="btn btn-info">Search</button>
  <img src="images/ajax-process-small.gif" id="ajax-ico" style="display: none;"/>
                                        
  </div>
  
							            <input type="radio" style="display: none;" name="program_type" id="bachelor_program_type" value="1" <?php if ($progType == 1) echo "checked='true'" ?> />
                                        <input type="radio" style="display: none;" name="program_type" value="2" id="master_program_type" <?php if ($progType == 2) echo "checked='true'" ?>/>
                                        <br/>
									    <div id="panel">         </div>
                                    </div>
								
								<div class="col-md-3">
								 <div id="sidebar2"></div>
                                </div>
									</div>
                                    
                                </div>
                                <!--End Main Content-->
                            </div>
</br>
  
 
                            <div id="footerInnerSeparator">
                                <?php
                                if($progType==2){
                                include './footerMaster.php';
                                }else{
                                    
                              include './footerBachlor.php';
}                              
?>
                               
                            </div>
                            <div id="footerOuterSeparator">
                                 </div>
                            <br/><br/>
 <?php include './info.html'; ?>
                          
				 </div>
				  </div>
				   </div>

                            <script src="scripts/jquery.min.js" type="text/javascript"></script> 
                            <script src="scripts/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
                            <script src="scripts/default.js" type="text/javascript"></script>


                            <script src="scripts/carousel/jquery.carouFredSel-6.2.0-packed.js" type="text/javascript"></script><script type="text/javascript">$('#list_photos').carouFredSel({responsive: true, width: '100%', scroll: 2, items: {width: 320, visible: {min: 2, max: 6}}});</script><script src="scripts/camera/scripts/camera.min.js" type="text/javascript"></script>
                            <script src="scripts/easing/jquery.easing.1.3.js" type="text/javascript"></script>
                            <script type="text/javascript">function startCamera() {
                                    $('#camera_wrap').camera({fx: 'scrollLeft', time: 4000, loader: 'none', playPause: false, navigation: true, height: '35%', pagination: true});
                                }
                                $(function() {
                                    startCamera()
                                });</script>


                
				<script>
                                $('#search').click(function() {
                                    $('#ajax-ico').show();
                                    var type = $('input[name=program_type]:checked').val();
                                    var seat = $("#seat").val();
                                    if (seat == "") {
                                        $('#ajax-ico').hide();
                                        return;
                                    }
                                    $.post("selection.php", {
                                        admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                        admission_session: <?php echo "$admission_session"; ?>,
                                        program_type: type,
                                        seatNo: seat
                                    }, function(response) {
                                        $("#panel").html(response);

                                        $.post("choices.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#sidebar1").html(response);
                                            $('#ajax-ico').hide();
                                        });
										
										$.post("candidates_category.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#sidebar2").html(response);
											//alert(response);
                                            $('#ajax-ico').hide();
                                        });
                                    });
                                });

                                $("#seat").keypress(function(e) {
                                    if (e.which == 13) {
                                        $('#ajax-ico').show();
                                        var type = $('input[name=program_type]:checked').val();
                                        var seat = $("#seat").val();
                                        if (seat == "") {
                                            $('#ajax-ico').hide();
                                            return;
                                        }
                                        $.post("selection.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            admission_session: <?php echo "$admission_session"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#panel").html(response);

                                            $.post("choices.php", {
                                                admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                                program_type: type,
                                                seatNo: seat
                                            }, function(response) {
                                                $("#sidebar1").html(response);
                                                $('#ajax-ico').hide();
                                            });
											$.post("candidates_category.php", {
                                            admission_list_detail_id:<?php echo "$admListDetailId"; ?>,
                                            program_type: type,
                                            seatNo: seat
                                        }, function(response) {
                                            $("#sidebar2").html(response);
											//alert(response);
                                            $('#ajax-ico').hide();
                                        });
                                        });
                                    }
                                });
                            </script>
                            </body>
                            </html>
                            <?php
                        } else {
                            echo "<h2>Unexpected Path...</h2>";
                        }
                    } else {
                        echo "<h2>Unexpected Path...</h2>";
                    }
                    ?>
	<?php include './footerbar.php'; ?>