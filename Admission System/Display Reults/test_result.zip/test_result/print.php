<?php

if (isset($_REQUEST['s'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['s']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);
    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
    if ($row = mysqli_fetch_array($result)) {
        $candidateId = $row['CANDIDATE_ID'];
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
       // $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];
	
	
			$columnWidth = 60;
			 $columnHeight = 5;

require('fpdf/cellpdf.php');
		class PDF extends FPDF
		{
		function Header()
			{
//    	$Image('sindh-university.png',50,50,100);
		   
		//	$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size 
			 
 $this->SetFont('Arial','B',15);
 //  $this->Cell($w,9,$REMARKS_PROGRAM_NAME,1,1,'C',false);
//	$this->Ln(10);
  		
		}
		function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

		}
		
		
			 
		$pdf=new CellPDF();
		$pdf->SetFont('Times','',12);
		$pdf->AddPage();
		

		
		//$pdf->Cell(0,8,"University of Sindh Jamshoro Admission Resuls",0,1,'C',false);
			$pdf->SetFont('Times','',20);
	//	$pdf->AddPage();
		$pdf->Image('images/logo.png',20,5,20);
		$pdf->Cell(0,8,"University of Sindh Jamshoro",0,1,'C',false);
		$pdf->Ln();
		$pdf->text(80,22,"Objection Form");
		$pdf->Ln();
		$pdf->Image('images/right_logo.jpg',170,5,18);
		$pdf->Line(10,30,200,30);
	
		$pdf->SetFont('Times','',12);
		
	//	$pdf->Cell(0,9,"Admission Resuls",0,1,'C',false);
		$pdf->Ln();
		$w = array(90, 45, 120, 50,40,20);
		$h=8;
		
		 $pdf->Ln(2);
        $pdf->SetFont("Times",'B',10);
        $pdf->Cell(0,$columnHeight,"Personal Information",0,1);
        $pdf->SetFont("Times",'',10);
		
		$pdf->Cell($columnWidth,$columnHeight,"Seat No",1,0);
        $pdf->Cell(0,$columnHeight,"".$seatNo ,1,1,'L');
      
        $pdf->Cell($columnWidth,$columnHeight,"Name",1,0);
        $pdf->Cell(0,$columnHeight,"".$name ,1,1,'L');
        $pdf->Cell($columnWidth,$columnHeight,"Father's Name",1,0);
        $pdf->Cell(0,$columnHeight,"".$father,1,'L');
		$pdf->ln();
		 	$pdf->Cell($columnWidth,$columnHeight,"District (Domicile):",1,0);
			$pdf->Cell(0,$columnHeight,"$district",1,0,'L');
			$pdf->ln();
	
				if ($area=="U" || $area=="0"){
		$pdf->Cell($columnWidth,$columnHeight,"Urban/Rural:",1,0);
		$pdf->Cell(0,$columnHeight,"URBAN",1,0);
		$pdf->ln();
			
			}else{
		$pdf->Cell($columnWidth,$columnHeight,"Urban/Rural:",1,0);
		$pdf->Cell(0,$columnHeight,"RURAL",1,0);
		$pdf->ln();
			}
			
			if($programType==1){	
			$pdf->Cell($columnWidth,$columnHeight,"HSC Group",1,0);
			$pdf->Cell(0,$columnHeight,$degree,1,0);
			$pdf->ln();
			}

	
	
	 $pdf->Ln(2);
        $pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"Academic Record",0,1);      
        $pdf->SetFont("Times",'B',10);
        $pdf->Cell($columnWidth,$columnHeight*2,"Examination Passed",1,0);
        //$pdf->Cell($columnWidth/3,$columnHeight*2,"Group",1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight*2,"Marks\n Obtained",1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight*2,"Total \nMarks",1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight*2,"Year",1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight*2,"Score Persantage",1,0,'C');
		$pdf->Cell($columnWidth/3,$columnHeight*2,"Score",1,0,'C');
      //  $pdf->Cell(0,$columnHeight*2,"Deducation\n Marks",1,0,'C');
		 //$pdf->Cell(0,$columnHeight*2,"MARKS AFTER\n DEDUCTION",1,0,'C');
		 $pdf->ln();
      
        $pdf->SetFont("Times",'B',10);
		
		 $pdf->Cell($columnWidth,$columnHeight,"S.S.C (Matriculation)",1,0);
        $pdf->SetFont("Times",'',10);
		//$pdf->Cell($columnWidth/3,$columnHeight,"".$row[0]['group_name'],1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$ssc_obt,1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$ssc_total_marks,1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$ssc_year,1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"10%",1,0,'C');
		$pdf->Cell($columnWidth/3,$columnHeight,"10: ".$ssc_perc,1,0,'C');
       // $pd->Cell(0,$columnHeight,"".$sscInfo[0]['issuer_name'],1,1,'C');
	   
	   $pdf->ln();
        $pdf->SetFont("Times",'B',10);
        $pdf->Cell($columnWidth,$columnHeight,"H.S.C (Intermediate)",1,0);
        $pdf->SetFont("Times",'',10);
      //  $pdf->Cell($columnWidth/3,$columnHeight,"".$hscInfo[0]['group_name'],1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$hsc_obt,1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$hsc_total_marks,1,0,'C');
        $pdf->Cell($columnWidth/3,$columnHeight,"".$hsc_year,1,0,'C');
			
			if($programType == 1){
			$pdf->Cell($columnWidth/3,$columnHeight,"10%",1,0,'C');
			$pdf->Cell($columnWidth/3,$columnHeight,"".$hsc_perc,1,0,'C');
					}else{
					
			$pdf->Cell($columnWidth/3,$columnHeight,"20%",1,0,'C');
			$pdf->Cell($columnWidth/3,$columnHeight,"".$hsc_perc,1,0,'C');
		 }
		
		
     //   $pdf->Cell(0,$columnHeight,"".$degree,1,1,'C');
	 $pdf->ln();
	  if($programType==2){
            $pdf->Cell($columnWidth,$columnHeight,"Graduation (Bachelor Degree)",1,0);
            //$pdf->Cell($columnWidth/3,$columnHeight,"".$grdInfo[0]['group_name'],1,0,'C');
            $pdf->Cell($columnWidth/3,$columnHeight,"".$grad_obt,1,0,'C');
            $pdf->Cell($columnWidth/3,$columnHeight,"".$grd_total_marks,1,0,'C');
			 $pdf->Cell($columnWidth/3,$columnHeight,$grd_year,1,0,'C');
            $pdf->Cell($columnWidth/3,$columnHeight,"35%",1,0,'C');
            $pdf->Cell($columnWidth/3,$columnHeight,"".$grad_perc,1,0,'C');
          //  $pdf->Cell(0,$columnHeight,"".$grdInfo[0]['issuer_name'],1,1,'C');
	  }
	 
	 $pdf->ln(8);
	 if ($deductionMarks != 0) {
	   $pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"Dectation",0,1);  
		$pdf->SetFont("Times",'',10);
			$pdf->SetFont("Times",'B',10);		
		$pdf->Cell($columnWidth,$columnHeight,"DEDUCTION MARKS",1,0);
		 $pdf->SetFont("Times",'',10);
            $pdf->Cell($columnWidth/3,$columnHeight,"".$deductionMarks,1,0,'C');
			$pdf->SetFont("Times",'B',10);
			 $pdf->Cell($columnWidth,$columnHeight,"MARKS AFTER DEDUCTION:",1,0);
			 $pdf->SetFont("Times",'',10);
            $pdf->Cell($columnWidth/3,$columnHeight,"".$marksAfterDeduction,1,0,'C');
            
	 }
	 
	 $pdf->ln(8);
	   $pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"TEST RESULT",0,1); 

			$pdf->SetFont("Times",'B',10);		
			
			$pdf->Cell($columnWidth,$columnHeight,"TEST MARKS",1,0);
			$pdf->SetFont("Times",'',10);
            $pdf->Cell($columnWidth/3,$columnHeight,"".$test_score,1,0,'C');
			$pdf->SetFont("Times",'B',10);
			$pdf->Cell($columnWidth,$columnHeight,"TEST SCORE [60]",1,0);
			$pdf->SetFont("Times",'',10);
            $pdf->Cell($columnWidth/3,$columnHeight,"".$test_perc,1,0,'C');
			$pdf->ln(8);
			$pdf->SetFont("Times",'BI',10);
      	
			$pdf->Cell($w[1],$h,"Total Score (CPN)[100]:",1,0,'C');
			$pdf->Cell($w[1],$h,$cpn,1,0,'C');
			$pdf->Ln(8);
			
		

			if ($objectionRemarks != "") {
					
		
			$pdf->Cell(0,$columnHeight,"Objection Remarks $objectionRemarks",1,0);
			
			$pdf->Ln();
		
			
			}
			
		$pdf->ln(8);
	   $pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"You are Selected In",0,1); 
		$pdf->SetFont("Times",'',10);
       
			if ($campus != "") {
				$pdf->SetFont('Times','B',12);
					$pdf->SetTextColor(255,0,0);
	//				$pdf->Cell($w[0],$h,"You are selected in:",1,0,'C');/
				//	$pdf->Ln();
	
				
					$pdf->SetTextColor(0,0,0);
				
				$pdf->SetFont('Times','',11);
			$pdf->Cell($w[1],$h,"Program:",1,0,'C');
			$pdf->Cell($w[1],$h,$discipline,1,0,'C');
			$pdf->Ln();
			
			$pdf->Cell($w[1],$h,"Category:",1,0,'C');
			$pdf->Cell($w[1],$h,$category,1,0,'C');
			$pdf->Ln();
	
			$pdf->Cell($w[1],$h,"Campus:",1,0,'C');
			$pdf->Cell($w[1],$h,$campus,1,0,'C');
			$pdf->Ln();
			$pdf->Ln();
	
				   while ($row = mysqli_fetch_array($result)) {
                    $campus = $row['CAMPUS'];
                    $category = $row['CATEGORY'];
                    $discipline = $row['DISCIPLINE'];
                    $campusId2 = $row['CAMPUS_ID'];
			
			
			$pdf->Cell($w[1],$h,"Program:",1,0,'C');
			$pdf->Cell($w[1],$h,$discipline,1,0,'C');
			$pdf->Ln();
	
			$pdf->Cell($w[1],$h,"Category:",1,0,'C');
			$pdf->Cell($w[1],$h,$category,1,0,'C');
			$pdf->Ln();
					
					 //if ($campusId2 != $campusId) {
			$pdf->Cell($w[1],$h,"Campus:",1,0,'C');
			$pdf->Cell($w[1],$h,$campus,1,0,'C');
			$pdf->Ln();
			$pdf->Ln();
	
					
                    $campusId = $campusId2;
                    //} 
				}//end whhile
			
					}// end campus if
		if ($choiceNo != 1) {
//			$pdf->Cell(0,8," If any candidate wish to study in selected choice, he/she must deposit rs.200 in separate bank challan with application so that his/her choice may not be changed.",0,1,'L',false);				
		
		}else{
		//  $resultAdmi = DatabaseManager::getCandidateFromSession($seatNo, $programType, $admission_session);
		//  if ($resultAdmi) {
		//		 		$pdf->Cell(0,8,"YOU ARE SELECTED IN PREVIUOS MERIT LIST",0,1,'L',false);					
		//        } else {
		
	
	
	}

		//$pdf->ln(8);
		$pdf->SetXY(10, 210);		
		$pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"OBJECTION IF ANY",0,1);
		$pdf->Cell(130,50,"",1,1); 
				
		$pdf->SetFont("Times",'',10);
       	
		
		
		
		//$pdf->Ln();
		
		// ********************choices*****************************// 
		$choiceResult = DatabaseManager::getChoice($candidateId, $campusId);
				$campusUpper = "";
				 $i = 0;
            
                if ($i == 0) {
                    $i++;
    //              $pdf->Cell("80");
					$pdf->SetTextColor(255,0,0);
							$pdf->SetFont('Times','B',14);
						$pdf->SetXY(145, 147);
					$pdf->Cell($w[1],$h,"Applied Choices",0,0,'C');
	
				 		//$pdf->Text(150,40,"Your Choices");
						$w=40;
						
					  	$pdf->SetTextColor(0,0,0);
				
       
                   }
				   $y=158;
				   while ($choiceRow = mysqli_fetch_array($choiceResult)) {
							
					$shiftcampus = $choiceRow['SHIFT_NAME'];
					if($shiftcampus != $campusUpper){
					$w+=5;
							$pdf->SetFont('Times','',10);
							$pdf->SetTextColor(0,0,255);
							$pdf->SetXY(140, $y-2);
							$pdf->Cell($w[1],$h,"".$shiftcampus,0,0,'C');
							$y = $y + 5;
							$pdf->SetTextColor(0,0,0);								
		
								$campusUpper = $shiftcampus;
					}
					$pdf->SetFont('Times','',10);

					$w+=6;
					$shiftId = $choiceRow['SHIFT_ID'];
                    $disc = $choiceRow['DISCIPLINE'];
                    $choice = $choiceRow['CHOICE_NO'];
					 $y = $y + 5;
					//$pdf->SetXY(140, $w);
				//	$pdf->SetXY(140, $w);
					$pdf->SetXY(172, $y);
				
					$pdf->Cell(0, $columnHeight,"$choice- $disc",1,0);
							
						 	
                }
		// ********************End choices*****************************// 
			
			
 
		$pdf->SetXY(150, 269);
        $pdf->Ln(2);
        
        $pdf->Cell(0,$columnHeight,"Signature of the applicant",0,0);

 
		
    }
}	
		
	
		//request if
		$pdf->Ln();
		$pdf->Output();
	
       ?>
	   
	    	
		
			
	   			  
		
		
      



