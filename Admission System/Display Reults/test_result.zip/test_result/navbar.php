<!--							 		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1801.8774815946902!2d68.2629579!3d25.4130116!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc33e04561e85ca48!2sUniversity+of+Sindh!5e0!3m2!1sen!2s!4v1415361348827" width="100%" height="600" frameborder="0" style="border:0"></iframe>-->
                            <br /><br /><br />
                                       
					<div class="navbar-inner">
	
                                        <div class="nav-collapse collapse">
                                            <ul class="nav nav-pills ddmenu">
                                          <li><a href="" style="color: blue;" href="">Home </a></li>
                                                    <li><a  style="color: blue;" href="http://www.usindh.edu.pk/faculty-a-staff.html">Faculty & Staff</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/financial-support.html">Financial Support</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/academics/central-library.html">Central Library</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/sutc.html">Testing Center</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/blogs">News & Events</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/distribution-of-seats.html">Distribution of Seats</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/fees-structure.html">Fees Structure</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/how-to-apply.html">How to Apply</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/general-regulations.html">General Regulations</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/graduate-degree-programs.html">Graduation Degree Programs</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/post-graduate-degree-programs.html">Post Graduation Degree Programs</a></li>
                                                    <li><a style="color: blue;" href="http://www.usindh.edu.pk/admissions/student-welfare-programs.html">Student Welfare Programs</a></li> \
                                             </ul>
                                        </div>
                               </div>
  