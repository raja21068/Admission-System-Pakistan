<?php


class DatabaseManager {

    public static function connect() {
       $mysql_hostname = "localhost";
    $mysql_user = "root";
  $mysql_password = "";
$mysql_database = "uos_admission_result";
//$mysql_user = "mast_list_2015";
  //	$mysql_password = "sarkarikhatta79";
 // $mysql_database = "uos_web_result";
        $bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("<h2>Error connecting with database...!</h2>");
        return $bd;
    }

	
	
public static function getWebTextData($key) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM webtextdata WHERE ID = $key";
        $result = mysqli_query($link, $query) or die("error executing query:");
        if ($row2 = mysqli_fetch_array($result)) {
             echo  $row2['VALUE'];
           }
}


    public static function getEntryTestResult($seatNo,$program_type_id) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM BACH_2015 WHERE SEAT_MO = $seatNo AND PROGRAM_TYPE_ID=$program_type_id";
                //echo($query);
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result;
    }


	
	public static function getChallan($candidateId) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CHALLAN WHERE CANDIDATE_ID = $candidateId";
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        
        return $result;
    }
    public static function getCandidate($seatNo, $programType, $admissionListDetailId) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_RESULT WHERE SEAT_NO = $seatNo AND PROGRAM_TYPE = $programType AND ADMISSION_LIST_NO = $admissionListDetailId";
		//echo($query);
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result;
    }
	
	public static function getFees($candidate_id) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM FEES_PAYMENT WHERE CANDIDATE_ID = $candidate_id";
		
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result;
    }

    public static function getCandidateFromSession($seatNo, $programType, $admissionSession) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_RESULT WHERE SEAT_NO = $seatNo AND PROGRAM_TYPE = $programType AND ADMISSION_SESSION = $admissionSession AND ADMISSION_LIST_NO <> 0";
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result;
    }


    public static function getChoice($candidateId, $campusId) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_CHOICE WHERE CANDIDATE_ID = $candidateId  ORDER BY SHIFT_NAME,SHIFT_ID, CHOICE_NO";
        $rs = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $rs;
    }
	public static function getCategory($candidateId) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_CATGORY WHERE CANDIDATE_ID = $candidateId";
		//echo($query);
        $rs = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $rs;
    }

    public static function getAdmissionSession($admissionListDetailId) {
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId";
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result;
    }

    public static function getDistinctCampus($admissionListDetailId){
        $link = DatabaseManager::connect();
        $query = "SELECT DISTINCT(CAMPUS_ID),CAMPUS FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId  AND CAMPUS <> '' ORDER BY CAMPUS";
		$result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
	
	public static function getDistinctMphliDepartment(){
        $link = DatabaseManager::connect();
        $query = "SELECT DISTINCT(DEPARTMENT) FROM BACH_2015";
		echo($query);
		$result = mysqli_query($link, $query) ;
		//or die(header("Location: error.html"));
        return $result; 
    }
	
		public static function getMphliDepartmentList($deptName,$program_type_id){
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM BACH_2015 where DEPARTMENT= '$deptName' and PROGRAM_TYPE_ID=$program_type_id ORDER BY TOTAL_SCORE DESC ";
		//echo($query);
		$result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
    
    public static function getDistinctDiscipline($admissionListDetailId, $campusId,$programType){
        $link = DatabaseManager::connect();
        $query = "SELECT DISTINCT(DISCIPLINE) FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId AND CAMPUS_ID=$campusId AND PROGRAM_TYPE=$programType order by DISCIPLINE";
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
    
     public static function getDistinctCategories($admissionListDetailId, $campusId,$discipline){
        $link = DatabaseManager::connect();
        $query = "SELECT DISTINCT(CATEGORY) FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId AND CAMPUS_ID=$campusId AND DISCIPLINE = '$discipline'";
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
    
     public static function getAllCandidates($admissionListDetailId, $campusId,$discipline,$category,$orderBy=""){
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId AND CAMPUS_ID=$campusId AND DISCIPLINE = '$discipline' AND CATEGORY = '$category' $orderBy";
		//echo($query);
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
    
	
	public static function getAllCandidatesOrderByDistrict($admissionListDetailId, $campusId,$discipline,$category){
        $link = DatabaseManager::connect();
        $query = "SELECT * FROM CANDIDATE_RESULT WHERE ADMISSION_LIST_NO = $admissionListDetailId AND CAMPUS_ID=$campusId AND DISCIPLINE = '$discipline' AND CATEGORY = '$category' ORDER BY `DISTRICT` , AREA";
	//	echo($query);
        $result = mysqli_query($link, $query) or die(header("Location: error.html"));
        return $result; 
    }
    
}

?>