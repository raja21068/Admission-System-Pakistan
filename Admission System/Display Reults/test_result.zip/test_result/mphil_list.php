 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
 <!-- Fevicon
================================================== -->
<link rel="shortcut icon" href="favicon.ico">
<link rel="icon" type="image/gif" href="images/animated_favicon1.gif">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Merit List</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<?php
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();

  
    $programType = mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $admission_session = mysqli_real_escape_string($con,  $_REQUEST['admission_session']);

      ?>
    
    <!-- start header -->


 
    <?php
    if (isset($_REQUEST['admission_session'])) {
        $admSession =mysqli_real_escape_string($con,   $_REQUEST['admission_session']);
        $progType =mysqli_real_escape_string($con,   $_REQUEST['program_type']);
       
        require_once './DatabaseManager.php';
            ?>
            <html>
                <head>
                    <?php include('bar.php'); ?>
                    </br>
                                        </br>
                    

                    <meta charset="utf-8">
                    <title>University Of Sindh</title>
                    <link rel="icon" type="image/png" href="images/logo.png" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">

                    <link href="scripts/bootstrap/css/bootstrap.min.css" rel="stylesheet">
                    <link href="scripts/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">


                  
                    <link href="styles/custom.css" rel="stylesheet" type="text/css" />
                </head>
                
                <body id="pageBody">
<?php include_once("analyticstracking.php") ?>

<?php
if($progType==1){
?>
<script>
	$(document).ready(function(){
		$('nav ul li a').each(function() {
			if($(this).text() == "Bachelor Results"){
				$(this).attr("id","current");
			}else {
				$(this).removeAttr("id");
			}
    	});
	});
</script>
<?php }else{?>
<script>
	$(document).ready(function(){
		$('nav ul li a').each(function() {
			if($(this).text() == "Master Results"){
				$(this).attr("id","current");
			}else {
				$(this).removeAttr("id");
			}
    	});
	});
</script>
<?php }?>
                                          <div class="contentArea">

                            <div class="divPanel notop page-content">


                                <div class="row-fluid">
                                    <!--Edit Main Content Area here-->
                                    <div class="span12" id="divMain" style="margin-top: -5px;">
									<?php
									if($progType==3) include ('headerMphil.php');
									if($progType==2) include ('headerMaster.php');
									if($progType==1) include ('headerBachlor.php');
									 
									?>

								
                                        <!--
<div>NOTE:<i>LAST DATE FOR SUBMISSION OF OBJECTION (IF ANY) AT DIRECTORATE OF ADMISSIONS DURING OFFICE HOURS UPTO <strong>08.11.2014</strong> </i></div>
<div><u>FIRST PROVISIONAL LIST (AFTER CLEARING OBJECTIONS) WILL BE DISPLAYED ON <strong>MONDAY 10.11.2014 </strong> </u></div>
-->
                                        <br />  
                                              
 <br />  
                                              



                                        <div class='bordered'>

                                    <div class="col-md-6">
                                                Department:
                                                <select class="form-control" id="department_sel">
                                                    <option value="">--SELECT DEPARTMENT--</option>
                                                    <?php
                                                    $result = DatabaseManager::getDistinctMphliDepartment();
                                                    while ($row = mysqli_fetch_array($result)) {
                                                        if ($row['DEPARTMENT'] == "" || $row['DEPARTMENT'] == '0'){continue;}
														$departmentName=$row['DEPARTMENT'];
                                                        echo "<option style='padding-right: 10px;' value='" . $departmentName . "'>" . $departmentName . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                                <img src="images/ajax-process-small.gif" style="display: none;" id="campus_ajax_icon">
                                            </div>

                                           <div id='can_div'></div> 

                              


								
                                </div>
                            </div>
                        </div>
						

                        <div id="footerOuterSeparator">
                            <?php // include './info.html'; ?>
                        </div>

                        <br /><br /><br />

                        <script src="scripts/jquery.min.js" type="text/javascript"></script> 
                        <script src="scripts/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
                        <script src="scripts/default.js" type="text/javascript"></script>


                        <script src="scripts/carousel/jquery.carouFredSel-6.2.0-packed.js" type="text/javascript"></script><script type="text/javascript">$('#list_photos').carouFredSel({responsive: true, width: '100%', scroll: 2, items: {width: 320, visible: {min: 2, max: 6}}});</script><script src="scripts/camera/scripts/camera.min.js" type="text/javascript"></script>
                        <script src="scripts/easing/jquery.easing.1.3.js" type="text/javascript"></script>

                </body>
            </html>
            </div>
            <?php
    ?>



    <?php
} else {
    
}
?>        
<?php include './footerbar.php'; ?>
 
<script>
  
   $("#department_sel").change(function() {
	    var disc = $(this).val();
        if (disc == "") {
            return;
        }
        var departmentName = $("#department_sel").val();
	//	alert(departmentName);
        $("#program_ajax_icon").show();
        $.post("mphil_list_result.php", {
            program_type:<?php echo $programType; ?>,
            dept_name: departmentName
        }, function(response) {
//            $("#cat_select").html(response);
            $("#can_div").html(response);
	        $("#program_ajax_icon").hide();
        });
    });
</script>