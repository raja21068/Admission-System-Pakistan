<?php
	if ($admListDetailId==2){

?>
<!--
<div style="color:blue" >

	
"If you are selected for anyother discipline in 2nd merit selection and you are not interested in the automatic transfer of your admission to that discipline then please follow the  instructions.
<ul>
<li> Submit a  applications  and  obtain separate challan of Rs. 200 to the Directorate of Admissions for retaining your admission in the choice, failing which your admission will be transfered automatically and a new challan of fee difference (if any) will be issued .</li>
</ul>

However, if you are interested in the automatic transfer of your admission in next  choice based on 2nd Merit Selection then please follow the  instructios.
<ul>
<li>Obtain the fee difereence challan (if any) from counters  of Directorate of Admissions, within stipulated time and deposit in bank. If you fail to do so then your admission will not be automatically transfered and you will not be considered for 3rd Merit Selection."</li>
	</ul>
	</b>
</div>
-->

<?php
	}

?>
<!--</br>
</br>
<div>NOTE:<i>The date of payment of Masters  degree program under all the categories has been extended by <strong> November 21<span>,</span >2014</strong> </i></div>
<div>The students whose names have been concluded in first merit list for admissions in Masters degree programs have been advised to deposit their admission fees by November 21. According to Director Admissions, those who remained unable to deposit their fees, their names will be omitted and they will be considered no more for admissions.</div>!-->
<div>The candidates selected in Quota-oriented disciplines (listed below) are required to show their Original Domicile and PRC certificates at the time of collection of Admission Fees Challan.</b>
<ul><li>M.B.A (Master of Business Administration)    </li><li>M.P.A (Previous) - Master of Public Administration </li></ul></div></br><div>
The candidates selected on reserve seats under category of Sindh University Employees Quota are required to show Service Certificate countersigned by the Registrar, University of Sindh, Jamshoro.</div></br><div>The candidates selected for admissions on reserved seats of affiliated college teachers are required to submit service certificate signed by the Director Colleges.</div></br><div>The University of Sindh reserves the right to rectify any error / omission detected at any stage and also reserves the right to cancel any Provisional Admission at any time without issuing prior notice. </div></br>
<div>
        <div>
   You can submit your application for objection/correction (if any) at the Directorate of Admission, Ghulam Mustafa Shah Administration building, University Of Sindh Allama I.I Kazi Campus ,Jamshoro. 
        </div>
   
</div>
</br>





<div class='row'>
<div class='col-md-3'></div>
<div class="col-md-5" style="  background-color: #D0D0D0;">
    <a href="http://www.admission.usindh.edu.pk/test_result//assets/masters/Objection_Form Master.pdf" style="color: #000;">
        
            <strong>You can submit your objections (if any) by submitting this Objection Form.
        
                </strong>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>
<!--
<div class="col-md-2"></div>

<div class="col-md-5" style=" background-color: #D0D0D0;">
    <a href="http://www.usindh.edu.pk/mast_list_2015/assets/pdf/Correction.pdf" style="color:blue;">
                  <strong>You can submit your objection (if any) regarding your marks and scores.</strong><br>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>


</div>

-->