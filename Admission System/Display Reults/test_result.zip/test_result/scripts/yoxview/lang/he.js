﻿{
    "Direction": "rtl",
    "Close" : "סגירה",
    "Help" : "עזרה",
    "FirstImage" : "לתמונה הראשונה",
    "LastImage" : "לתמונה האחרונה",
    "StartStopSlideShow" : "התחל/עצור מצגת",
    "Pause" : "עצור מצגת",
    "Play" : "התחל מצגת",
    "Prev" : "הקודמת",
    "PinInfo" : "נעץ שורת מידע",
    "UnpinInfo" : "שחרר שורת מידע",
    "Next" : "הבאה",
    "PrevImage" : "לתמונה הקודמת",
    "NextImage" : "לתמונה הבאה",
    "Loading" : "טוען",
    "CloseHelp" : "סגור עזרה",
    "HelpText" : "ניתן לנווט בין התמונות ע&quot;י שימוש במקלדת:<br/><br/>חצים ימינה/שמאלה: הקודמת/הבאה<br/>מקש רווח: הבאה<br/>ENTER: התחל/הפסק מצגת<br/>ESCAPE: סגירת הגלריה<br/>HOME/END: תמונה ראשונה/אחרונה<br/>H: פאנל עזרה",
    "Slideshow" : "מצגת",
    "OriginalContext": "צפיה בהקשר המקורי"
}