﻿{
    "Direction" : "ltr",
    "Close" : "Cerrar",
    "Help" : "Ayuda",
    "FirstImage" : "A la primer imagen",
    "LastImage" : "A la ultima imagen",
    "StartStopSlideShow" : "Play/Pause slideshow",
    "Pause" : "Pausar",
    "Play" : "Play",
    "Prev" : "Anterior",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Siguiente",
    "PrevImage" : "Imagen anterior",
    "NextImage" : "Siguiente imagen",
    "Loading" : "Cargando",
    "CloseHelp" : "Cerrar ayuda",  
    "HelpText" : "La galería se puede navegar usando el teclado:<br/><br/>Flechas IZQUIERDA/DERECHA: Anterior/Siguiente<br/>SPACEBAR: Siguiente<br/>ENTER: Iniciar/Parar slideshow<br/>ESCAPE: Cerrar galería<br/>HOME/END: Primer/Ultimo imagen<br/>H - Este panel de ayuda",
    "Slideshow" : "Play",
    "OriginalContext": "Ver en el contexto original"
}