﻿{
    "Direction" : "ltr",
    "Close" : "Zavrieť",
    "Help" : "Nápoveda",
    "FirstImage" : "Na prvý obrázok",
    "LastImage" : "Na posledný obrozek",
    "StartStopSlideShow" : "Spustiť/Zastaviť prehrávanie",
    "Pause" : "Zastaviť",
    "Play" : "Spustiť",
    "Prev" : "Predchádzajúci",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Nasledujúci",
    "PrevImage" : "Predchádzajúci obrázok",
    "NextImage" : "Nasledujúci obrázok",
    "Loading" : "Nahrávam",
    "CloseHelp" : "Zavrieť nápovedu",
    "HelpText" : "Galériu môžete prechádzať pomocou kláves:<br/><br/>ŠÍPKY VĽAVO/VPRAVO: Predchádzajúci/Nasledujúci obrázok<br/>MEDZERNÍK: Ďalší<br/>ENTER: Spustiť/zastaviť prehrávanie<br/>ESC: Zavrieť galériu<br/>HOME/END: Prvý/posledný obrázok<br/>H - Vyvolanie nápovedy",
    "Slideshow" : "Prehrávanie",
    "OriginalContext": "Zobraziť v pôvodnom kontexte"
}