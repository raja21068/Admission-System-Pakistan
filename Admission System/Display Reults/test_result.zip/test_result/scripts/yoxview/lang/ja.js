﻿{
    "Direction" : "ltr",
    "Close" : "閉じる",
    "Help" : "ヘルプ",
    "FirstImage" : "先頭の画像",
    "LastImage" : "最後の画像",
    "StartStopSlideShow" : "スライドショーの開始/一時停止",
    "Pause" : "一時停止",
    "Play" : "開始/停止",
    "Prev" : "前",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "次",
    "PrevImage" : "前の画像",
    "NextImage" : "次の画像",
    "Loading" : "ロード中",
    "CloseHelp" : "ヘルプを閉じる",  
    "HelpText" : "ギャラリーでは以下のキー操作が可能です。:<br/><br/>←/→ : 前/次の画像<br/>SPACE: 次の画像<br/>Enter: スライドショーの開始/停止<br/>ESC: ギャラリーを閉じる<br/>HOME/END: 先頭/最後の画像 <br/>H - ヘルプを表示",
    "Slideshow" : "開始",
    "OriginalContext": "掲載サイトで見る"
}
