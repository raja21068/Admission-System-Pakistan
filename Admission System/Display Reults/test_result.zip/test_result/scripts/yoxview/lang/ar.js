﻿{
    "Direction" : "rtl",
    "Close" : "إغلاق",
    "Help" : "مساعدة",
    "FirstImage" : "الى الصورة الاولى",
    "LastImage" : "الى الصورة الأخيرة",
    "StartStopSlideShow" : "تشغيل/إيقاف العرض",
    "Pause" : "إيقاف",
    "Play" : "تشغيل",
    "Prev" : "السابق",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "التالي",
    "PrevImage" : "الصورة السابقة",
    "NextImage" : "الصورة التالية",
    "Loading" : "تحميل",
    "CloseHelp" : "إغلاق المساعدة",  
    "HelpText" : "يمكن التنقل خلال العرض عن طريقة لوحة المفاتيح:<br/><br/>أزرار اليمين و اليسار: سابق/تالي<br/>زر المسافة: التالي<br/>ENTER: تشغيل/إيقاف العرض<br/>ESCAPE: إغلاق العرض<br/>HOME/END: البداية/النهاية صورة<br/>H - لوحة المساعدة الحالية",
    "Slideshow" : "تشغيل",
    "OriginalContext": "عرض ضمن السياق الأصلي"
}