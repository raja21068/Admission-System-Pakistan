﻿{
    "Direction" : "ltr",
    "Close" : "关闭",
    "Help" : "帮助",
    "FirstImage" : "第一张",
    "LastImage" : "最后一张",
    "StartStopSlideShow" : "播放/暂停幻灯片",
    "Pause" : "暂停",
    "Play" : "播放",
    "Prev" : "上一页",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "下一页",
    "PrevImage" : "上一张",
    "NextImage" : "下一张",
    "Loading" : "载入中",
    "CloseHelp" : "关闭帮助",  
    "HelpText" : "你可以使用键盘进行画廊导航：<br/><br/>左/右箭头： 上一张/下一张<br/>空格键： 下一张<br/>Enter键： 播放/暂停幻灯片<br/>Esc键： 关闭画廊<br/>HOME/END: 第一张/最后一张<br/>H - 帮助面板",
    "Slideshow" : "播放",
    "OriginalContext": "在原有范围内查看"
}