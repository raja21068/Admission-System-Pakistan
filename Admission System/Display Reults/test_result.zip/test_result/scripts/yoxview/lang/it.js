{
    "Direction" : "ltr",
    "Close" : "Chiudi",
    "Help" : "Aiuto",
    "FirstImage" : "Alla prima immagine",
    "LastImage" : "All' ultima immagine",
    "StartStopSlideShow" : "Riproduci/Pausa la proiezione",
    "Pause" : "Pausa",
    "Play" : "Riproduci",
    "Prev" : "Precedente",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Successiva",
    "PrevImage" : "Immagine precedente",
    "NextImage" : "Immagine successiva",
    "Loading" : "Caricamento",
    "CloseHelp" : "Chiudi aiuto",
    "HelpText" : "Si pu&#xF2; navigare nella galleria usando la tastiera:<br/><br/>FRECCE SINISTRA/DESTRA: Precedente/Successiva<br/>SPAZIO: Successiva<br/>INVIO: Inizia/Ferma lo slideshow<br/>ESC: Chiudi la galleria<br/>HOME/FINE: Prima/Ultima immagine<br/>H - Aiuto<br/>",
    "Slideshow" : "Riproduci",
    "OriginalContext": "vedi nel contesto originale"
}