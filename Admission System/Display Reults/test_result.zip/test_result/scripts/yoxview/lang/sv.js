﻿{
    "Direction" : "ltr",
    "Close" : "Stäng",
    "Help" : "Hjälp",
    "FirstImage" : "Till första bilden",
    "LastImage" : "Till sista bilden",
    "StartStopSlideShow" : "Spela/Pausa bildspelet", 
    "Pause" : "Pausa",
    "Play" : "Bildspel",
    "Prev" : "Föregående",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Nästa",
    "PrevImage" : "Föregående bild",
    "NextImage" : "Nästa bild",
    "Loading" : "Laddar",
    "CloseHelp" : "Stäng hjälp",  
    "HelpText" : "Detta galleri kan navigeras med hjälp av tangentbordet: <br/>VÄNSTER/HÖGER PIL: Tillbaka/Nästa<br/>MELLANSLAG: Nästa bild<br/>ENTER: Starta/pausa bildspelet<br/>ESCAPE: Stäng galleriet<br/>HOME/END: Första/Sista bilden<br/>H - Denna hjälppanel", 
    "Slideshow" : "Bildspel",
    "OriginalContext": "View in original context"
}