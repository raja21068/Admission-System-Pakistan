﻿{
    "Direction" : "ltr",
    "Close" : "Zavřít",
    "Help" : "Nápověda",
    "FirstImage" : "Na první obrázek",
    "LastImage" : "Na poslední obrázek",
    "StartStopSlideShow" : "Spustit/Zastavit přehrávání",
    "Pause" : "Zastavit",
    "Play" : "Spustit",
    "Prev" : "Předchozí",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Následující",
    "PrevImage" : "Předchozí obrázek",
    "NextImage" : "Následující obrázek",
    "Loading" : "Nahrávám",
    "CloseHelp" : "Zavřít nápovědu",  
    "HelpText" : "Galerii můžete procházet pomocí kláves:<br/><br/>ŠIPKY VLEVO/VPRAVO: Předchozí/Následující obrázek<br/>MEZERNÍK: Další<br/>ENTER: Spustit/zastavit přehrávání<br/>ESC: Zavřít galerii<br/>HOME/END: První/poslední obrázek<br/>H - Vyvolání nápovědy",
    "Slideshow" : "Přehrávání",
    "OriginalContext": "Ukázat v původním umístění"
}