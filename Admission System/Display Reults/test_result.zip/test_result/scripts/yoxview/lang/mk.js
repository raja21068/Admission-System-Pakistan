﻿{
    "Direction" : "ltr",
    "Close" : "Затвори",
    "Help" : "Помош",
    "FirstImage" : "Прва слика",
    "LastImage" : "Последна слика",
    "StartStopSlideShow" : "Пушти/Паузирај презентација",
    "Pause" : "Паузирај",
    "Play" : "Пушти",
    "Prev" : "Претходна",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Следна",
    "PrevImage" : "Претходна слика",
    "NextImage" : "Следна слика",
    "Loading" : "Вчитување...",
    "CloseHelp" : "затвори го панелот",  
    "HelpText" : "Галеријата може да се употребува со користење на тастатурата:<br/><br/>СТРЕЛКИ ЛЕВО/ДЕСНО: Претходна/Следна<br/>SPACE: Следна<br/>ENTER: Пушти/Паузирај презентација<br/>ESCAPE: Затвори галерија<br/>HOME/END: Прва/Последна слика<br/>H - Овој панел за помош",
    "Slideshow" : "Play"
}