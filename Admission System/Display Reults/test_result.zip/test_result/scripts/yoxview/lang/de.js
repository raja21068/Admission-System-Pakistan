﻿{
    "Direction" : "ltr",
    "Close" : "Schliessen",
    "Help" : "Hilfe",
    "FirstImage" : "Zum ersten Bild",
    "LastImage" : "Zum letzten Bild",
    "StartStopSlideShow" : "Start/Pause Slideshow",
    "Pause" : "Pause",
    "Play" : "Abspielen",
    "Prev" : "Zurück",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Vor",
    "PrevImage" : "Vorheriges Bild",
    "NextImage" : "Nächstes Bild",
    "Loading" : "Laden",
    "CloseHelp" : "Schliesse Hilfe",  
    "HelpText" : "Die Gallerie kann mit dem Keyboard verwendet werden:<br/><br/>LINKS/RECHTS PFEILE: Zurück/Vor<br/>SPACE: Nächstes<br/>ENTER: Start/Stop Slideshow<br/>ESCAPE: Schliesse Gallerie<br/>HOME/END: Erstes/Letztes Bild<br/>H - Diese Hilfe",
    "Slideshow" : "Abspielen",
    "OriginalContext": "Anzeige im originalen Zusammenhang"
}
