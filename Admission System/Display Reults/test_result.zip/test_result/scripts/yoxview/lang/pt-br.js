﻿{
    "Direction" : "ltr",
    "Close" : "Fechar",
    "Help" : "Ajuda",
    "FirstImage" : "Ir para a primeira imagem",
    "LastImage" : "Ir para a ultima imagem",
    "StartStopSlideShow" : "Iniciar/Pausar slideshow",
    "Pause" : "Pausar",
    "Play" : "Iniciar",
    "Prev" : "Anterior",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Próximo",
    "PrevImage" : "Imagem anterior",
    "NextImage" : "Próxima imagem",
    "Loading" : "Carregando",
    "CloseHelp" : "Fechar ajuda",  
    "HelpText" : "Você pode navegar na galeria usando o seu teclado:<br/><br/>Setas ESQUERDA/DIREITA: Anterior/Próxima<br/>Espaço: Próxima<br/>ENTER: Iniciar/Parar slideshow<br/>ESCAPE: Fechar a galeria<br/>HOME/END: Primeira/Última imagem<br/>H - Este painel de ajuda",
    "Slideshow" : "Iniciar",
    "OriginalContext": "Veja no contexto original"
}