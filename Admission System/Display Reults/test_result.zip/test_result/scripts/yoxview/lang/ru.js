﻿{
    "Direction" : "ltr",
    "Close" : "Закрыть",
    "Help" : "Помощь",
    "FirstImage" : "К первому изображению",
    "LastImage" : "К последнему изображению",
    "StartStopSlideShow" : "Начать/Приостановить слайдшоу",
    "Pause" : "Приостановить",
    "Play" : "Начать",
    "Prev" : "Пред.",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Следующая",
    "PrevImage" : "Предыдущее изображение",
    "NextImage" : "Следующее изображение",
    "Loading" : "Загрузка",
    "CloseHelp" : "Закрыть помощь",  
    "HelpText" : "Управлять галерей можно с помощью клавиатуры:<br/><br/>ЛЕВАЯ/ПРАВАЯ СТРЕЛОЧКИ: Пред./Следующее<br/>ПРОБЕЛ: Следующее<br/>ENTER: Старт/Стоп слайдшоу<br/>ESCAPE: Закрыть галерею<br/>HOME/END: Первое/Последнее изображение<br/>H - Открыть панель помощи",
    "Slideshow" : "Начать",
    "OriginalContext": "View in original context"
}