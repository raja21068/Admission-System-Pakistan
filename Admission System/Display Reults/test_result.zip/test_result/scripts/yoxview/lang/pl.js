﻿{
    "Direction" : "ltr",
    "Close" : "Zamknij",
    "Help" : "Pomoc",
    "FirstImage" : "Do pierwszego obrazka",
    "LastImage" : "Do ostatniego obrazka",
    "StartStopSlideShow" : "Odtwarzaj/wstrzymaj pokaz slajdów",
    "Pause" : "Wstrzymaj",
    "Play" : "Odtwarzaj",
    "Prev" : "Poprzedni",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Następny",
    "PrevImage" : "Poprzedni obrazek",
    "NextImage" : "Następny obrazek",
    "Loading" : "Ładowanie",
    "CloseHelp" : "Zamknij pomoc",  
    "HelpText" : "Możesz sterować galerią za pomocą klawiatury:<br/><br/>LEWA/PRAWA STRZAŁKA: poprz. / nast. obrazek<br/>SPACJA: następny<br/>ENTER: rozpocznij/zatrzymaj pokaz slajdów<br/>ESCAPE: Zamknij galerię<br/>OME/END: pierwszy / ostatni obrazek<br/>H - panel pomocy",
    "Slideshow" : "Pokaz",
    "OriginalContext": "Zobacz w oryginalnym kontekście"
}