﻿{
    "Direction" : "ltr",
    "Close" : "Inchide",
    "Help" : "Ajutor",
    "FirstImage" : "Prima imagine",
    "LastImage" : "Ultima imagine",
    "StartStopSlideShow" : "Ruleaza/Pauza diaporama",
    "Pause" : "Pauza",
    "Play" : "Porneste",
    "Prev" : "Precedent",
    "PinInfo" : "Fixeaza info",
    "UnpinInfo" : "Ascunde info",
    "Next" : "Urmator",
    "PrevImage" : "Imaginea precedenta",
    "NextImage" : "Imaginea urmatoare",
    "Loading" : "Se incarca",
    "CloseHelp" : "Inchide ajutorul",  
    "HelpText" : "Prin galerie se poate naviga folosind tastatura:<br/><br/>SAGETILE STANGA/DREAPTA: Precedenta/Urmatoare<br/>BARA DE SPATIU: Urmatoarea<br/>ENTER: Start/Stop diaporama<br/>ESCAPE: Inchide galeria<br/>HOME/END: Prima/Ultima imagine<br/>H - Acest panou de ajutor",
    "Slideshow" : "Ruleaza",
    "OriginalContext": "Vezi in contextul original"
}