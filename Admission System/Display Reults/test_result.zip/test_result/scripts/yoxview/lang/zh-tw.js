﻿{
   "Direction" : "ltr",
   "Close" : "關閉",
   "Help" : "求助",
   "FirstImage" : "第一張",
   "LastImage" : "最後一張",
   "StartStopSlideShow" : "播放/暫停幻燈片",
   "Pause" : "暫停",
   "Play" : "播放",
   "Prev" : "上一頁",
   "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
   "Next" : "下一頁",
   "PrevImage" : "上一張",
   "NextImage" : "下一張",
   "Loading" : "載入中",
   "CloseHelp" : "關閉求助",
   "HelpText" : "你可以使用鍵盤進行畫廊導航：<br/><br/>左/右箭頭： 上一張/下一張<br/>空格鍵： 下一張<br/>Enter鍵： 播放/暫停幻燈片<br/>Esc鍵： 關閉畫廊<br/>HOME/END: 第一張/最後一張<br/>H - 求助面板",
   "Slideshow" : "輪播",
   "OriginalContext": "在原有範圍內查看"
}