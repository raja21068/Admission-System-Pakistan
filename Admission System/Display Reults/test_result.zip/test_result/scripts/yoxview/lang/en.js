﻿{
    "Direction" : "ltr",
    "Close" : "Close",
    "Help" : "Help",
    "FirstImage" : "To the first image",
    "LastImage" : "To the last image",
    "StartStopSlideShow" : "Play/Pause slideshow",
    "Pause" : "Pause",
    "Play" : "Play",
    "Prev" : "Prev",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Next",
    "PrevImage" : "Previous image",
    "NextImage" : "Next image",
    "Loading" : "Loading",
    "CloseHelp" : "Close help",  
    "HelpText" : "The gallery can be navigated using the keyboard:<br/><br/>LEFT/RIGHT ARROWS: Prev/Next<br/>SPACEBAR: Next<br/>ENTER: Start/Stop slideshow<br/>ESCAPE: Close gallery<br/>HOME/END: First/Last image<br/>H - This help panel",
    "Slideshow" : "Play",
    "OriginalContext": "View in original context"
}