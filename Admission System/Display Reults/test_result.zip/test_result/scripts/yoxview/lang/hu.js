﻿{
    "Direction" : "ltr",
    "Close" : "Bezárás",
    "Help" : "Súgó",
    "FirstImage" : "Az első képhez",
    "LastImage" : "Az utolsó képhez",
    "StartStopSlideShow" : "Lejátszás indítása/leállítása",
    "Pause" : "Szünet",
    "Play" : "Lejátszás",
    "Prev" : "Előző",
    "PinInfo" : "Info rögzítése",
    "UnpinInfo" : "Info feloldása",
    "Next" : "Következő",
    "PrevImage" : "Előző kép",
    "NextImage" : "Következő kép",
    "Loading" : "Töltés",
    "CloseHelp" : "Súgó bezárása",  
    "HelpText" : "A képgaléria billentyűzet segítségével is navigálható:<br/><br/>BALRA/JOBBRA NYÍL: Előző/Következő<br/>SZÓKÖZ: Következő<br/>ENTER: Vetítés indítása/leállításabr/>ESCAPE: Galéria bezárása<br/>HOME/END: Első/Utolsó kép<br/>H - Ez a súgó",
    "Slideshow" : "Lejátszás",
    "OriginalContext": "Megtekintés eredeti környezetben"
}