﻿{
    "Direction" : "ltr",
    "Close" : "Κλείσιμο",
    "Help" : "Βοήθεια",
    "FirstImage" : "Πρώτη Εικόνα",
    "LastImage" : "Τελευταία Εικόνα",
    "StartStopSlideShow" : "Έναρξη/Παύση του slideshow",
    "Pause" : "Παύση",
    "Play" : "Έναρξη",
    "Prev" : "Προηγούμενο",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Επόμενο",
    "PrevImage" : "Προηγούμενη Εικόνα",
    "NextImage" : "Επόμενη Εικόνα",
    "Loading" : "Φόρτωση",
    "CloseHelp" : "Κλείσιμο Βοήθειας",  
    "HelpText" : "Η περιήγηση στην γκαλερή μπορεί να γίνει με τη χρήση πληκτρολογίου:<br/><br/>ΑΡΙΣΤΕΡΑ/ΔΕΞΙΑ ΒΕΛΗ: Προηγούμενο/Επόμενο<br/>SPACEBAR: Επόμενο<br/>ENTER: Έναρξη/Τερματισμός παρουσίασης<br/>ESCAPE: Κλείσιμο γκαλερή<br/>HOME/END: Πρώτη/Τελευταία Εικόνα<br/>H - Βοήθεια",
    "Slideshow" : "Έναρξη",
    "OriginalContext": "Προβολή αρχικής μορφής"
}