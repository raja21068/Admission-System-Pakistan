﻿{
    "Direction" : "ltr",
    "Close" : "Dún",
    "Help" : "Cabhair",
    "FirstImage" : "Go dti an pictiúr amhain",
    "LastImage" : "Go dti an pictiúr seo caite",
    "StartStopSlideShow" : "Spraoi/Sos taispeántas",
    "Pause" : "Sos",
    "Play" : "Spraoi",
    "Prev" : "roimhe seo",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "is gaire",
    "PrevImage" : "Roimhe seo pictiúr",
    "NextImage" : "Pictiúr is gaire",
    "Loading" : "luchtú",
    "CloseHelp" : "Dun cabhair",
    "HelpText" : "Feachann tú an pictiúri le do keybhord:<br/><br/>Clé/Déis saighde: Prev/Next<br/>SPACEBAR: Next<br/>ENTER: Spraoi/ Sos taispeántas<br/>ESCAPE: Dun leathanach<br/>HOME/END: Go dti an pictiúr amhain/seo caite<br/>H - An leathanach cabhair",
    "Slideshow" : "Spraoi taispeבntas",
    "OriginalContext": "D'fhonn i gcomhthéacs bunaidh"
}