﻿{
    "Direction" : "ltr",
    "Close" : "Затвори",
    "Help" : "Помощ",
    "FirstImage" : "Към първата картинка",
    "LastImage" : "Към последната картинка",
    "StartStopSlideShow" : "Пусни/Спри поредица от картинки",
    "Pause" : "Спри",
    "Play" : "Пусни",
    "Prev" : "Предишна",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Следваща",
    "PrevImage" : "Предишна картинка",
    "NextImage" : "Следваща картинка",
    "Loading" : "Зареждам",
    "CloseHelp" : "Затвори панела за помощ",  
    "HelpText" : "в галерията може да изпозлвате:<br/><br/>LEFT/RIGHT СТРЕЛКА: Предишна/Следваща<br/>SPACE: Следваща<br/>ENTER: Пусни/Спри поредица от картинки<br/>ESCAPE: Затвори галерията<br/>HOME/END: Първа/Последна картинка<br/>H - Този помощен панел",
    "Slideshow" : "Пусни",
    "OriginalContext": "Вижте в оригинален контекст"
}