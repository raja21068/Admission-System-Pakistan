﻿{
    "Direction" : "ltr",
    "Close" : "Fermer",
    "Help" : "Aide",
    "FirstImage" : "Première image",
    "LastImage" : "Dernière image",
    "StartStopSlideShow" : "Démarrer/Pause diaporama",
    "Pause" : "Pause",
    "Play" : "Démarrer",
    "Prev" : "Précédente",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Suivante",
    "PrevImage" : "Image précédente",
    "NextImage" : "Image suivante",
    "Loading" : "Chargement",
    "CloseHelp" : "Fermer l'aide",  
    "HelpText" : "La navigation peut se faire avec le clavier :<br/><br/>Flêches GAUCHES/DROITES: Précédente/Suivante<br/>Espace: Suivante<br/>Entrée: Démarrer/Arrêter<br/>Echap: Fermer<br/>HOME/FIN: Première/Dernière image<br/>H - Afficher ce panneau d'aide",
    "Slideshow" : "Démarrer",
    "OriginalContext": "Voir dans le contexte original"
}