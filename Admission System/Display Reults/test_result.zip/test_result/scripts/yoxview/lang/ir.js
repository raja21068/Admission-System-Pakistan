﻿{
    "Direction" : "rtl",
    "Close" : "بستن",
    "Help" : "راهنما",
    "FirstImage" : "تصویر نخست",
    "LastImage" : "تصویر آخر",
    "StartStopSlideShow" : "شروع/خاتمه نمایش",
    "Pause" : "توقف",
    "Play" : "نمایش",
    "Prev" : "قبلی",
    "PinInfo" : "نمایش اطلاعات",
    "UnpinInfo" : "عدم نمایش اطلاعات",
    "Next" : "بعدی",
    "PrevImage" : "تصویر قبلی",
    "NextImage" : "تصویر بعدی",
    "Loading" : "بارگزاری",
    "CloseHelp" : "بستن راهنما",  
    "HelpText" : "گالری با استفاده از دکمه های صفحه کلید نیز عمل میکند:<br/><br/>دکمه قبلی و بعدی : قبلی/بعدی<br/>زر space: بعدی<br/>ENTER: توقف/نمایش<br/>ESCAPE: بستن گالری<br/>HOME/END: ابتدا/انتهای تصاویر<br/>H - صفحه راهنما",
    "Slideshow" : "نمایش اسلاید",
    "OriginalContext": "محتوای اصلی"
}