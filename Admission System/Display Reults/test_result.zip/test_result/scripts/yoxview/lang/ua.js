﻿{
    "Direction" : "ltr",
    "Close" : "Закрити",
    "Help" : "Допомога",
    "FirstImage" : "До першого зображення",
    "LastImage" : "До останнього зображення",
    "StartStopSlideShow" : "Почати/Призупинити слайдшоу",
    "Pause" : "Призупинити",
    "Play" : "Почати",
    "Prev" : "Попереднє",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Наступне",
    "PrevImage" : "Попереднє зображення",
    "NextImage" : "Наступне зображення",
    "Loading" : "Завантаження",
    "CloseHelp" : "Закрити допомогу",  
    "HelpText" : "Керувати галереєю можна за допомогою клавіатури:<br/><br/>ЛІВА/ПРАВА СТРІЛОЧКИ: Попереднє/Наступне<br/>ПРОБІЛ: Наступне<br/>ENTER: Старт/Стоп слайдшоу<br/>ESCAPE: Зачинити галерею<br/>HOME/END: Перше/Останнє зображення<br/>H - Відкрити панель допомоги",
    "Slideshow" : "Почати",
    "OriginalContext": "View in original context"
}