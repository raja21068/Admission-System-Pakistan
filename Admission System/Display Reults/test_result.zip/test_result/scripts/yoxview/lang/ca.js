﻿{
    "Direction" : "ltr",
    "Close" : "Tancar",
    "Help" : "Ajuda",
    "FirstImage" : "Anar al principi",
    "LastImage" : "Anar al final",
    "StartStopSlideShow" : "Començar/Pausar",
    "Pause" : "Pausar",
    "Play" : "Començar",
    "Prev" : "Anterior",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Següent",
    "PrevImage" : "Imatge anterior",
    "NextImage" : "Següent imatge",
    "Loading" : "Carregant",
    "CloseHelp" : "Tancar l'ajuda",  
    "HelpText" : "Pot navegar per la presentaci&oacute; utilitzant el teclat:<br/><br/>Fletxes ESQUERRA/DRETA: Anterior/Seg&uuml;ent<br/>SPACEBAR: Seg&uuml;ent<br/>ENTER: Comen&ccedil;ar/Parar la presentaci&oacute;<br/>ESCAPE: Tancar<br/>HOME/END: Principi/Final<br/>H - Mostra aquesta ajuda",
    "Slideshow" : "Començar",
    "OriginalContext": "Veure al context original"
}
