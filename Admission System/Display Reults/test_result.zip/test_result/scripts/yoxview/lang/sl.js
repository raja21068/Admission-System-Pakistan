{
    "Direction" : "ltr",
    "Close" : "Zapri",
    "Help" : "Pomo&#269;",
    "FirstImage" : "Na prvo sliko",
    "LastImage" : "Na zadnjo sliko",
    "StartStopSlideShow" : "Po&#382;eni/Ustavi projekcijo",
    "Pause" : "Ustavi",
    "Play" : "Predvajaj",
    "Prev" : "Nazaj",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Naprej",
    "PrevImage" : "Predhodna slika",
    "NextImage" : "Naslednja slika",
    "Loading" : "Nalagam",
    "CloseHelp" : "Zapri pomo&#269;",
    "HelpText" : "Med slikami se lahko pomikate z uporabo tipkovnice:<br/><br/>PU&#352;&#268;ICI LEVO/DESNO: Nazaj/Naprej<br/>PRESLEDNICA: Naprej<br/>VNOS: Po&#382;eni/Ustavi projekcijo<br/>ESC: Zapri galerijo<br/>HOME/END: Prva/Zadnja slika<br/>H - Pomo&#269;",
    "Slideshow" : "Predvajaj",
    "OriginalContext": "View in original context"
}