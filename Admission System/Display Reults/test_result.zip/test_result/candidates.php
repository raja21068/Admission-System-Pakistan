
<?php
if (isset($_REQUEST['admission_list_detail'])) {
    ?>
    <table  border="1" >
        <tr> 
            <th>SEAT#</th>
            <th>NAME</th>
            <th>FATHER</th>
            <th>DITRICT</th>
            <th>U/R</th>
			<th>CPN</th>
        </tr>

        <?php
		require_once './DatabaseManager.php';
     $con= DatabaseManager::connect();
        $admListDetailId = mysqli_real_escape_string($con,$_REQUEST['admission_list_detail']);
        $campusId = mysqli_real_escape_string($con,$_REQUEST['campus_id']);
        $discip = mysqli_real_escape_string($con,$_REQUEST['discipline']);
        $cat = mysqli_real_escape_string($con,$_REQUEST['category']);
           $result = DatabaseManager::getAllCandidates($admListDetailId, $campusId, $discip, $cat);
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "      <td>".$row['SEAT_NO']."</td>";
            echo "      <td>".$row['NAME']."</td>";
            echo "      <td>".$row['FATHER']."</td>";
            echo "      <td>".$row['DISTRICT']."</td>";
            echo "      <td>".$row['AREA']."</td>";
			echo "      <td>".$row['CPN']."</td>";
            echo "</tr>";
        }
        ?>
    </table>
        <?php
    }
    ?>
