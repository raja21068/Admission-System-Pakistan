<?php

if (isset($_REQUEST['admission_list_detail'])) {
 require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    echo "<option value=''>--SELECT DEGREE--</option>";
    $admListDetailId = mysqli_real_escape_string($con,$_REQUEST['admission_list_detail']);
    $campusId = mysqli_real_escape_string($con,$_REQUEST['campus_id']);
   $programType= mysqli_real_escape_string($con,$_REQUEST['programType']);
   //echo("ppp".$programType);
        
    $result =  DatabaseManager::getDistinctDiscipline($admListDetailId, $campusId,$programType);
    while ($row = mysqli_fetch_array($result)) { 
        echo "<option value='".$row['DISCIPLINE']."'>".$row['DISCIPLINE']."</option>";
    }
}else{
    echo '<option>No admission_list_detail</option>';
}
?>
