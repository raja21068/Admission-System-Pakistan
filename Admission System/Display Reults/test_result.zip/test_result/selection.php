<?php




if (isset($_REQUEST['seatNo'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['seatNo']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);


    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
	$countrows=mysqli_num_rows($result);
	 if ($row = mysqli_fetch_array($result)) {
	    $candidateId = $row['CANDIDATE_ID'];
		//echo($candidateId);
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
        $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];
		

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];


		
       ?>

        <table class='table  table-condensed table-bordered' >

             <!--<tr><td style="background-color: #006633; color: white; " colspan="2"><strong>Congratulations, You are selected..!</strong></td></tr>-->
      
			<tr><td>Seat#:</td><td><strong><?php echo $seatNo; ?></strong></td></tr>
            <tr><td>Name of the Candidate:</td><td><strong><?php echo $name; ?></strong></td></tr>
            <tr><td>Father<span>'<span>s Name:</td><td><strong><?php echo $father; ?></strong></td></tr>
            <tr><td>District (Domicile):</td><td><strong><?php echo $district; ?></strong></td></tr>
            <tr><td>Urban/Rural:</td><td><strong><?php  if ($area=="U" || $area=="0" ){echo("URBAN");}else{echo("RURAL");} ?></strong></td></tr>
			<tr><td>SSC (Matric) Marks:</td><td><strong><?php echo $ssc_obt; ?></strong></td></tr>
			<tr><td>SSC Total Marks:</td><td><strong><?php echo $ssc_total_marks; ?></strong></td></tr>
			<tr><td>SSC Year:</td><td><strong><?php echo $ssc_year; ?></strong></td></tr>
			<tr><td>HSC (Inter) Marks:</td><td><strong><?php echo $hsc_obt; ?></strong></td></tr>
			<tr><td>HSC Total Marks:</td><td><strong><?php echo $hsc_total_marks; ?></strong></td></tr>
			<tr><td>HSC Year:</td><td><strong><?php echo $hsc_year; ?></strong></td></tr>
			
			
		   <tr><td><?php if($programType == 1) echo("HSC Group"); else echo("Degree");?>:</td><td><strong><?php echo $degree; ?></strong></td></tr>
			
   		<tr><td>Board :</td><td><strong><?php echo $last_issuer; ?></strong></td></tr>
			
		<tr><td>TEST MARKS:</td><td><strong><?php echo $test_score; ?></strong></td></tr>

				  <tr><td>SSC (Matric) Score[10]:</td><td><strong><?php echo $ssc_perc; ?></strong></td></tr>
            <tr><td> HSC (Inter) Score[<?php if ($programType == 2) {
            echo "15";
        } else {
            echo "30";
        } ?>]:</td><td><strong><?php echo $hsc_perc; ?></strong></td></tr>
		
		
            <?php if ($programType == 2) { ?>
                <tr><td>Graduation:</td><td><strong><?php echo $degree; ?></strong></td></tr>
                <tr><td>Graduation / Post-Graduation  marks:</td><td><strong><?php echo $grad_obt; ?></strong></td></tr>
                <tr><td>Graduation / Post-Graduation score[35]:</td><td><strong><?php echo $grad_perc; ?></strong></td></tr>
            <?php } ?>
        <?php if ($deductionMarks != 0) { ?>
                <tr><td>DEDUCTION MARKS:</td><td><strong><?php echo $deductionMarks; ?></strong></td></tr>
                <tr><td>MARKS AFTER DEDUCTION:</td><td><strong><?php echo $marksAfterDeduction; ?></strong></td></tr>
            <?php } ?>
        
            <tr><td>TEST SCORE [60]:</td><td><strong><?php 
			if($admissionListDetailId==0){
				echo ($test_perc);
			}else{
			echo $test_perc;
			}			
			?></strong></td></tr>
            <tr><td>Total CPN [100]:</td><td><strong><?php echo $cpn; ?></strong></td></tr>
                        
						<?php
						
						if ($objectionRemarks != "")  {

						?>
                <tr><td>Objection Remarks:</td><td style="color: white; background-color: red;"><strong><?php echo "$objectionRemarks"; ?></strong></td></tr>
        <?php } ?>
        <?php
		
		if($admissionListDetailId==0){
			echo("<tr><td colspan='2'><strong>Print Reports:</strong></td></tr>");

	//		echo("<tr><td>Objection Form </td> <td colspan='1'><a href='print_objection.php?program_type=$programType&s=$seatNo&admission_list_detail_id=$admissionListDetailId&admission_session=$admission_session'><img src='images/print-icon.jpg' height='10' width='10' align='center'></a></td></tr>");

			echo("<tr><td>Objection Form </td><td><a href='print.php?program_type=$programType&s=$seatNo&admission_list_detail_id=$admissionListDetailId&admission_session=$admission_session'><img src='images/print-icon.jpg' height='10' width='10' align='center'></a></td></tr>");

			return;
		}
		

			/*---------------------Campus and Category Print -------------------------*/
				
                
                echo("<tr><td colspan='2'><strong>You are selected in:</strong></td></tr>");
 
				if($discipline!='0'){

				
?>		
                <tr><td>Program:</td><td><strong><?php echo $discipline; ?></strong></td></tr>
                <tr><td>Category:</td><td><strong><?php echo $category; ?></strong></td></tr>
				<tr style="margin-bottom:10px;"><td>Campus: </td><td ><strong> <?php echo $campus; ?></strong></td></tr>
				<tr><td colspan=2></td></tr>
                <?php } ?>
                <?php
                while ($row = mysqli_fetch_array($result)) {
                    $campus = $row['CAMPUS'];
                    $category = $row['CATEGORY'];
                    $discipline = $row['DISCIPLINE'];
                    $campusId2 = $row['CAMPUS_ID'];
					if($discipline=='0'){
						continue;
						}
			
                    ?>
                    <tr><td>Program:</td><td><strong><?php echo $discipline; ?></strong></td></tr>
                    <tr><td>Category:</td><td><strong><?php echo $category; ?></strong></td></tr>

                <?php
				
                    echo "<tr><td>Campus: </td>  <td><strong>$campus</strong></td></tr>";
					 
					 
					 
                    $campusId = $campusId2;
				?>
				<tr><td colspan=2></td></tr>
              
				<?php
			
            }
				/*----------------Challan Amount Print ----------------*/
/*
					$resultChalan=DatabaseManager::getChallan($candidateId);
					$countChalan=mysqli_num_rows($resultChalan);
		
							if($countChalan>0){		
							
							
							echo("<tr><td colspan='2'><strong>Challan available for you: </strong></td></tr>");
							$challanCount=0;
							if ($rowChallan = mysqli_fetch_array($resultChalan)) {
							$challanCount++;
							$challanCode = $rowChallan['CHALLAN_CODE'];
							$amount = $rowChallan['AMOUNT'];
							$deptName = $rowChallan['NAME'];
							
							$challanCount++;
							
							?>
									<?php if ($challanCount>=2) ?> <tr><td colspan=2></td></tr>
									<tr><td>Challan Amount:</td><td><strong><?php echo $amount; ?></strong></td></tr>
									<tr><td>Department Name:</td><td><strong><?php echo $deptName; ?></strong></td></tr>
							

							



			<?php
		
		
		    } // end while of fees
	}//end count if
*/

					
				/*---------------------Paid fees Amount Print -------------------------*/
						
					
					$resultfees=DatabaseManager::getFees($candidateId);
					$count=mysqli_num_rows($resultfees);
		
							if($count>0){		
							
							
							if($admissionListDetailId=="2" || $admissionListDetailId=="3"){
								echo(" <tr><td colspan='2'> <strong><font color='red'> Please pay the fee difference (if any) by collecting your challan and depositing in bank within due date. </font> </strong></td></tr>");
								}
							echo("<tr><td colspan='2'><strong>Your fee payment details:</strong></td></tr>");
							$feesCount=0;
							while ($rowfees = mysqli_fetch_array($resultfees)) {
							$feesCount++;
							$challan_no = $rowfees['CHALLAN_NO'];
							$amount = $rowfees['AMOUNT'];
							$challan_date = $rowfees['CHALLAN_DATE'];
							$fees_type = $rowfees['FEE_TYPE'];
							$feesCount++;
							
							?>
									<?php if ($feesCount>=2) ?> <tr><td colspan=2></td></tr>
									<tr><td>Paid Amount:</td><td><strong><?php echo $amount; ?></strong></td></tr>
									<tr><td>Challan No:</td><td><strong><?php echo $challan_no; ?></strong></td></tr>
									<tr><td>Date Of Payment:</td><td><strong><?php echo $challan_date; ?></strong></td></tr>
									<tr><td>Fee Type:</td><td><strong><?php echo $fees_type; ?></strong></td></tr>
							

							



			<?php
		
		
		    } // end while of fees
	}//end count if
	

	else{
	//r1
//	if($admissionListDetailId=='1') {echo("<tr><td><img src='images/alert.jpg'> </td><td>Your provisional admission for this discipline is cancelled now, as you haven't paid the fees within due date i.e. 15th December 2014.</td></tr> ");	}
	}
	
	
        if ($choiceNo != 1) {
			//r2
			//if($admissionListDetailId=='2' && $programType=='1'){

		   ?>    
			<!--
             <tr><td colspan='2'>
                    <strong><font color='blue'>If you wish to study in selected choice, you must deposit Rs.200 in separate bank challan with Admission Retaining Application so that your choice may not be changed lateron.</font></strong>
               </td> </tr>
				-->
            <?php
        //}
		}
    ?>
	<?php
	
    } // end if mysql_affected_rows (candidate)
	else {
	        echo("<table class='table table-bordered' >");
		if($admissionListDetailId==0){
		
	
	echo ("<tr><td class='danger'><h4>Invaild Seat No</h4></td></tr>");
		 return;
		}
		if($admissionListDetailId==1){
		 echo '<br/><h4>You are not selected, please wait for next merit list..</h4>';
		 return;
		}
		
	
		
		$resultAdmi = DatabaseManager::getCandidateFromSession($seatNo, $programType, $admission_session);
		 if ($rowAdmi = mysqli_fetch_array($resultAdmi)) {
		   echo '<br/><h4>You were selected in Pervious Merit List</br>';
				$candidateId = $rowAdmi['CANDIDATE_ID'];
		//r3		
   		//$resultfees1=DatabaseManager::getFees($candidateId);
				//$rowfees = mysqli_fetch_array($resultfees1);
		
		//					if($rowfees==false){		echo("<tr><td><img src='images/alert.jpg'> </td><td>Your provisional admission for this discipline is cancelled now, as you haven't paid the fees within due date i.e. 15th December 2014.</td></tr> ");						}
		   	return;

		 }else {
				if($admissionListDetailId==3){   echo '<br/><h4>You are not selected..</h4>'; return;}
				if($admissionListDetailId==4){echo '<br/><h4>You are not selected in suppmental admission list for bachelor degree programs 2016</h4>'; return;}
         
				echo '<br/><h4>You are not selected, please wait for next merit list..</h4>';
			
					 return;

        }
				
	}
	
}//if seatNo
?>
<?php
echo("<tr><td colspan='2'><strong>Print Reports:</strong></td></tr>");

//echo("<tr><td>Objection Form </td> <td colspan='1'><a href='print_objection.php?program_type=$programType&s=$seatNo&admission_list_detail_id=$admissionListDetailId&admission_session=$admission_session'><img src='images/print-icon.jpg' height='10' width='10' align='center'></a></td></tr>");

echo("<tr><td>Objection Form </td> <td><a href='print.php?program_type=$programType&s=$seatNo&admission_list_detail_id=$admissionListDetailId&admission_session=$admission_session'><img src='images/print-icon.jpg' height='10' width='10' align='center'></a></td></tr>");

    
?>

           </table>
    				
</br>

