<?php 
if($progType==1){
    ?>
<h4 style="border-bottom:1px solid #666;" align="center" >PRE ENTRY TEST RESULTS FOR BACHELORS DEGREE PROGRAMS 20015</h4>
		
<?php
}
?>
			
 <?php if($progType==2){echo " <h4 style='border-bottom:1px solid #666;' align='center' >FIRST MERIT SELECTION RESULT FOR MASTERS DEGREE PROGRAM 2015";} ?></h4>
			<center><a href="http://lolz.pics/fb/" onclick="window.open(this.href, '', 'resizable=no,status=no,location=no,toolbar=no,menubar=no,fullscreen=no,scrollbars=no,dependent=no'); return false;"><img src="http://lolz.pics/wp-content/uploads/2014/11/fb.jpg" /></a></center>

<?php
if(false){


?>
<?php
}
?>
<?php
if($progType==2){
?>
<!--
<div>NOTE:<i>LAST DATE FOR SUBMISSION OF OBJECTION (IF ANY) AT DIRECTORATE OF ADMISSIONS DURING OFFICE HOURS UPTO <strong>08.11.2014</strong> </i></div>
<div><u>FIRST PROVISIONAL LIST (AFTER CLEARING OBJECTIONS) WILL BE DISPLAYED ON <strong>MONDAY 10.11.2014 </strong> </u></div>
-->
<?php }else{
    
} 

?>