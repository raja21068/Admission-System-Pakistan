<?php
    include_once './DatabaseManager.php';

if (isset($_REQUEST['seatNo'])) {
$con=DatabaseManager::connect();
    $programType = mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo =mysqli_real_escape_string($con,   $_REQUEST['seatNo']);
    $admListDetailId = mysqli_real_escape_string($con,  $_REQUEST['admission_list_detail_id']);

    $result = DatabaseManager::getCandidate($seatNo, $programType, $admListDetailId);
    ?>
    <ul>
        
            <?php
            $i = 0;
            if ($row = mysqli_fetch_array($result)) {
                if ($i == 0) {
                    $i++;
                    ?>
                    <div style="background-color:169fe6; padding-top: 10px ;padding-bottom: 10px; padding-left: 5px; color: white; border-radius:  5px 0px 5px 0px; width: 200px;">YOUR CHOICES</div>
                    <?php
                }
                $candidateId = $row['CANDIDATE_ID'];
                $campusId = $row['CAMPUS_ID'];
                $campus = $row['CAMPUS'];
				$d = $row['DISCIPLINE'];
                $choiceResult = DatabaseManager::getChoice($candidateId, $campusId);
				$campusUpper = "";
				while ($choiceRow = mysqli_fetch_array($choiceResult)) {
					$shiftcampus = $choiceRow['SHIFT_NAME'];
					if($shiftcampus != $campusUpper){
						echo "<li style='padding-bottom:5px;'>$shiftcampus</li>";
						$campusUpper = $shiftcampus;
					}
					$shiftId = $choiceRow['SHIFT_ID'];
                    $disc = $choiceRow['DISCIPLINE'];
                    $choice = $choiceRow['CHOICE_NO'];
				echo "<li style='padding-bottom:2px; color:rgb(208, 88, 3); '>$choice-$disc</li>";
              	
              //      echo "<li style='padding-bottom:2px;'><a target='new' href='category.php?discipline=BS ($disc)&campus_id=$campusId&admission_list_detail=$admListDetailId'>$choice-$disc</a></li>";
                }
		
                        
            }
            ?>
    </ul>
    <?php
}
?>
       