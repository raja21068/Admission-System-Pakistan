<?php include("bar.php"); ?>
<div class="clearfix"></div>
<!--<link rel="stylesheet" type="text/css" href="style.css" media="all" />-->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
 <!-- Fevicon
================================================== -->
<link rel="shortcut icon" href="favicon.ico">
<link rel="icon" type="image/gif" href="images/animated_favicon1.gif">

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>FAQs</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 <body id="pageBody">

<div class="container" id='container' style='width: auto;'>
<h3 class="text-primary" >How is the merit for admissions determined? </h3>
<p  class="lead">The merit for admissions shall be determined on the basis of Pre-entry Test score and the total marks obtained in the first attempt as well as previous academic record. However, candidates who do not qualify the Pre-Entry-Test will not be considered for admission in any discipline.</p>

<h3 class="text-primary" >How is weightage assigned to the Score of Pre Entry Test and Other Scores (academic) determined?</h3>
<p class='lead'>The weightage assigned to the Pre-entry test and previous academic record will be as under:-</p>
<div class='row'>
<div class='col-md-6'>
<table class='table table-bordered'>
<tr>
<td></td>
<td></td>
<td>Bachelor</td>
<td>Master</td>
</tr>
<tr>
<td>1</td>
<td>S.S.C.</td>
<td>10%</td>
<td>10%</td>
</tr>
<tr>
<td>2</td>
<td>H.S.C.(adjusted marks)</td>
<td>50%</td>
<td>15%</td>
</tr>
<tr>
<td>3</td>
<td>Bachelor Degree (-do-)</td>
<td>--</td>
<td>35%</td>
</tr>
<tr>
<td>4</td>
<td>Pre-Entry Test / Aptitute test </td>
<td>40%</td>
<td>40%</td>
</tr>
</table>
</div>
<div class='col-md-6'></div>
</div>
<h3 class="text-primary" >How is weightage assigned in case of improvers/repeaters?</h3>
<p class='lead'>    In case of improvers/ repeaters, marks shall be deducted as per rules from the total marks of the candidates in order to prepare the adjusted merit list. This deduction shall not alter the division/ grade of the candidates</p>
<ol>
  <li>05 marks to be deducted if the candidate has appeared second time in H.S.C. Examination in order to improve his/ her Division/ Grade.</li>
  <li>In case H.S.C. Examination has not been cleared within the minimum period required for passing the same after passing Matriculation Examination, every additional year or part of a year beyond this period shall be treated as candidate<span>'<span>s attempt for the purpose of deducting marks irrespective of his/ her having not appeared in the examination in each year.</li>
  <li>05 marks shall be deducted from the total marks for the loss of each extra year or part thereof.
However, a maximum of 25 marks may be deducted.</li>
  <li>Same rules shall apply if a candidate fails to clear Bachelor degree Examination within the minimum period required for passing such examination after Matriculation Examination.</li>
  <li>05 marks per year shall be deducted from the total marks if the candidate has not passed the pre-requisite examination in the preceding year.</li>
</ol>
<h3 class='text-primary'>What are the Eligibility & other Rules?</h3>
<ol>
<li>No admission shall be allowed to a candidate who has passed the pre-requisite examination in <b>Third Division</b> from any Board  or University.</li>
<li>A student of B.A./ Hons./ B.S/ B.Com. (Hons.) Part-I Class shall be allowed transfer from the University to an affiliated college within three months from the last date of admission, but no transfer from college to University is allowed.</li>

<li><b>No change of subject shall be allowed after closing of admission.</b></li>
<li>The admissions to various Bachelor (Honours) and Master (Prev.) professional/ quota-oriented courses of study shall be made in accordance with the Regulations prescribed for the purpose.</li>
<li>The fairness, transparency and correctness in admissions will be monitored and enforced by a committee of Senior Professors of the University appointed by the <b>Vice-chancellor with Director Admissions as its Secretary. Pre-Entry Test will also be conducted under the supervision of this Committee.</b></li>
<li>A candidate who has passed H.S.C. Science, Commerce or H.S.C. Home Economics Examination is also eligible for admission to 4-yr. Bachelor/ B.A. (Hons) program.</li>
<li>Candidates who are interested in seeking admission in the <b>Institute of Art & Design</b> shall also have to take up <b>Aptitude Test</b> to be conducted by the Institute, as per schedule to be announced by the Director.
Aptitude Test is also mandatory for admission to the newly introduced<b> B.S.H.P.E. Part-I</b> course of study.
</li>
<li>   A candidate who has already completed his/her course of study in a University Teaching Institute/ Department/ Centre leading to Bachelor<span>'s</span> (Pass/ Honours) degree shall NOT be eligible for admission to another  or second Bachelor<span>'</span>s (Pass/ Honours) course (except B.Ed./ B.H. P.E.<span>,<span> and Post Graduate Diplomas)  in the University Teaching Institute/ Department/ Centre.</li>
<li>      A candidate who has already passed Bachelor<span>'<span>s Pass degree course examination from the University of Sindh or any other university<span>,<span> shall NOT be eligible for admission to another Bachelor<span>'<span>s (Pass/ Honours) course excepting B.Ed. or B.H. P.E.<span>,<span> and Post Graduate Diploma courses programs.</li>
<li><b>Admission on migration basis </b>from other Universities to this University shall be considered on the following grounds:
<ol type='A'>
<li>The student has cleared all the subjects/papers of the last examination from the parent University.</li>
<li>Parents of the student who are Government Officials are posted within the territorial jurisdiction of the University of Sindh.</li>
<li>Parents of the student who are Government Officials are posted within the territorial jurisdiction of the University of Sindh.</li>
<li>Admission on migration basis in the following Quota-Oriented disciplines will only be permissible under <b>Self Finance Scheme:-</b>
Business Administration/ Computer Science/ Information Technology/Telecommunication/ Electronics/ Geology/ Pharmacy/ Public Administration</li>

</ol>
</li>


</div>
</body>
<?php include ("footerbar.php");?>