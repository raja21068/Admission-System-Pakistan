<?php

if (isset($_REQUEST['seatNo'])) {
    require_once 'DatabaseManager.php';
    $con=DatabaseManager::connect();

    $seatNo = mysqli_real_escape_string($con,$_REQUEST['seatNo']);
    $program_type_id= mysqli_real_escape_string($con,$_REQUEST['program_type_id']);

    $result=DatabaseManager::getEntryTestResult($seatNo,$program_type_id);

//$result = DatabaseManager::getCandidate(5, 2, 1);
            $countrows=mysqli_num_rows($result);
            if ($row = mysqli_fetch_array($result)) {
            $candidateId = $row['SEAT_NO'];
            $name = $row['NAME'];
            $father = $row['FATHER_NAME'];
            $perecent_score = $row['PERCENT_SCORE'];
            $total_score = $row['TOTAL_SCORE'];
            $remarks=$row['REMARKS'];






?>

            <table class='table  table-condensed table-bordered' >
            <tr><td>Seat#:</td><td><strong><?php echo $seatNo; ?></strong></td></tr>
            <tr><td>Name of The Candidate:</td><td><strong><?php echo $name; ?></strong></td></tr>
            <tr><td>Father<span>'</span>s Name:</td><td><strong><?php echo $father; ?></strong></td></tr>
            <tr><td>Total Score [400]:</td><td><strong><?php echo $total_score; ?></strong></td></tr>

            <tr><td>Test Score</td><td><strong><?php echo $perecent_score; ?></strong></td></tr>
                      <tr><td>Remarks: </td><td><strong><?php echo $remarks; ?></strong></td></tr>
              
<?php
    }

    }

?>
