<?php

if (isset($_REQUEST['s'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['s']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);
    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
    if ($row = mysqli_fetch_array($result)) {
        $candidateId = $row['CANDIDATE_ID'];
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
        $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];
	
	
			$columnWidth = 60;
			 $columnHeight = 5;

require('fpdf/cellpdf.php');
		class PDF extends CellPDF
		{
		function Header()
			{
//    	$Image('sindh-university.png',50,50,100);
		   
		//	$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size 
			 
 $this->SetFont('Arial','B',15);
 //  $this->Cell($w,9,$REMARKS_PROGRAM_NAME,1,1,'C',false);
//	$this->Ln(10);
  		
		}
		function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

		}
		
		
			 
		$pdf=new CellPDF();
		$pdf->SetFont('Times','',12);
		$pdf->AddPage();
		//$pdf->Open();
		//First name

		
		//$pdf->Cell(0,8,"University of Sindh Jamshoro Admission Resuls",0,1,'C',false);
			$pdf->SetFont('Times','',20);
	//	$pdf->AddPage();
		$pdf->Image('images/logo.png',20,5,20);
		$pdf->Cell(0,8,"University of Sindh Jamshoro",0,1,'C',false);
		$pdf->Ln();
		$pdf->text(80,22,"Objection Form");
		$pdf->Ln();
		$pdf->Image('images/right_logo.jpg',170,5,18);
		$pdf->Line(10,30,200,30);
	
		$pdf->SetFont('Times','',12);
		
	//	$pdf->Cell(0,9,"Admission Resuls",0,1,'C',false);
		$pdf->Ln();
		$w = array(90, 45, 120, 50,40,20);
		$h=8;
		
		 $pdf->Ln(2);
        $pdf->SetFont("Times",'B',10);
        $pdf->Cell(0,$columnHeight,"Personal Information",0,1);
        $pdf->SetFont("Times",'',10);
		
		$pdf->Cell($columnWidth,$columnHeight,"Seat No",1,0);
        $pdf->Cell(0,$columnHeight,"".$seatNo ,1,1,'L');
      
        $pdf->Cell($columnWidth,$columnHeight,"Name",1,0);
        $pdf->Cell(0,$columnHeight,"".$name ,1,1,'L');
        $pdf->Cell($columnWidth,$columnHeight,"Father's Name",1,0);
        $pdf->Cell(0,$columnHeight,"".$father,1,'L');
		$pdf->ln();
		 	$pdf->Cell($columnWidth,$columnHeight,"District (Domicile):",1,0);
			$pdf->Cell(0,$columnHeight,"$district",1,0,'L');
			$pdf->ln();
	
				if ($area=="U" || $area=="0"){
		$pdf->Cell($columnWidth,$columnHeight,"Urban/Rural:",1,0);
		$pdf->Cell(0,$columnHeight,"URBAN",1,0);
		$pdf->ln();
			
			}else{
		$pdf->Cell($columnWidth,$columnHeight,"Urban/Rural:",1,0);
		$pdf->Cell(0,$columnHeight,"RURAL",1,0);
		$pdf->ln();
			}
	
	
		$pdf->Ln(2);
        $pdf->SetFont("Times",'BU',10);
        $pdf->Cell(0,$columnHeight,"OBJECTION DETAILS",0,1);      
        $pdf->SetFont("Times",'B',10);
        $pdf->Cell($columnWidth/4,$columnHeight*2,"S No",1,0);
        //$pdf->Cell($columnWidth/3,$columnHeight*2,"Group",1,0,'C');
        $pdf->Cell($columnWidth,$columnHeight*2,"Objection Type",1,0,'C');
      //  $pdf->Cell($columnWidth/3,$columnHeight*2,"Tick",1,0,'C');
        $pdf->Cell($columnWidth-5,$columnHeight*2,"Web Display",1,0,'C');
        $pdf->Cell($columnWidth,$columnHeight*2,"Candidate Claim",1,0,'C');
	  //  $pdf->Cell(0,$columnHeight*2,"Deducation\n Marks",1,0,'C');
		 //$pdf->Cell(0,$columnHeight*2,"MARKS AFTER\n DEDUCTION",1,0,'C');
		//$pdf->TextField('firstname',50,5,array('BorderColor'=>'ltGray'));
		  $pdf->ln();
      	$sno=1;
        $pdf->SetFont("Times",'B',10);

		$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		$pdf->Cell($columnWidth,$columnHeight,"Marks - S.S.C (Matriculation)",1,0);
	//	$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		$pdf->Cell($columnWidth-5,$columnHeight,"".$ssc_obt,1,0,'C');
		$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		$pdf->ln();
		$sno++;

		$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		$pdf->Cell($columnWidth,$columnHeight,"Marks - H.S.C (Intermediate)",1,0);
		//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		$pdf->Cell($columnWidth-5,$columnHeight,"".$hsc_obt,1,0,'C');
		$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		$pdf->ln();
		$sno++;



	  if($programType==2){

		  $pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		  $pdf->Cell($columnWidth,$columnHeight,"Marks - Graduation (Bachelor Degree)",1,0);
		  //$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		  $pdf->Cell($columnWidth-5,$columnHeight,"".$grad_obt,1,0,'C');
		  $pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		  $pdf->ln();
		  $sno++;
	  }

	 

	 if ($deductionMarks != 0) {
		 $pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		 $pdf->Cell($columnWidth,$columnHeight,"DEDUCTION MARKS",1,0);
		// $pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		 $pdf->Cell($columnWidth-5,$columnHeight,"$deductionMarks",1,0,'C');
		 $pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		 $pdf->ln();
		 $sno++;

	 }

		$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		$pdf->Cell($columnWidth,$columnHeight,"District (Domicile)",1,0);
		//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		$pdf->Cell($columnWidth-5,$columnHeight,"$district",1,0,'C');
		$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		$pdf->ln();
		$sno++;


		$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		$pdf->Cell($columnWidth,$columnHeight,"Urban/Rural",1,0);
		//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		if ($area=="U" || $area=="0") {

			$pdf->Cell($columnWidth -5, $columnHeight, "URBAN", 1, 0, 'C');
		}else{
			$pdf->Cell($columnWidth -5, $columnHeight, "RURAL", 1, 0, 'C');
		}
		$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		$pdf->ln();
		$sno++;




		$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
		$pdf->Cell($columnWidth,$columnHeight,"TEST MARKS",1,0);
		//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
		$pdf->Cell($columnWidth-5,$columnHeight,"$test_score",1,0,'C');
		$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
		$pdf->ln();
		$sno++;




			if ($objectionRemarks != "" || $objectionRemarks != 0) {

				$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
				$pdf->Cell($columnWidth,$columnHeight,"Objection Remarks",1,0);
				//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
				$pdf->Cell($columnWidth-5,$columnHeight,"$objectionRemarks",1,0,'C');
				$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
				$pdf->ln();
				$sno++;
				}

				$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
				$pdf->Cell($columnWidth,$columnHeight,"Program",1,0);
				//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
				$pdf->Cell($columnWidth-5,$columnHeight,"$discipline",1,0,'C');
				$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
				$pdf->ln();
				$sno++;

				$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
				$pdf->Cell($columnWidth,$columnHeight,"Any Other Objection",1,0);
				//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
				$pdf->Cell($columnWidth-5,$columnHeight,"",1,0,'C');
				$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
				$pdf->ln();
				$sno++;

				$pdf->Cell($columnWidth/4,$columnHeight,"$sno",1,0);
				$pdf->Cell($columnWidth,$columnHeight,"Any Other Objection",1,0);
				//$pdf->Cell($columnWidth/3,$columnHeight,"",1,0);
				$pdf->Cell($columnWidth-5,$columnHeight,"",1,0,'C');
				$pdf->Cell($columnWidth,$columnHeight,"",1,0,'C');
				$pdf->ln();
				$sno++;





		$pdf->SetXY(150, 160);
        $pdf->Ln(2);
		$pdf->Cell(0,$columnHeight,"Signature of the applicant",0,0);

 
		
    }
}	
		
	
		//request if
		$pdf->Ln();
		$pdf->Output();
	
       ?>
	   
	    	
		
			
	   			  
		
		
      



