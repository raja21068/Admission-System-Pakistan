<?php
	if ($admListDetailId==4){
		?>
		<ol type="1">
<li><div>Those students who have submitted pro-forma along-with Demand Draft (DD) for Evening Program but not selected in any discipline, he/ she may submit application for admission to <b> BS (Public Administration), BS (Commerce), BS (Forestry) and B.B.A (Old Campus) </b>Evening Programs up-to<b> Friday 08.01.2016</b></div></li>

<li> <div>Those candidates who wish to transfer for Campus of their Domicile of Jurisdiction, they may submit application at Directorate of Admissions duly recommended by Pro-Vice Chancellor of respected Campus.</b></div></li>
<li> <div>Those Candidates who desired to cancel their admission and refund of admission fee, may submit application along-with original Paid Admission Fee Challan upto Friday 08.01.2016 </b></div></li>

</ol>
		<?php
	} ?>
	<?php
	if ($admListDetailId==0){

?>
<ol type="1">
<li><div><b> Those prospective students who have applied for admissions against reserved seats i.e sports/ disabled/ S.U employee/ affiliated college quota must submit required certificate up-to 21.11.2015.Failing in which he/she will not be considered against reserved seat.</b></div></li>

<li> <div><b>The prospective students must check their profile carefully and clear the objections/ provide required documents by 21.11.2015. Failing in which he/she will not be considered for admission.</b></div></li>
</ol>


<?php 
	}
?>
 
      <!--  <div>
            <strong>You can submit your objection/application for  correction on the following prescribed pro forma by hand to the Directorate of Admission, Ghulam Mustafa Shah Administration building, University Of Sindh Allama I.I Kazi Campus ,Jamshoro
        </strong>
        </div>
   -->
<?php
	if ($admListDetailId==1 || $admListDetailId==2){

?>
<!--
The Director Admissions University of Sindh has announced for general information that those candidates who have been selected for admission to Bachelor degree program under first merit list in the University of Sindh but still not deposited admission fees they are hereby advised to deposit their admission fee up to Monday, December, 15, 2014.</br>
<a href="#" id="rm" >..read more</a>
<readmore id="rmpara" style="display:none;">Bank challan of fees can be obtained by the candidates from the Directorate of Admissions University of Sindh and deposit the admission fees at HBL branch Jamshoro. The candidates selected against reserved seats of districts must bring original domicile and PRC certificate with them at the time of obtaining of bank challan of fees. The candidates selected on reserved seats for employees of affiliated degree colleges must bring service certificate signed by the Director of Colleges.
</br>?The candidates selected for admission at various campuses of the University can collect fees challan from the concerned campuses and deposit fees at the prescribed HBL branches there.
<a href="#" id="hide">..hide</a>
</readmore>
</br>
</br>
<script>
	$("#rm").click(function(){
		$("#rmpara").show();
		$(this).hide();
	});
</script>
<script>
	$("#hide").click(function(){
		$("#rm").show();
		$("#rmpara").hide();
	});
</script>

-->
<ol type='1'>
<div>
<li style="color:red">     The student desirous of retaining the discipline allocated in first offer may do so by submitting their acceptance in writing along-with paid challan of Rs.200/- to be issued by the Assistant Director Admissions up to last date of submission of admission fee.  Otherwise their choice of preference may be changed automatically (if eligible) in next merit list. </li></br>
</div>
<li><div> Those prospective students selected in their subject as mentioned at choice No: 01 are not required to deposit challan of retaining fee.  </div></li></br>
<li><div>After due date no request for retaining of subject will be entertained</div></li></br>
<li><div>No application will be entertained for change of choice/subject.   </div></li></br>
<li><div>Once a choice of the discipline is assigned to a student, he/she will not be assigned lower choice(s) at later stage or in next merit list(s) </div></li></br>
<li><div>The candidates selected on reserve seats under category of Sindh University Employees Quota are required to show Service Certificate countersigned by the Registrar, University of Sindh, Jamshoro. </div></li></br>
<li><div>The candidates selected for admissions on reserved seats of affiliated college teachers are required to submit service certificate signed by the Director Colleges Education.</div></li></br>

</ol>
<div>The candidates selected in Quota-oriented disciplines (listed below) are required to show their Original Domicile and PRC certificates at the time of collection of Admission Fees Challan.
<div class='table-responsive'>
<table class='table table-bordered'>
<tr>
<td>LL.B (Law)  </td>
<td>B.B.A (Hons)</td>
<td>Pharm-D (Doctor of Pharmacy) </td>
<td>BS (Geology) </td>
<td>BS (Genetics)</td>
<td>BS (Electronics) </td>
</tr>
<tr>
<td>BS (Information Technology)</td>
<td>BS (Computer Science)</td>
<td>BS (Software Engineering)</td>
<td>BS (Public Administration)</td>
<td>BS (Telecommunication)</td>
<td></td>
</tr>
</table></div>
</div>
</br>

<div>The candidates selected on reserve seats under category of Sindh University Employees Quota are required to show Service Certificate countersigned by the Registrar, University of Sindh, Jamshoro.</div></br>

<div>The candidates selected for admissions on reserved seats of affiliated college teachers are required to submit service certificate signed by the Director Colleges.</div></br>

<div>The University of Sindh reserves the right to rectify any error / omission detected at any stage and also reserves the right to cancel any  Admission at any time without issuing prior notice. </div></br>
<?php
}
?>



<?php
	if ($admListDetailId==3){

?>
<!--
<div style="color:blue" >

	
"If you are selected for any other discipline in 2nd merit selection and you are not interested in the automatic transfer of your admission to said discipline then please follow the instructions.
<ul>
<li> •	Submit an applications and obtain separate challan of Rs. 200 from the Directorate of Admissions and deposit in bank for retaining your admission in first choice, failing which your admission will be transferred automatically, based on 2nd Merit Selection and a new challan of fee difference (if there is any difference in both fees) will be issued"</li>
</ul>
"However, if you are selected for any other discipline in 2nd merit selection and you are interested in the automatic transfer of your admission in next choice based on 2nd Merit Selection then please follow the instructions
<ul>
<li>•	Obtain the fee difference challan (if there is any difference in both fees) from counters of Directorate of Admissions, within stipulated time and deposit in bank. If you fail to do so then your admission will not be automatically transferred and you will not be considered for 3rd Merit Selection. "</li>
	</ul>
	</b>
</div>
-->


<div>The candidates selected in Quota-oriented disciplines (listed below) are required to show their Original Domicile and PRC certificates at the time of collection of Admission Fees Challan.
<div class='table-responsive'>
<table class='table table-bordered'>
<tr>
<td>LL.B (Law)  </td>
<td>B.B.A (Hons)</td>
<td>Pharm-D (Doctor of Pharmacy) </td>
<td>BS (Geology) </td>
<td>BS (Genetics)</td>
<td>BS (Electronics) </td>
</tr>
<tr>
<td>BS (Information Technology)</td>
<td>BS (Computer Science)</td>
<td>BS (Software Engineering)</td>
<td>BS (Public Administration)</td>
<td>BS (Telecommunication)</td>
<td></td>
</tr>
</table>
</div>
</div>
</br>

<div>The candidates selected on reserve seats under category of Sindh University Employees Quota are required to show Service Certificate countersigned by the Registrar, University of Sindh, Jamshoro.</div></br>

<div>The candidates selected for admissions on reserved seats of affiliated college teachers are required to submit service certificate signed by the Director Colleges.</div></br>

<div>The University of Sindh reserves the right to rectify any error / omission detected at any stage and also reserves the right to cancel any  Admission at any time without issuing prior notice. </div></br>

<?php
}
?>

<!--<div  style="margin-top: 10px; padding-left: 191px; padding-right: 10px; float: left; padding-top: 0px;">
    <a href="assets/bachlors/Objection.pdf" style="color: #000;">
        <div style="width:60%; float: left;">
            <strong>You can submit your objections (if any) regarding this  Merit Selection Result/List by downloading and submitting this Objection Form.
                </strong>
        </div>
        <div style="width:40%;float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>-->
<!--
<div class='row'>
<div class="col-md-5" style="  background-color: #D0D0D0;">
    <a href="assets/bachlors/Objection.pdf" style="color: #000;">
        
            <strong>You can submit your objections (if any) by submitting this Objection Form.
        
                </strong>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>
<div class="col-md-2"></div>

<div class="col-md-5" style=" background-color: #D0D0D0;">
    <a href="assets/bachlors/retaining.pdf" style="color:blue;">
        <div style="">
            <strong>APPLICATION FORM FOR RETAINING ADMISSION  (BACHELORS<span>'</span>)</strong><br>
        </div>
        <div style="width:40% float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>


</div>
-->
<!--
<div class="sidebar" style="margin-top: 10px; padding-left: 10px; float: left; width: 45%; background-color: #D0D0D0;padding-top: 0px;">
    <a href="assets/bachlors/Rechecking.pdf" style="color: #000;">
        <div style="width:60%; float: left;">
            <strong>If you want to submit your request for rechecking of your test paper then read the instructions here
                </strong>
        </div>
        <div style="width:40%;float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>
<div class="sidebar" style=" margin-top: 10px;margin-left:10px;  padding-left: 10px; float: left; width: 45%; background-color: #D0D0D0;padding-top: 0px;" >
    <a href="assets/bachlors/Rechecking_form.pdf" style="color:#000;">
        <div style="width:60%;  float: left;">
            <strong>You can submit your application for rechecking of your test paper by using this form
        </strong>
        </div>
        <div style="width:40%;float: right;">
            <img src="images/links.png">
        </div>
    </a>
</div>
-->